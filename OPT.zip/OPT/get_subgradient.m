function [x,objval] = get_subgradient(tol_Model,r)  

%用Gurobi求解
params.outputflag = 0;           %0表示命令行窗口不显示求解过程�?1表示显示过程


obj_c = tol_Model.obj_c - tol_Model.Bwan' * r;


Gmodel.obj = full(obj_c);
Gmodel.A = [tol_Model.Aineq;tol_Model.Aeq];
Gmodel.rhs = full([tol_Model.bineq;tol_Model.beq]);
Gmodel.sense(1:size(tol_Model.Aineq,1)) = '<';
Gmodel.sense(size(tol_Model.Aineq,1)+1:size(tol_Model.Aineq,1)+size(tol_Model.Aeq,1)) = '=';
Gmodel.vtype = tol_Model.var_type;
Gmodel.modelsense = 'min';
Gmodel.varnames = tol_Model.var_names;
Gmodel.lb = full(tol_Model.lb);
Gmodel.ub = full(tol_Model.ub);
Gmodel.vtype(Gmodel.vtype == 'B') = 'C';                        %把整数变量改成连续变�?  
%gurobi_write(Gmodel, 'dual.lp');
result = gurobi(Gmodel,params);

% for v=1:length(tol_Model.var_names)
%      fprintf('%s %d\n',tol_Model.var_names{v},result.x(v));
% end


x = result.x;
objval = result.objval;
end