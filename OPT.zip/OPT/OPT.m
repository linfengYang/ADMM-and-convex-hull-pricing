function OPT(dataUC)
%    pathAndFilename='UC_AF/50_1.mod';   
%    pathAndFilename='UC_AF/example_2_std.mod';   
%    pathAndFilename='UC_AF/example_3_std.mod';   
%   pathAndFilename='UC_AF/5_2_std.mod';   
%    pathAndFilename='UC_AF/5_std.mod';
%     pathAndFilename='UC_AF/8_std.mod';
%      pathAndFilename='UC_AF/10_std.mod';
%     pathAndFilename='UC_AF/10_0_4_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/75_0_1_w.mod';
%      pathAndFilename='UC_AF/200_0_1_w.mod';
%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';
%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%       pathAndFilename='UC_AF/c20_187_based_8_std.mod';
%dataUC=readdataUC(pathAndFilename);
%dataUC = example('hua_2',1);
N = dataUC.N; %�������
T = dataUC.T;
path = ['��ֵʵ��/',dataUC.dataName,'_',num2str(N),'_',num2str(T),'_OPT','.txt'];
fileID = fopen(path,'w');

slack_model.Aineq = [];
slack_model.bineq = [];
slack_model.Aeq = [];
slack_model.beq = [];
slack_model.lb = [];
slack_model.ub = [];
slack_model.var_type = [];
slack_model.var_names = [];
slack_model.var_num = [];
slack_model.Bwan = [];
slack_model.b = [];
slack_model.obj_c = [];
slack_model.slack = [];

MILP_model.Aineq = [];
MILP_model.bineq = [];
MILP_model.Aeq = [];
MILP_model.beq = [];
MILP_model.lb = [];
MILP_model.ub = [];
MILP_model.var_type = [];
MILP_model.var_names = [];
MILP_model.var_num = [];
MILP_model.Bwan = [];
MILP_model.b = [];
MILP_model.obj_c = [];
MILP_model.slack = [];

%�����ͻ��鼯
G1 = []; G2 = []; G3 = [];num = 0;
new_model_i = cell(N,1);
for i = 1:N
    [single_model,model_3bin,G1,G2,G3,num] = unit_division_OPT(dataUC,G1,G2,G3,i,10,num);
    new_model_i{i} = single_model;
    slack_model.var_num = [slack_model.var_num,single_model.var_num];
    slack_model.var_type = [slack_model.var_type,single_model.var_type];
    slack_model.var_names = [slack_model.var_names;single_model.var_names];
    
    slack_model.obj_c = [slack_model.obj_c;single_model.obj_c];
    slack_model.Aineq = blkdiag(slack_model.Aineq,single_model.Aineq);
    slack_model.Aeq = blkdiag(slack_model.Aeq,single_model.Aeq);
    slack_model.bineq = [slack_model.bineq;single_model.bineq];
    slack_model.beq = [slack_model.beq;single_model.beq];
    slack_model.Bwan = [slack_model.Bwan,single_model.Bwan];
    slack_model.lb = [slack_model.lb;single_model.lb];
    slack_model.ub = [slack_model.ub;single_model.ub];
    slack_model.slack = [slack_model.slack,single_model.slack];
    
    MILP_model.var_num = [MILP_model.var_num,model_3bin.var_num];
    MILP_model.var_type = [MILP_model.var_type,model_3bin.var_type];
    MILP_model.var_names = [MILP_model.var_names;model_3bin.var_names];
    MILP_model.obj_c = [MILP_model.obj_c;model_3bin.obj_c];
    MILP_model.Aineq = blkdiag(MILP_model.Aineq,model_3bin.Aineq);
    MILP_model.Aeq = blkdiag(MILP_model.Aeq,model_3bin.Aeq);
    MILP_model.bineq = [MILP_model.bineq;model_3bin.bineq];
    MILP_model.beq = [MILP_model.beq;model_3bin.beq];
    MILP_model.Bwan = [MILP_model.Bwan,model_3bin.Bwan];
    MILP_model.lb = [MILP_model.lb;model_3bin.lb];
    MILP_model.ub = [MILP_model.ub;model_3bin.ub];
    MILP_model.slack = [MILP_model.slack,model_3bin.slack];
end
fprintf('��͹������:%d\n', num);
tic
%��⣨P1���õ����Ž�Ͷ�ż����r
[~,r,objval] = solve_problem(dataUC,slack_model,0,0,0,1,path);

%r = round(r);
[~,Zc_r] = solve_Lagrange_duality(slack_model,r); %������������ɳ�
IA_time = toc;
fprintf('OPT�㷨ִ��ʱ��:%f\n', IA_time);
%���MILPģ�͵õ�Ŀ��ֵZ_QIP
[~,~,Z_QIP] = solve_problem(dataUC,MILP_model,1,0,0,path);

%������̧����
U = round(Z_QIP) - round((Zc_r + r' * dataUC.PD));
%U = round(Z_QIP) - round(objval);

%%���
fprintf('MIP:%d\n', round(Z_QIP));
fprintf('dul:%d\n', round(Zc_r + r' * dataUC.PD));
fprintf('͹���۸�:%d\n',r);
fprintf('��̧����:%d\n', U);

fprintf(fileID,'-----------------------------------------------------------------------------------\n');
fprintf(fileID,'͹���۸�:%d\n',r);
fprintf(fileID,'MIP:%d\n',round(Z_QIP));
fprintf(fileID,'dul:%d\n',round(Zc_r + r' * dataUC.PD));
fprintf(fileID,'��̧����%d\n',U);
fprintf(fileID,'OPT�㷨ִ��ʱ��:%f\n', IA_time);
fclose(fileID);
end

