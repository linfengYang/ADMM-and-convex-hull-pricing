function simple_convexHull = Model_simple(dataUC,j,unitType,L) %�����ֱ�Ϊ����������������š��������͡�Ŀ�꺯���ֶ����Ի��Ķ���L
%�ο�(2020 TPS Yanan Yu)An Extended Integral Unit Com-mitment
%Formulation and an Iterative Algorithm for Convex Hull Pricing
%����ļ�͹��ģ��
T = dataUC.T;
%��С��ͣʱ��
L_i = dataUC.time_min_on(j);
E_i = dataUC.time_min_off(j);



%����������ģ��

%��������
type_p(1:T) = 'C'; type_z(1:T) = 'C'; type_u(1:T) = 'B'; type_v(1:T - 1) = 'B'; type_e(1:T - 1) = 'B';
%������
name_p = cell(T,1); name_z = cell(T,1); name_u = cell(T,1);name_v = cell(T - 1,1); name_e = cell(T - 1,1);
for t = 1:T
    name_p{t} = ['p',num2str(j),num2str(t)];
    name_z{t} = ['z',num2str(j),num2str(t)];
    name_u{t} = ['u',num2str(j),num2str(t)];
    if t > 1
        name_v{t - 1} = ['v',num2str(j),num2str(t)];
        name_e{t - 1} = ['e',num2str(j),num2str(t)];
    end
end


%��������
var_num = 3*T + 2 * (T - 1);

%״̬Լ��(6d)
Aeq_state_u = sparse(T - 1,T); Aeq_state_v = sparse(T - 1,T - 1);
Aeq_state_e = sparse(T - 1,T - 1);
index  = 1;
for t = 2:T
    Aeq_state_u(index,t) = 1;
    Aeq_state_u(index,t - 1) = -1;
    Aeq_state_v(index,t - 1) = -1;
    Aeq_state_e(index,t - 1) = 1;
    index = index + 1;
end

%��С��ͣʱ��Լ��
Aineq_minStartTime_v = sparse(L_i + 1,T - 1);
Aineq_minStartTime_u = sparse(L_i + 1,T);
Aineq_minDownTime_v = sparse(E_i + 1,T - 1);
Aineq_minDownTime_u = sparse(E_i + 1,T);

v_row = 1;u_row = 1;
for t = L_i + 1:T
    Aineq_minStartTime_u(u_row,t) = -1;
    u_row = u_row + 1;
    for i = t - L_i + 1:t
        Aineq_minStartTime_v(v_row,i - 1) = 1;
    end
    v_row = v_row + 1;
end

v_row = 1; u_row = 1;
for t = E_i + 1:T
    Aineq_minDownTime_u(u_row,t - E_i) = 1;
    u_row = u_row + 1;
    for i = t - E_i + 1:t
        Aineq_minDownTime_v(v_row,i - 1) = 1;
    end
    v_row = v_row + 1;
end

%�������½�
Aineq_low_p = sparse(1:T,1:T,-1); Aineq_low_u = sparse(1:T,1:T,dataUC.p_low(j));
Aineq_up_p = sparse(1:T,1:T,1); Aineq_up_u = sparse(1:T,1:T,-dataUC.p_up(j));
%���������½�
var_up = [inf*ones(2*T,1);inf*ones(T,1);inf*ones(2*(T - 1),1)];  
var_low = [-inf*ones(2*T,1);zeros(T,1);zeros(2*(T - 1),1)];  
%��������Լ��
Aineq_rampUp_p = sparse(T,T); Aineq_rampUp_u = sparse(T,T);
Aineq_rampUp_v = sparse(T,T - 1);
Aineq_rampDown_p = sparse(T,T); Aineq_rampDown_u = sparse(T,T);
Aineq_rampDown_e = sparse(T,T - 1);

for i = 1:T
    Aineq_rampUp_p(i,i) = 1;
    Aineq_rampDown_p(i,i) = -1;
    if i > 1
       Aineq_rampUp_p(i,i - 1) = -1;
       Aineq_rampUp_u(i,i - 1) = -dataUC.p_rampup(j);
       Aineq_rampDown_p(i,i - 1) = 1;
       Aineq_rampDown_u(i,i - 1) = -dataUC.p_rampdown(j);
    end
    if i > 1
        Aineq_rampUp_v(i,i - 1) = -dataUC.p_startup(j);
        Aineq_rampDown_e(i,i - 1) = -dataUC.p_shutdown(j);
    end
end

if dataUC.u0(j) == 1
   bineq_rampUp = [dataUC.u0(j)*dataUC.p_rampup(j) + dataUC.p_initial(j);zeros(T - 1,1)];
   bineq_rampDown = [dataUC.u0(j)*dataUC.p_rampdown(j) - dataUC.p_initial(j);zeros(T - 1,1)];
else
    bineq_rampUp = [dataUC.p_startup(j);zeros(T - 1,1)];
    bineq_rampDown = [dataUC.p_startup(j);zeros(T - 1,1)];
end

Aineq_startUpRamp_p = sparse(T - 1,T); Aineq_startUpRamp_u = sparse(T - 1,T);
Aineq_startUpRamp_v = sparse(T - 1,T - 1);
index_row = 1;
for i = 2:T
    Aineq_startUpRamp_p(index_row,i) = 1;
    Aineq_startUpRamp_u(index_row,i) = -dataUC.p_up(j);
    Aineq_startUpRamp_v(index_row,i - 1) = -(dataUC.p_startup(j) - dataUC.p_up(j));
    index_row = index_row + 1;
end


%����������gurobiģ��

%�̶��Ŀ����ɱ�
c_startCost = dataUC.fixedStartCost(j)*ones(T - 1,1);

%������
var_type = [type_p,type_z,type_u,type_v,type_e];
var_name = [name_p;name_z;name_u;name_v;name_e];

%״̬Լ��ϵ������
constraint_status = [sparse(T - 1,T),sparse(T - 1,T),Aeq_state_u,Aeq_state_v,Aeq_state_e];


%��С��ͣʱ��ϵ������
constraint_minStartTime = [sparse(size(Aineq_minStartTime_u,1),T),sparse(size(Aineq_minStartTime_u,1),T),Aineq_minStartTime_u,Aineq_minStartTime_v,sparse(size(Aineq_minStartTime_u,1),T - 1)];
constraint_minDownTime = [sparse(size(Aineq_minDownTime_u,1),T),sparse(size(Aineq_minDownTime_u,1),T),Aineq_minDownTime_u,Aineq_minDownTime_v,sparse(size(Aineq_minDownTime_u,1),T - 1)];

%�������½�ϵ������
constraint_up_p = [Aineq_up_p,sparse(T,T),Aineq_up_u,sparse(T,T - 1),sparse(T,T - 1)];
constraint_low_p = [Aineq_low_p,sparse(T,T),Aineq_low_u,sparse(T,T - 1),sparse(T,T - 1)];
    
%��������Լ��ϵ������
constraint_ramp_up = [Aineq_rampUp_p,sparse(T,T),Aineq_rampUp_u,Aineq_rampUp_v,sparse(T,T - 1)];
constraint_ramp_down = [Aineq_rampDown_p,sparse(T,T),Aineq_rampDown_u,sparse(T,T - 1),Aineq_rampDown_e];
constraint_startUpRamp_up = [Aineq_startUpRamp_p,sparse(T - 1,T),Aineq_startUpRamp_u,Aineq_startUpRamp_v,sparse(T - 1,T - 1)];


simple_convexHull.var_num = var_num;
simple_convexHull.var_type = var_type;
simple_convexHull.var_names = var_name;
if unitType == 1
    simple_convexHull.Aineq = [constraint_minStartTime;constraint_minDownTime;constraint_up_p;constraint_low_p];
    simple_convexHull.bineq = [zeros(size(Aineq_minStartTime_u,1),1);ones(size(Aineq_minDownTime_u,1),1);zeros(2*T,1)];
else  
    simple_convexHull.Aineq = [constraint_minStartTime;constraint_minDownTime;constraint_up_p;constraint_low_p;constraint_startUpRamp_up];    
    simple_convexHull.bineq = [zeros(size(Aineq_minStartTime_u,1),1);ones(size(Aineq_minDownTime_u,1),1);zeros(3*T - 1,1)];
end
simple_convexHull.Aeq = constraint_status;
simple_convexHull.beq = zeros(T - 1,1);

%Ŀ�꺯���ֶ����Ի�
for i = 0:L
     pil = dataUC.p_low(j) + i * (dataUC.p_up(j) - dataUC.p_low(j)) / L;
     gradiant = sparse(T,var_num);
     gradiant(1:T,1:T) = (2 * dataUC.gamma(j) + dataUC.beta(j)) * eye(T); %pit
     gradiant(1:T,2*T + 1:3*T) = (dataUC.alpha(j) - dataUC.gamma(j) * power(pil,2)) * eye(T); %uit
     gradiant(1:T,T + 1:2*T) = -1 * eye(T); %zit
     b_linear = zeros(T,1);
     simple_convexHull.Aineq = [simple_convexHull.Aineq;gradiant];
     simple_convexHull.bineq = [simple_convexHull.bineq;b_linear];
end
simple_convexHull.obj_c = [zeros(T,1);ones(T,1);zeros(T,1);c_startCost;zeros(T - 1,1)];
simple_convexHull.Q = sparse(var_num,1);
simple_convexHull.Bwan = [sparse(1:T,1:T,1),sparse(T,var_num - T)];
simple_convexHull.lb = var_low;
simple_convexHull.ub = var_up;
simple_convexHull.slack = 0;
simple_convexHull.unitNum = j;
end