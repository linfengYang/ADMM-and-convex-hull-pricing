function r = get_dual(dataUC,model)
[xi,objval] = solve_problem(dataUC,model,1,0,0,1);
objval =                              
end