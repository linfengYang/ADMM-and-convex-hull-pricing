function G3 = unit_delete(G3,i)
for j = 1:size(G3,2)
    if G3(j) == i
       G3(j) = [];
       break;
    end
end
end