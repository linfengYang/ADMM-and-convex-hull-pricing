function [x,r] = solve_linprog(dataUC,model)

[x,fval,exitflag,OUTPUT,LAMBDA] = gurobi.linprog(model.obj_c,model.Aineq,model.bineq,model.Aeq,model.beq,model.lb,model.ub);


end