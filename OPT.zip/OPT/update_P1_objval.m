function M = update_P1_objval(objval,G3)
M = size(G3,2);
for i = 1:size(M,1)
    unit_num = G3(i);
    M{i}.G = unit_num;
    M{i}.P1_objval = objval;
end
end