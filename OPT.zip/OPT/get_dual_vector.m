function [x,r] = get_dual_vector(dataUC,model)

[x,r] = solve_problem(dataUC,model,0,0,0,1);


end