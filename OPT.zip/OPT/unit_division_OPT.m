function [single_model,MILP_model,G1,G2,G3,num] = unit_division_OPT(dataUC,G1,G2,G3,unit_num,n,num)
%���ֻ���,���ݻ�������Խ����黮�ֵ�G1������G2������ȥ
gap = dataUC.p_up(unit_num) - dataUC.p_low(unit_num);
if dataUC.p_rampup(unit_num) >= gap && dataUC.p_rampdown(unit_num) >= gap
       if dataUC.p_startup(unit_num) < gap
          single_model = Model_simple(dataUC,unit_num,2,n);
          MILP_model = single_model;
          G2 = [G2,unit_num];
          %disp('����2');
          num = num + 1;
       else
          single_model = Model_simple(dataUC,unit_num,1,n);
          G1 = [G1,unit_num];
          MILP_model = single_model;
          %disp('����1');
          num = num + 1;
       end
else
    single_model = model_DP2(dataUC,unit_num,n);
    MILP_model = model_3bin(dataUC,unit_num,n);
    %single_model.slack = 1;
    G3 = [G3,unit_num];
end
end