function tol_Model = merge_models(G1_Model,G2_Model)
%������ģ�ͺϲ���һ��gruobiģ��
tol_Model.var_num = G1_Model.var_num + G2_Model.var_num;
tol_Model.var_type = [G1_Model.var_type,G2_Model.var_type];
tol_Model.var_names = [G1_Model.var_names;G2_Model.var_names];
tol_Model.obj_c = [G1_Model.obj_c;G2_Model.obj_c];
tol_Model.Q = [G1_Model.Q;G2_Model.Q];
tol_Model.Aineq = blkdiag(G1_Model.Aineq,G2_Model.Aineq);
tol_Model.Aeq = blkdiag(G1_Model.Aeq,G2_Model.Aeq);
tol_Model.bineq = [G1_Model.bineq;G2_Model.bineq];
tol_Model.beq = [G1_Model.beq;G2_Model.beq];
tol_Model.Bwan = [G1_Model.Bwan,G2_Model.Bwan];
tol_Model.ub = [G1_Model.ub;G2_Model.ub];
tol_Model.lb = [G1_Model.lb;G2_Model.lb];

%�ϲ�����׶Լ��
for i = 1:size(G2_Model.Qrow,2)
    G2_Model.Qrow(i) = G1_Model.var_num + G2_Model.Qrow(i);
    G2_Model.Qcol(i) = G1_Model.var_num + G2_Model.col(i);
end
tol_Model.Qrow = [G1_Model.Qrow;G2_Model.Qrow];
tol_Model.Qcol = [G1_Model.Qcol;G2_Model.Qcol];
tol_Model.Qval = [G1_Model.Qval;G2_Model.Qval];
end