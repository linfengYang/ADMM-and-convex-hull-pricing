function run_test()

%����������ݼ�
pathAndFileName_1 = cell(1,1);
pathAndFileName_10 = cell(5,1);
pathAndFileName_20 = cell(5,1);
pathAndFileName_50 = cell(5,1);
pathAndFileName_75 = cell(5,1);
pathAndFileName_100 = cell(5,1);
pathAndFileName_150 = cell(5,1);
pathAndFileName_200 = cell(12,1);
pathAndFileName_1{1} = 'UC_AF/10_std.mod';
for i = 1:12
    %10��20��50��75��100��150 200
    if i <= 5
        pathAndFileName_10{i} = ['UC_AF/',num2str(10),'_0_',num2str(i),'_w.mod'];
        pathAndFileName_20{i} = ['UC_AF/',num2str(20),'_0_',num2str(i),'_w.mod'];
        pathAndFileName_50{i} = ['UC_AF/',num2str(50),'_0_',num2str(i),'_w.mod'];
        pathAndFileName_75{i} = ['UC_AF/',num2str(75),'_0_',num2str(i),'_w.mod'];
        pathAndFileName_100{i} = ['UC_AF/',num2str(100),'_0_',num2str(i),'_w.mod'];
        pathAndFileName_150{i} = ['UC_AF/',num2str(150),'_0_',num2str(i),'_w.mod'];
    end
    % 200
    pathAndFileName_200{i} = ['UC_AF/',num2str(200),'_0_',num2str(i),'_w.mod'];
end

tol_pathAndFileName = [pathAndFileName_1;pathAndFileName_10;pathAndFileName_20;pathAndFileName_50;pathAndFileName_75;pathAndFileName_100;pathAndFileName_150;pathAndFileName_200];

for i = 1:1%size(tol_pathAndFileName,1)
    path = tol_pathAndFileName{i};
    dataUC_i = readdataUC(path);
    N = dataUC_i.N;

    for j = 1:N
        if dataUC_i.time_on_off_ini(j) < 0
           dataUC_i.time_on_off_ini(j) = - dataUC_i.time_on_off_ini(j);
           dataUC_i.p_initial(j) = dataUC_i.p_low(j);
           dataUC_i.u0(j) = 1;
        end 
    end
    %�����͹������
%     simple_num = ceil(N * 0.6); simple_num_2 = ceil(simple_num * 0.5);unit_num = N;
%    for j = 1:simple_num
%         dataUC_i.p_rampup(unit_num) = dataUC_i.p_up(unit_num) + 50;
%         dataUC_i.p_rampdown(unit_num) = dataUC_i.p_up(unit_num) + 50;
%         if j <= simple_num_2
%            dataUC_i.p_startup(unit_num) = dataUC_i.p_rampup(unit_num);
%         end
%         unit_num = unit_num - 1;
%    end
          %�����͹������
%     simple_num = ceil(N * 0.6); simple_num_2 = ceil(simple_num * 0.5);unit_num = [7,8,5,6,9,10];
%    for j = 1:simple_num
%         dataUC_i.p_rampup(unit_num(j)) = dataUC_i.p_up(unit_num(j)) + 50;
%         dataUC_i.p_rampdown(unit_num(j)) = dataUC_i.p_up(unit_num(j)) + 50;
%         if j <= simple_num_2
%            dataUC_i.p_startup(unit_num(j)) = dataUC_i.p_rampup(unit_num(j));
%         end
%    end
%    
%    extend_num = ceil((100 / N));
%    
%     
%     dataUC.N = [];dataUC.T = [];dataUC.p_up = [];dataUC.p_low = [];
%     
%     
%     dataUC.p_rampup = [];dataUC.p_rampdown = [];dataUC.p_startup = [];
%     dataUC.p_startup = [];dataUC.p_shutdown = [];dataUC.alpha = [];
%     dataUC.beta = [];dataUC.gamma = [];dataUC.Cold_cost = [];
%     dataUC.Hot_cost = [];dataUC.fixedStartCost = [];
%     dataUC.time_min_on = [];dataUC.time_min_off = [];
%     dataUC.time_on_off_ini = [];dataUC.p_initial = [];
%     dataUC.u0 = [];dataUC.Cold_hour = [];
%     newstr = erase(path,'.mod');
%     
%     dataUC.dataName = erase(newstr,'UC_AF/');
%     dataUC.N = extend_num * dataUC_i.N;
%     dataUC.T = 24;
%     for j = 1:extend_num
%         dataUC.p_up = [dataUC.p_up;dataUC_i.p_up];
%         dataUC.p_low = [dataUC.p_low;dataUC_i.p_low];
%         dataUC.p_rampup = [dataUC.p_rampup;dataUC_i.p_rampup];
%         dataUC.p_rampdown = [dataUC.p_rampdown;dataUC_i.p_rampdown];
%         dataUC.p_startup = [dataUC.p_startup;dataUC_i.p_startup];
%         dataUC.p_shutdown = [dataUC.p_shutdown;dataUC_i.p_shutdown];
%         dataUC.alpha = [dataUC.alpha;dataUC_i.alpha];
%         dataUC.beta = [dataUC.beta;dataUC_i.beta];
%         dataUC.gamma = [dataUC.gamma;dataUC_i.gamma];
%         dataUC.Cold_cost = [dataUC.Cold_cost;dataUC_i.Cold_cost];
%         dataUC.Hot_cost = [dataUC.Hot_cost;dataUC_i.Hot_cost];
%         dataUC.fixedStartCost = [dataUC.fixedStartCost;dataUC_i.fixedStartCost];
%         dataUC.time_min_on = [dataUC.time_min_on;dataUC_i.time_min_on];
%         dataUC.time_min_off = [dataUC.time_min_off;dataUC_i.time_min_off];
%         dataUC.time_on_off_ini = [dataUC.time_on_off_ini;dataUC_i.time_on_off_ini];
%         dataUC.p_initial = [dataUC.p_initial;dataUC_i.p_initial];
%         dataUC.u0 = [dataUC.u0;dataUC_i.u0];
%         
%         dataUC.Cold_hour = [dataUC.Cold_hour;dataUC_i.Cold_hour];
%     end
    sizeI = [10,100,500,1000,1500,2000,3000];
    for k = 5:7
        extend_num = ceil((sizeI(k) / N));
        
        
        dataUC.N = [];dataUC.T = [];dataUC.p_up = [];dataUC.p_low = [];
        
        
        dataUC.p_rampup = [];dataUC.p_rampdown = [];dataUC.p_startup = [];
        dataUC.p_startup = [];dataUC.p_shutdown = [];dataUC.alpha = [];
        dataUC.beta = [];dataUC.gamma = [];dataUC.Cold_cost = [];
        dataUC.Hot_cost = [];dataUC.fixedStartCost = [];
        dataUC.time_min_on = [];dataUC.time_min_off = [];
        dataUC.time_on_off_ini = [];dataUC.p_initial = [];
        dataUC.u0 = [];dataUC.Cold_hour = [];
        newstr = erase(path,'.mod');
        
        dataUC.dataName = erase(newstr,'UC_AF/');
        dataUC.N = extend_num * dataUC_i.N;
        dataUC.T = 24;
        for j = 1:extend_num
            dataUC.p_up = [dataUC.p_up;dataUC_i.p_up];
            dataUC.p_low = [dataUC.p_low;dataUC_i.p_low];
            dataUC.p_rampup = [dataUC.p_rampup;dataUC_i.p_rampup];
            dataUC.p_rampdown = [dataUC.p_rampdown;dataUC_i.p_rampdown];
            dataUC.p_startup = [dataUC.p_startup;dataUC_i.p_startup];
            dataUC.p_shutdown = [dataUC.p_shutdown;dataUC_i.p_shutdown];
            dataUC.alpha = [dataUC.alpha;dataUC_i.alpha];
            dataUC.beta = [dataUC.beta;dataUC_i.beta];
            dataUC.gamma = [dataUC.gamma;dataUC_i.gamma];
            dataUC.Cold_cost = [dataUC.Cold_cost;dataUC_i.Cold_cost];
            dataUC.Hot_cost = [dataUC.Hot_cost;dataUC_i.Hot_cost];
            dataUC.fixedStartCost = [dataUC.fixedStartCost;dataUC_i.fixedStartCost];
            dataUC.time_min_on = [dataUC.time_min_on;dataUC_i.time_min_on];
            dataUC.time_min_off = [dataUC.time_min_off;dataUC_i.time_min_off];
            dataUC.time_on_off_ini = [dataUC.time_on_off_ini;dataUC_i.time_on_off_ini];
            dataUC.p_initial = [dataUC.p_initial;dataUC_i.p_initial];
            dataUC.u0 = [dataUC.u0;dataUC_i.u0];
            
            dataUC.Cold_hour = [dataUC.Cold_hour;dataUC_i.Cold_hour];
        end
        dataUC.PD = extend_num * dataUC_i.PD;
%         TLP(dataUC);
        OPT(dataUC);
    end
%     dataUC_i.PD = [dataUC_i.PD];
%     dataUC.PD = extend_num * dataUC_i.PD;
%    
% %         disp(dataUC.T);
% %         if k >= 2
% %            dataUC.T = dataUC.T + 24;
% %            dataUC.PD = [dataUC.PD;dataUC_i.PD];
% %         end
%         %CHP_subgradient(dataUC);
%         %TLP(dataUC);
%         OPT(dataUC);

end