%%  D_ADMM solve ED problem
function solve_DP(pathAndFilename)

% parallel = 1;       %% parallel=0 串行执行  =1 并行执行程序
% if parallel == 1
%     poolSize =  matlabpool('size');
%     if poolSize == 0
%         matlabpool local 8
% %         matlabpool jobm2
%     end
% else
%     poolSize = matlabpool('size');
%     if poolSize > 0
%         matlabpool close
%     end
% end
tic
%%%机组文件名称
%    pathAndFilename='UC_AF/50_1.mod';   
%    pathAndFilename='UC_AF/example_2_std.mod';   
%    pathAndFilename='UC_AF/example_3_std.mod';   
%   pathAndFilename='UC_AF/5_2_std.mod';   
%    pathAndFilename='UC_AF/5_std.mod';
%     pathAndFilename='UC_AF/8_std.mod';
      pathAndFilename='UC_AF/10_std.mod';
%     pathAndFilename='UC_AF/10_0_4_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/75_0_1_w.mod';
%      pathAndFilename='UC_AF/200_0_1_w.mod';
%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';
%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%       pathAndFilename='UC_AF/c20_187_based_8_std.mod';
dataUC=readdataUC(pathAndFilename);
%dataUC=example('10_1',1);
N=dataUC.N;    %机组�?
T=dataUC.T;    %时刻�?
%dataUC.PD = dataUC.PD(1:10);
for i = 1:N
    G(i) = i;
end
model_name = 'DP2';
[Gmodel,Gmodel_i] = Build_Model(dataUC,G,model_name,4);


%设置变量名称和类�?
model.varnames = Gmodel.var_names;
model.vtype = Gmodel.var_type;

%设置�?次项系数
model.obj = Gmodel.obj_c;
model.modelsense = 'min';

%设置变量上下�?
model.ub = Gmodel.ub;
model.lb = Gmodel.lb;
%设置二次项系�?
%model.Q = UC.Q_UC;
Gmodel.Aeq = [Gmodel.Aeq;Gmodel.Bwan];
Gmodel.beq = [Gmodel.beq;dataUC.PD];
% Gmodel.Aineq = [Gmodel.Aineq;Gmodel.Bwan_u];
% Gmodel.bineq = [Gmodel.bineq;dataUC.PD + dataUC.spin];
model.A =[Gmodel.Aineq;Gmodel.Aeq];
model.rhs = full([Gmodel.bineq;Gmodel.beq]);
model.sense(1:size(Gmodel.Aineq,1)) = '<';
model.sense(size(Gmodel.Aineq,1)+1:size(Gmodel.Aineq,1)+size(Gmodel.Aeq,1)) = '=';

%model.vtype(model.vtype == 'B') = 'C';  %��ģ�������ɳ�
      
params.outputflag = 1;
params.MIPGap = 0;

if strcmp(model_name,'3bin')
   gurobi_write(model, '3bin.lp');
end

if strcmp(model_name,'DP1')
   gurobi_write(model, 'DP1.lp');
end    

if strcmp(model_name,'DP2')
   gurobi_write(model, 'DP2.lp');
end    

result = gurobi(model,params);
pit = zeros(N,T);

if strcmp(model_name,'3bin')
      k = 1;
      for i = 1:N
%           fprintf('%d  ',result.x(k:k + T - 1));
%           fprintf('\n');
          pit(i,:) = result.x(k:k + T - 1)';
          k = k + 6*T;
      end
      disp(pit);
end
if strcmp(model_name,'DP1')
    s = 0;
    for i = 1:N
        d = Gmodel_i.var_num{i};
        pit(i,:) = result.x(s + 1:s + T)';
        s = s + d;
    end
    disp(pit);
end

if strcmp(model_name,'DP2')
    s = 0;
    for i = 1:N
        d = Gmodel_i.var_num{i};
        pit(i,:) = result.x(s + 1:s + T)';
        s = s + d;
    end
    disp(pit);
end

% for v=1:length(Gmodel.var_names)
%     fprintf('%s %d\n',Gmodel.var_names{v},result.x(v));
% end
end
%%%% end of function