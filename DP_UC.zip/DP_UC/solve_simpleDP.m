%%  D_ADMM solve ED problem
function solve_simpleDP(pathAndFilename)

% parallel = 1;       %% parallel=0 串行执行  =1 并行执行程序
% if parallel == 1
%     poolSize =  matlabpool('size');
%     if poolSize == 0
%         matlabpool local 8
% %         matlabpool jobm2
%     end
% else
%     poolSize = matlabpool('size');
%     if poolSize > 0
%         matlabpool close
%     end
% end
tic
%%%机组文件名称
%    pathAndFilename='UC_AF/50_1.mod';   
%    pathAndFilename='UC_AF/example_3_std.mod';   
%     pathAndFilename='UC_AF/5_2_std.mod';   
   pathAndFilename='UC_AF/5_std.mod';
%     pathAndFilename='UC_AF/8_std.mod';
%      pathAndFilename='UC_AF/10_std.mod';
%     pathAndFilename='UC_AF/10_0_1_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/75_0_1_w.mod';
%      pathAndFilename='UC_AF/200_0_1_w.mod';
%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';
%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%       pathAndFilename='UC_AF/c20_187_based_8_std.mod';
dataUC=readdataUC(pathAndFilename);
%dataUC=example('10_1');

N=dataUC.N;    %机组�?
T=dataUC.T;    %时刻�?
for i = 1:N
    G1(i) = i;
end
unitType(1:N,1) = 1;
DP = Build_simpleModel(dataUC,G1,unitType,10);
%设置变量名称和类�?
      model.varnames = DP.var_names;
      model.vtype = DP.var_type;
      
      %设置�?次项系数
      model.obj = DP.obj_c;
      model.modelsense = 'min';
      
      %设置变量上下�?
      model.ub = DP.ub;
      model.lb = DP.lb;
      %设置二次项系�?
      %model.Q = UC.Q_UC;
      %设置不等式约�?
      DP.Aeq = [DP.Aeq;DP.Bwan];
      DP.beq = [DP.beq;dataUC.PD];
      model.A =[DP.Aineq;DP.Aeq];
      model.rhs = full([DP.bineq;DP.beq]);
      model.sense(1:size(DP.Aineq,1)) = '<';
      model.sense(size(DP.Aineq,1)+1:size(DP.Aineq,1)+size(DP.Aeq,1)) = '=';
     
      %旋转二阶锥约�?
%       Q_num = size(DP.Qrow,2)/2; k = 1;j = T + 1;
%       for i = 1:Q_num
%           model.quadcon(i).Qrow = [DP.Qrow(k),DP.Qrow(j)];
%           model.quadcon(i).Qcol = [DP.Qcol(k),DP.Qcol(j)];
%           model.quadcon(i).Qval = [DP.Qval(k),DP.Qval(j)];
%           model.quadcon(i).q  = DP.Q;
%           model.quadcon(i).rhs = 0.0;
%           model.quadcon(i).name = ['rot_cone',num2str(i)];
%           k = k + 1;
%           j = j + 1;
%           if mod(k-1,T) == 0
%              k = k + T;
%              j = j + T;
%           end
%       end
%      model.vtype(find(model.vtype == 'B')) = 'C';                        %把整数变量改成连续变�?
      
      params.outputflag = 1;
      %params.MIPGap = 0.0001;
      
      gurobi_write(model, 'simpleDP.lp');
      result = gurobi(model,params);

      k = 1; j = T;
      for v = 1:N
          fprintf('%d  ',result.x(k:j));
          fprintf('\n');
          k = k + 3*T + 2*(T - 1);
          j = j + 3*T + 2*(T - 1);
      end
      for v=1:length(DP.var_names)
          fprintf('%s %d\n',DP.var_names{v},result.x(v));
      end
end
%%%% end of function