%% ***************************************************************
%             ���ߣ���ʩ��
%             ԭ�����ڣ�2021��6��7��
%             �޸����ڣ�
%             ����˵��������Mʱ��ģ�͡�
%% ***************************************************************
function model = model_chen(dataUC,DC_flow,boolean_MILP,D,window,wflag,drflag,history,facet,mflag)
%����ʽ����̬����������
%% init ��ʼ������
if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
    N = dataUC.N;                                                    %����������--1*1����
    T = dataUC.T;                                                    %ʱ�����--1*1����
    PD = dataUC.PD;                                                  %��������--T*1����   
    %Spin = dataUC.spin;                                              %��ת�ȱ���--T*1����

    Alpha = dataUC.alpha;                                            %�����鷢�纯��ϵ��Alpha--N*1����
    Beta = dataUC.beta;                                              %�����鷢�纯��ϵ��Beta--N*1����
    Gamma = dataUC.gamma;                                            %�����鷢�纯��ϵ��Gama--N*1����

    Pmin = dataUC.p_low;                                             %�����鷢�繦���½�--N*1����
    Pmax = dataUC.p_up;                                              %�����鷢�繦���Ͻ�--N*1����
    Pup = dataUC.p_rampup;                                           %���������¹����Ͻ�--N*1����
    Pdown = dataUC.p_rampdown;                                       %���������¹����Ͻ�--N*1����
    Pstart = dataUC.p_startup;                                       %�����鿪������--N*1����
    Pshut = dataUC.p_shutdown;                                       %������ػ�����--N*1����    

    Time_on_min = dataUC.time_min_on;                                %��������С����ʱ��--N*1����
    Time_off_min =dataUC.time_min_off;                               %��������Сͣ��ʱ��--N*1����
    Cost_cold = dataUC.Cold_cost;                                    %����������������--N*1����
    Cost_hot = dataUC.Hot_cost;                                      %����������������--N*1����
    Time_cold = dataUC.Cold_hour;                                    %������������ʱ��--N*1����

    Time_on_off_ini = dataUC.time_on_off_ini;                        %�������ڳ�ʼ״̬ǰ�Ѿ�����/ͣ����ʱ��--N*1����

    if(isfield(dataUC,'p_initial'))                                  %isfield(S,'fieldname')�жϽṹ��S�Ƿ������fieldnameָ������,��������������߼�1�����S������fieldname�����S���ǽṹ�����͵ģ������߼�0
        P0 = dataUC.p_initial;
    else
        P0 = dataUC.p_up * 0.7;                                        %��������ʼ����--N*1����
    end

    if(isfield(dataUC,'u0'))
        u0 = dataUC.u0;
    else
        u0 = full(spones(P0));                                       %����������ʼ��/ͣ��״̬
    end
end

%% ��ʷ��Ϣ
L = max(0,min(ones(N,1) * T,(ones(N,1) - u0) .* (Time_off_min + Time_on_off_ini)));       %���������ٻ�Ҫ�ٱ��ֹػ�ʱ��--N*1����
W = max(0,min(ones(N,1) * T,u0 .* (Time_on_min - Time_on_off_ini)));                      %��������Լ�����������ٻ�Ҫ�ٱ��ֿ���ʱ��--N*1����

%% P����ͶӰ
Alpha_wan = Alpha + Beta .* Pmin + Gamma .* Pmin .* Pmin;                    %Alpha����--N*1����
Beta_wan = (Pmax - Pmin) .* (Beta + 2 * Gamma .* Pmin);                      %Beta����--N*1����
Gamma_wan = Gamma .* (Pmax - Pmin) .* (Pmax - Pmin);                        %Gama����--N*1����

P0_wan = (P0 - u0 .* Pmin) ./ (Pmax - Pmin);                                %���Pit�����ʼֵ
Pup_wan = Pup ./ (Pmax - Pmin);                                             %Pup����--N*1����
Pdown_wan = Pdown ./ (Pmax - Pmin);                                         %Pdown����--N*1����
Pstart_wan = (Pstart - Pmin) ./ (Pmax - Pmin);                              %Pstart����--N*1����
Pshut_wan = (Pshut - Pmin) ./ (Pmax - Pmin);                                %Pshut����--N*1����

%% �Զ��峣��
G = ceil(max(0,P0_wan - Pshut_wan) ./ Pdown_wan);                           %��һʱ�����ػ�����������Լ��
U = min(ones(N,1) * T,u0 .* max(G,Time_on_min - Time_on_off_ini));          %���������ٻ�Ҫ�ٱ��ֿ���ʱ��--N*1����
K = max(0,floor((P0_wan - Pshut_wan) ./ Pdown_wan) + ones(N,1));            %��һʱ�����ػ����½�������
Q = min(ones(N,1) * T,u0 .* max(K,Time_on_min - Time_on_off_ini));          %��һʱ�οɹػ����½�������

if(mflag == 1)
    %ԭģ�ͱ��� variable = {'PitWan','C',T;'SitWan','C',T;'taoit','B',tao_sum};    %var + tao_sum������
    var = 2 * T;     % Mʱ��ģ��taoǰ��ı���{PitWan,SitWan}����
elseif(mflag == 2)
    %ԭģ�ͱ��� variable = {'PitWan','C',T;'SitWan','C',T;'uit','B',T;'vit','B',T;'wit','B',T;'taoit','B',tao_sum};    %var + tao_sum������
    var = 5 * T;     % Mʱ��ģ��taoǰ��ı���{PitWan,SitWan,uit,vit,wit}����
elseif(mflag == 3)
    %ԭģ�ͱ��� variable = {'PitWan','C',T;'SitWan','C',T;'uit','B',T;'vit','B',T;'wit','B',T;'taoit','B',tao_sum};    %var + tao_sum������
    var = 5 * T;     % Mʱ��ģ��taoǰ��ı���{PitWan,SitWan,uit,vit,wit}����
end

%% ���崰�ڴ�С
if(window == 0)
    M = max([ceil((ones(N,1) - Pstart_wan) ./ Pup_wan) + ones(N,1),ceil((ones(N,1) - Pshut_wan) ./ Pdown_wan) + ones(N,1),ceil(ones(N,1) ./ Pup_wan),ceil(ones(N,1) ./ Pdown_wan)]')';    
elseif(window == 1)
    M = (T + 1) * ones(N,1);                                      %���л���Ĵ��ڴ�С����T + 1��ֻ��1������
else
    M = window * ones(N,1);                                      %���л���Ĵ��ڴ�С����window
end

%% ��Ԫ������洢Լ��
% ������Լ��
A_s_ineq = cell(N,1);
b_s_ineq = cell(N,1);

A_s_eq = cell(N,1);
b_s_eq = cell(N,1);

% ���Լ��
A_c_ineq = cell(N,1);
A_c_eq = cell(N,1);
%���Լ������
B_wan = cell(N,1);
%Ŀ�꺯��
H = cell(N,1);
f = cell(N,1);

orig_H = cell(N,1);
orig_f = cell(N,1);

%�������½�
lb = cell(N,1);
ub = cell(N,1);

tao_location = cell(N,1);      %��¼tao������λ��

% ÿ������ԭʼ�����ĸ���
ori_var_num = sparse(N,1);      %Ŀ�꺯�����Ի�ǰ
var_num = sparse(N,1);      %Ŀ�꺯�����Ի���

%% ѭ������ÿ�������ģ������
for i = 1 : N
%% ȷ��tao������λ�ü���Ӧ��h,k����ʾ����A

    if(history == 1)   %1��ʾģ�ͺ���ʷ״̬��0��ʾģ�Ͳ�����ʷ״̬
        [tao_location{i},tao_num,tao_sum,tao_h,tao_k] = GetLocation_1(u0(i),L(i),U(i),Time_on_min(i),Time_off_min(i),M(i),T);
    else
        [tao_location{i},tao_num,tao_sum,tao_h,tao_k] = GetLocation_0(Time_on_min(i),M(i),T);
    end
    
%% ���Լ��

%% ���Լ������
B_wan_p_it_wan = sparse(1:T,1:T,Pmax(i) - Pmin(i));
B_wan_u_it = sparse(1:T,1:T,Pmin(i));
%B_wan{i} = [B_wan_p_it_wan,sparse(T,T),B_wan_u_it,sparse(T,var + tao_num - 3 * T)];

%% Power balance constraints ����ƽ��Լ��
    if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
        A_power_balance = sparse(T,var + tao_sum);
        A_power_balance(1:T,1:T) = (Pmax(i) - Pmin(i)) * eye(T);  %pitwan

        %uit
        if(mflag == 1)
            for t = 1 : T
                m = min(t + 1,T - M(i) + 2);
                tao = u_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                A_power_balance(t,tao) = Pmin(i);                          %tao
            end
        else
            A_power_balance(1:T,2 * T + 1 : 3 * T) = Pmin(i) * eye(T);
        end
    end

%% system spinning reserve requirement ��ת����Լ��
    A_spinning_reserve = sparse(T,var + tao_sum);
    
    %uit
    if(mflag == 1)
        for t = 1 : T
            m = min(t + 1,T - M(i) + 2);
            tao = u_tao(m,t,M(i),tao_location{i},var);                      %ȷ������tao��λ��
            A_spinning_reserve(t,tao) = -Pmax(i);                       %tao
        end
    else
        A_spinning_reserve(1 : T,2 * T + 1 : 3 * T) = -Pmax(i) * eye(T);
    end
    
    
%% ������Լ��    
%% startup cost constraint �����ɱ�Լ��
    A_start_cost = sparse(T,var + tao_sum);
    b_start_cost = sparse(T,1);
    
    for t = 1 : T   %T������ʽ
        
        A_start_cost(t,T + t) = -1;   %Sit
        
        if(mflag == 1)
            %vit
            m = max(1,t + 2 - M(i));
            tao = v_tao(m,t,M(i),tao_location{i},var);     %ȷ��vit��Ӧ����tao��λ��
            A_start_cost(t,tao) = Cost_cold(i) - Cost_hot(i);    %tao

            %wit
            for r = max(1,t - Time_off_min(i) - Time_cold(i)) : t - 1
                m = min(r,T - M(i) + 2);
                tao = w_tao(m,r,M(i),tao_location{i},var);     %ȷ��wit��Ӧ����tao��λ��
                A_start_cost(t,tao) = -1 * (Cost_cold(i) - Cost_hot(i));    %tao
            end
        else
            A_start_cost(t,3 * T + t) = Cost_cold(i) - Cost_hot(i);    %vit
            %wit
            for r = max(1,t - Time_off_min(i) - Time_cold(i)) : t - 1
                A_start_cost(t,4 * T + r) = -1 * (Cost_cold(i) - Cost_hot(i));
            end
        end
        
        %�����ɱ�Լ���Ҷ���
        if((t - Time_off_min(i) - Time_cold(i)) <= 0 && max(0,-Time_on_off_ini(i)) < abs(t - Time_off_min(i) - Time_cold(i) - 1) + 1) %f_init = 1
            b_start_cost(t) = Cost_cold(i) - Cost_hot(i);
        else        %f_init = 0
            b_start_cost(t) = 0;
        end
        
    end
    
%% initial status of units �����ʼ״̬Լ��
    A_initial_status = [];
    b_initial_status = [];
    
    if(mflag == 1)
        
        if(history == 1 && u0(i) == 1)%��ʼ״̬Ϊ���� tao(m-1,k)֮��=1
            for m = 1 : min(U(i) + 1,T - M(i) + 2)
                initial_status = sparse(1,var + tao_sum);
                tao = u_tao(m,m - 1,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                initial_status(1,tao) = 1;    %tao
                if(any(initial_status))
                    A_initial_status = [A_initial_status;initial_status];
                    b_initial_status = [b_initial_status;1];
                end
            end
        end
        
        if (history == 0)
            for t = 0 : W(i) + L(i)
                initial_status = sparse(1,var + tao_sum);
                m = min(t + 1,T - M(i) + 2);
                tao = u_tao(m,t,M(i),tao_location{i},var);                      %ȷ������tao��λ��
                initial_status(1,tao) = 1;    %tao
                if(any(initial_status))
                    A_initial_status = [A_initial_status;initial_status];
                    b_initial_status = [b_initial_status;u0(i)];
                end
            end
        end
        
    else
        
        %uit=u0
        if (history == 1)
            A_initial_status = sparse(U(i) + L(i),var + tao_sum);
            A_initial_status(1 : U(i) + L(i),2 * T + 1 : 2 * T + U(i) + L(i)) = eye(U(i) + L(i));
            b_initial_status = sparse(repmat(u0(i),U(i) + L(i),1));
        else
            A_initial_status = sparse(W(i) + L(i),var + tao_sum);
            A_initial_status(1 : W(i) + L(i),2 * T + 1 : 2 * T + W(i) + L(i)) = eye(W(i) + L(i));
            b_initial_status = sparse(repmat(u0(i),W(i) + L(i),1));
        end
        
    end
    
%% minimum up/dowm time constraints ��С��/�ػ�ʱ��Լ��
    %��С����ʱ��Լ��
    A_min_up_time = [];
    b_min_up_time = [];
    
    for t = W (i) + 1 : T

        min_up_time = sparse(1,var + tao_sum);

        if(mflag == 1)
            if(M(i) < Time_on_min(i) + 1)
                %uit
                m = min(t + 1,T - M(i) + 2);
                tao = u_tao(m,t,M(i),tao_location{i},var);              %ȷ������tao��λ��
                min_up_time(1,tao) = -1;                          %tao

                %vit
                for r = max(0,t - Time_on_min(i)) + 1 : t
                    m = max(1,r + 2 - M(i));                
                    tao = v_tao(m,r,M(i),tao_location{i},var);     %ȷ������tao��λ��
                    min_up_time(1,tao) = min_up_time(1,tao) + 1;    %tao
                end
            end
        else
            min_up_time(1,2 * T + t) = -1;            %uit

            %vit
            for r = max(0,t - Time_on_min(i)) + 1 : t
                min_up_time(1,3 * T + r) = 1;
            end
        end

        if(any(min_up_time))
            A_min_up_time = [A_min_up_time;min_up_time];
            b_min_up_time = [b_min_up_time;0];
        end

    end
    
    %��С�ػ�ʱ��Լ��
    A_min_down_time = [];
    b_min_down_time = [];
    
    for t = L(i) + 1 : T

        min_down_time = sparse(1,var + tao_sum);

        if(mflag == 1)
            if(M(i) < Time_off_min(i) + 1)
                %uit
                m = min(t + 1,T - M(i) + 2);
                tao = u_tao(m,t,M(i),tao_location{i},var);              %ȷ������tao��λ��
                min_down_time(1,tao) = 1;                          %tao

                %wit
                for r = max(0,t - Time_off_min(i)) + 1 : t
                    m = min(r,T - M(i) + 2);                
                    tao = w_tao(m,r,M(i),tao_location{i},var);     %ȷ������tao��λ��
                    min_down_time(1,tao) = min_down_time(1,tao) + 1;    %tao
                end
            end
        else
            min_down_time(1,2 * T + t) = 1;       %uit

            %wit
            for r = max(0,t - Time_off_min(i)) + 1 : t
                min_down_time(1,4 * T + r) = 1;
            end
        end

        if(any(min_down_time))
            A_min_down_time = [A_min_down_time;min_down_time];
            b_min_down_time = [b_min_down_time;1];
        end

    end
    
%% state variables and logical constraints ��Ԫ����֮��Ĺ�ϵ
    Aineq_state = [];             %���ڸ�������tao�Ĳ���ʽ
    bineq_state = [];             %���ڸ�������tao�Ĳ���ʽ
    Aeq_state = [];               %���ڸ�������tao�ĵ�ʽ
    beq_state = [];               %���ڸ�������tao�ĵ�ʽ
    
    if(mflag == 1)
        for m = 1 : T - M(i) + 2

            for t = m - 1 : m + M(i) - 2
                %��һ��������tao֮��Ĺ�ϵ
                state = sparse(1,var + tao_sum);
                tao = tao_state(m,t,M(i),tao_location{i},var,Time_off_min(i));
                state(1,tao) = 1;    %tao
                if(any(state))
                    Aineq_state = [Aineq_state;state];
                end

                %���ڴ���tao֮��Ĺ�ϵ
                %uit 
                if (m <= T - M(i) + 1)
                    if((history == 1 && t >= max(L(i) + 1,m)) || (history == 0 && t >= m))
                        state = sparse(1,var + tao_sum);
                        tao = u_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                        state(1,tao) = 1;    %tao
                        tao = u_tao(m + 1,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                        state(1,tao) = -1;    %tao
                        if(any(state))
                            Aeq_state = [Aeq_state;state];
                        end
                    end
                end
                %vit
                if (m <= T - M(i) + 1)
                    if((history == 1 && t >= max(L(i) + 1,m + 1)) || (history == 0 && t >= m + 1))
                        state = sparse(1,var + tao_sum);
                        tao = v_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                        state(1,tao) = 1;    %tao
                        tao = v_tao(m + 1,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                        state(1,tao) = -1;    %tao
                        if(any(state))
                            Aeq_state = [Aeq_state;state];
                        end
                    end
                end
                %wit
%                 if (m <= T - M(i) + 1)
%                     if((history == 1 && t >= max(L(i) + 1,m + 1)) || (history == 0 && t >= m + 1))
%                         state = sparse(1,var + tao_sum);
%                         tao = w_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
%                         state(1,tao) = 1;    %tao
%                         tao = w_tao(m + 1,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
%                         state(1,tao) = -1;    %tao
%                         if(any(state))
%                             Aeq_state = [Aeq_state;state];
%                         end
%                     end
%                 end

            end

        end

        bineq_state = ones(size(Aineq_state,1),1);
        beq_state = sparse(size(Aeq_state,1),1);
        
    else   %mflag ~= 1
        %u1-v1+w1=u0
        %v(t) - w(t) = u(t) - u(t-1)  t��2��T
        Aeq_state = sparse(T,var + tao_sum);
        Aeq_state(1 : T,2 * T + 1 : 3 * T) = eye(T) - diag(ones(T - 1,1),-1);  %uit
        Aeq_state(1 : T,3 * T + 1 : 4 * T) = -1 * eye(T);           %vit
        Aeq_state(1 : T,4 * T + 1 : 5 * T) = eye(T);                %wit
        beq_state = [u0(i);sparse(T - 1,1)];
        
        if(mflag == 2)
            for m = 1 : T - M(i) + 2

                for t = m - 1 : m + M(i) - 2

                    %tao��u֮��Ĺ�ϵ
                    state = sparse(1,var + tao_sum);
                    tao = u_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                    state(1,tao) = 1;    %tao
                    if(t > 0)
                        state(1,2 * T + t) = -1;    %uit
                        beq_state = [beq_state;0];
                    else
                        beq_state = [beq_state;u0(i)];
                    end
                    Aeq_state = [Aeq_state;state];

                    if(t > m - 1)

                        %tao��v֮��Ĺ�ϵ
                        state = sparse(1,var + tao_sum);
                        tao = v_tao(m,t,M(i),tao_location{i},var);                 %ȷ������tao��λ��
                        state(1,tao) = 1;    %tao
                        state(1,3 * T + t) = -1;    %vit
                        Aeq_state = [Aeq_state;state];
                        beq_state = [beq_state;0];

                        %tao��w֮��Ĺ�ϵ
                        state = sparse(1,var + tao_sum);
                        tao = w_tao(m,t,M(i),tao_location{i},var);                     %ȷ������tao��λ��
                        state(1,tao) = 1;    %tao
                        state(1,4 * T + t) = -1;    %wit
                        Aeq_state = [Aeq_state;state];
                        beq_state = [beq_state;0];

                    end

                end

            end
        else    %mflag == 3
            
            vlo = cell(T - M(i) + 2,1);     %���������λ��
            B = cell(T - M(i) + 2,1);         %��Ԫ������Ĳ���ʽ���
            d = cell(T - M(i) + 2,1);         %��Ԫ������Ĳ���ʽ�Ҷ�

            [A,dbase,t_h,t_k,tbase_h,tbase_k] = BaseVariable( M(i),wflag );

            for m = 1 : T - M(i) + 2

                %��ÿ�������ڶ����tao����ת����taobase��u,v,w���������µĲ���ʽ��
                [B{m},Blo{m},vlo{m},b0{m}] = VaribleTransform( A,dbase,t_h,t_k,tbase_h,tbase_k,u0(i),M(i),wflag,T,m,tao_location{i},tao_sum,var );

                if(M(i) > 2)

                    state = -B{m};
                    b = b0{m};

                    if(drflag)   %1��ʾɾ������Ķ�Ԫ��������ʽ

                        row = size(state,1);
                        del = [];

                        for j = 1 : row      %�����ж��Ƿ�����
                            if(all(state(j,var + 1 : var + tao_sum) == 0))
                                del = [del;j];
                            end
                        end

                        state(del,:) = [];
                        b(del,:) = [];

                    end

                    Aineq_state = [Aineq_state;state];
                    bineq_state = [bineq_state;b];

                    Aineq_state = [Aineq_state;-state];
                    bineq_state = [bineq_state;ones(size(b,1),1) - b];

                end
            end
        end
        
    end
    
%% unit generation limits ����������½�Լ��
    A_generation_upper = [];
    b_generation_upper = [];
    A_generation_lower = [];
    b_generation_lower = [];
    num = 0;
    
    for m = 1 : T - M(i) + 2
        
        t1 = m - 1;
        t2 = min(Q(i),(1 - P0_wan(i)) / Pup_wan(i));
        t3 = max([(Pshut_wan(i) - P0_wan(i)) / Pup_wan(i),(Q(i) * Pdown_wan(i) + Pshut_wan(i) -P0_wan(i)) / (Pup_wan(i) + Pdown_wan(i))]);
        t4 = m + M(i) - 2;
        
        for t = m - 1 : m + M(i) - 2  
            
            generation_upper = sparse(1,var + tao_sum);
            
            b = 0;
            if(t > 0)
                generation_upper(1,t) = 1;  %Pit 
            end
            
            if (u0(i) == 0)   %��ʼ״̬�ǹػ�
                
                %�Ͻ�
                for j = 1 : tao_num(m)   %tao
                    if (tao_h{m}(j) <= t && t <= tao_k{m}(j))
                        if (tao_h{m}(j) > m - 1 && tao_k{m}(j) < m + M(i) - 2)
                            generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                        elseif (tao_h{m}(j) > m - 1 && tao_k{m}(j) == m + M(i) - 2)
                            generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);   %tao
                        elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) < m + M(i) - 2)
                            generation_upper(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                        elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) == m + M(i) - 2)
                            generation_upper(1,var + num + j) = -1;   %tao
                        end                    
                    end
                end
                
                % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                if(mflag == 3)
                    [generation_upper,b] = ModifyInequality( generation_upper,b,B{m},Blo{m},vlo{m},b0{m} );
                end
                A_generation_upper = [A_generation_upper;generation_upper];
                b_generation_upper = [b_generation_upper;b];
                
            else              %��ʼ״̬�ǿ���
                
                %�Ͻ�
                if(history == 1 && m <= U(i) + Time_off_min(i) + 1)
                    if(facet == 0 || t == t1 || t > t2 || (t3 < t && t < t4 && Q(i) < t4))
                        
                        for j = 1 : tao_num(m)   %tao
                            if (tao_h{m}(j) <= U(i) + Time_off_min(i) && tao_h{m}(j) <= t && t <= tao_k{m}(j))
                                if (tao_k{m}(j) < m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1 * min([1,P0_wan(i) + t * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                elseif (tao_k{m}(j) == m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1 * min([1,P0_wan(i) + t * Pup_wan(i)]);
                                end
                            elseif (tao_h{m}(j) > U(i) + Time_off_min(i) && tao_h{m}(j) <= t && t <= tao_k{m}(j))
                                if (tao_h{m}(j) > m - 1 && tao_k{m}(j) < m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                elseif (tao_h{m}(j) > m - 1 && tao_k{m}(j) == m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);   %tao
                                elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) < m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) == m + M(i) - 2)
                                    generation_upper(1,var + num + j) = -1;   %tao
                                end                   
                            end
                        end

                        if(t == 0)
                            b = -P0_wan(i);
                        end
                        
                        % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                        if(mflag == 3)
                            [generation_upper,b] = ModifyInequality( generation_upper,b,B{m},Blo{m},vlo{m},b0{m} );
                        end
                        A_generation_upper = [A_generation_upper;generation_upper];
                        b_generation_upper = [b_generation_upper;b];
                        
                    end
                else        %m > U(i) + Time_off_min(i) + 1 �� �����ǳ�̬
                    
                    for j = 1 : tao_num(m)   %tao
                        if (tao_h{m}(j) <= t && t <= tao_k{m}(j))
                            if (tao_h{m}(j) > m - 1 && tao_k{m}(j) < m + M(i) - 2)
                                generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                            elseif (tao_h{m}(j) > m - 1 && tao_k{m}(j) == m + M(i) - 2)
                                generation_upper(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);   %tao
                            elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) < m + M(i) - 2)
                                generation_upper(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                            elseif (tao_h{m}(j) == m - 1 && tao_k{m}(j) == m + M(i) - 2)
                                generation_upper(1,var + num + j) = -1;   %tao
                            end                    
                        end
                    end
                    
                    if(t == 0)
                        b = -P0_wan(i);
                    end
                    
                    % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                    if(mflag == 3)
                        [generation_upper,b] = ModifyInequality( generation_upper,b,B{m},Blo{m},vlo{m},b0{m} );
                    end
                    A_generation_upper = [A_generation_upper;generation_upper];
                    b_generation_upper = [b_generation_upper;b];
                    
                end
                
                %�½�
                if(history == 1 && m <= U(i) + Time_off_min(i) + 1)
                    
                    if(t < P0_wan(i)/Pdown_wan(i))
                        if(facet == 0 || t == m - 1 || t > Q(i))
                            
                            generation_lower = sparse(1,var + tao_sum);
                            
                            if(t > 0)
                                generation_lower(1,t) = -1;  %Pit 
                                b = 0;
                            else
                                b = P0_wan(i);
                            end
                            
                            for j = 1 : tao_num(m)   %tao
                                if (tao_h{m}(j) <= U(i) + Time_off_min(i) && tao_h{m}(j) <= t && t <= tao_k{m}(j))
                                    generation_lower(1,var + num + j) = P0_wan(i) - t * Pdown_wan(i);            
                                end
                            end
                            
                            % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                            if(mflag == 3)
                                [generation_lower,b] = ModifyInequality( generation_lower,b,B{m},Blo{m},vlo{m},b0{m} );
                            end
                            A_generation_lower = [A_generation_lower;generation_lower];
                            b_generation_lower = [b_generation_lower;b];
                            
                        end
                    end
                    
                end
                
            end
            
        end
        
        num = num + tao_num(m);
        
    end
        
%% Ramping constraints ��������Լ��
    A_ramp_up = [];
    b_ramp_up = [];
    A_ramp_down = [];
    b_ramp_down = [];
    
    num = 0;
    
    for m = 1 : T - M(i) + 2
        
        t1 = m + M(i) - 2;

        for t = m : t1
            %������Լ��
            if (u0(i) == 0)   %��ʼ״̬�ǹػ�
                
                for a = 1 : t - m + 1
                    
                    %��Щ������������ģ����������ڵ�������ռ��
%                     if(m < T - M(i) + 2 && a < t - m + 1)
%                         continue;
%                     end
                    
                    if(facet == 0 || a < 1 / Pup_wan(i))    
                        ramp_up = sparse(1,var + tao_sum);
                        
                        for j = 1 : tao_num(m)   %tao
                            if (tao_h{m}(j) <= t && t <= tao_k{m}(j) && (t - a) < tao_h{m}(j))
                                if (tao_k{m}(j) < m + M(i) - 2)
                                    ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                elseif (tao_k{m}(j) == m + M(i) - 2)
                                    ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);   %tao
                                end 
                            elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                if (tao_k{m}(j) < m + M(i) - 2)
                                    ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                elseif (tao_k{m}(j) == m + M(i) - 2)
                                    ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i)]);  %tao
                                end              
                            end
                        end
                        
                        ramp_up(1,t) = 1;               %Pit
                        if(a < t)
                            ramp_up(1,t - a) = -1;        %Pi(t-a)
                        end
                        
                        % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                        b = 0;
                        if(mflag == 3)
                            [ramp_up,b] = ModifyInequality( ramp_up,b,B{m},Blo{m},vlo{m},b0{m} );
                        end
                        A_ramp_up = [A_ramp_up;ramp_up];
                        b_ramp_up = [b_ramp_up;b];
                        
                    end
                    
                end
                
            else              %��ʼ״̬�ǿ���
                
                a1 = 1 / Pup_wan(i);
                a2 = min(a1,(1 - P0_wan(i) + t * Pdown_wan(i)) / (Pup_wan(i) + Pdown_wan(i)));
                a3 = min(Time_on_min(i),(1 - Pstart_wan(i)) / Pup_wan(i) + 1);
                a4 = t - U(i) - Time_off_min(i);
                a5 = min((Pshut_wan(i) + (max(t,Q(i)) - t) * Pdown_wan(i)) / Pup_wan(i),(Pshut_wan(i) + max(t,Q(i)) * Pdown_wan(i) - P0_wan(i)) / (Pup_wan(i) + Pdown_wan(i)));
                a6 = max([(Pshut_wan(i) - Pstart_wan(i)) / Pup_wan(i) + 1,((Time_on_min(i) - 1) * Pdown_wan(i) + Pshut_wan(i) -Pstart_wan(i)) / (Pup_wan(i) + Pdown_wan(i)) + 1,t + Time_on_min(i) - t1]);
                a7 = min(a1,a4);
                
                for a = 1 : t - m + 1
                    
                    %��Щ������������ģ����������ڵ�������ռ��
%                     if(m < T - M(i) + 2 && a < t - m + 1)
%                         continue;
%                     end
                    
                    if(history == 1 && m <= U(i) + Time_off_min(i) + 1)
                        if(facet == 0 || a == 1 || t > Q(i) || a > a2 || (a3 < a && a <= a4) || (max(t,Q(i)) < t1 && a > a5) || (t < t1 && a6 < a && a <= a4))
                            if(facet == 0 || a == t || a < a2 || a < a7)

                                ramp_up = sparse(1,var + tao_sum);

                                for j = 1 : tao_num(m)   %tao
                                    if (tao_h{m}(j) <= t && t <= tao_k{m}(j) && (t - a) < tao_h{m}(j))
                                        if (tao_k{m}(j) < m + M(i) - 2)
                                            ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                        elseif (tao_k{m}(j) == m + M(i) - 2)
                                            ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);  %tao
                                        end
                                    elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                        if(tao_h{m}(j) <= U(i) + Time_off_min(i))  %h <= U(i) + Time_off_min(i)
                                            if (tao_k{m}(j) < m + M(i) - 2)
                                                ramp_up(1,var + num + j) = -1 * min([1 - max(0, P0_wan(i) - (t - a) * Pdown_wan(i)),a * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i) - max(0, P0_wan(i) - (t - a) * Pdown_wan(i))]);  %tao
                                            elseif (tao_k{m}(j) == m + M(i) - 2)
                                                ramp_up(1,var + num + j) = -1 * min([1 - max(0, P0_wan(i) - (t - a) * Pdown_wan(i)),a * Pup_wan(i)]);  %tao
                                            end
                                        else  %h > U(i) + Time_off_min(i)
                                            if (tao_k{m}(j) < m + M(i) - 2)
                                                ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                            elseif (tao_k{m}(j) == m + M(i) - 2)
                                                ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i)]);  %tao
                                            end
                                        end
                                    elseif(tao_h{m}(j) <= U(i) + Time_off_min(i) && t - a >= tao_h{m}(j) && t - a <= tao_k{m}(j) && t > tao_k{m}(j))
                                        ramp_up(1,var + num + j) = max(0, P0_wan(i) - (t - a) * Pdown_wan(i));  %tao
                                    end
                                end

                                ramp_up(1,t) = 1;             %Pit

                                if(a == t)
                                    b = P0_wan(i);
                                else
                                    ramp_up(1,t - a) = -1;        %Pi(t-a)
                                    b = 0;
                                end
                                
                                % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                                if(mflag == 3)
                                    [ramp_up,b] = ModifyInequality( ramp_up,b,B{m},Blo{m},vlo{m},b0{m} );
                                end
                                
                                A_ramp_up = [A_ramp_up;ramp_up];
                                b_ramp_up = [b_ramp_up;b];
                                
                            end
                        end
                        
                    else     %m > U(i) + Time_off_min(i) + 1 �� �����ǳ�̬
                        if(facet == 0 || a < 1 / Pup_wan(i))

                            ramp_up = sparse(1,var + tao_sum);

                            for j = 1 : tao_num(m)   %tao
                                if (tao_h{m}(j) <= t && t <= tao_k{m}(j) && (t - a) < tao_h{m}(j))
                                    if (tao_k{m}(j) < m + M(i) - 2)
                                        ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                    elseif (tao_k{m}(j) == m + M(i) - 2)
                                        ramp_up(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - tao_h{m}(j)) * Pup_wan(i)]);  %tao
                                    end
                                elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                    if (tao_k{m}(j) < m + M(i) - 2)
                                        ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t) * Pdown_wan(i)]);  %tao
                                    elseif (tao_k{m}(j) == m + M(i) - 2)
                                        ramp_up(1,var + num + j) = -1 * min([1,a * Pup_wan(i)]);  %tao
                                    end
                                end
                            end
                            
                            ramp_up(1,t) = 1;             %Pit

                            if(a == t)
                                b = P0_wan(i);
                            else
                                ramp_up(1,t - a) = -1;        %Pi(t-a)
                                b = 0;
                            end
                            
                            % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                            if(mflag == 3)
                                [ramp_up,b] = ModifyInequality( ramp_up,b,B{m},Blo{m},vlo{m},b0{m} );
                            end
                            A_ramp_up = [A_ramp_up;ramp_up];
                            b_ramp_up = [b_ramp_up;b];
                            
                        end
                        
                    end
                    
                end
                
            end
            
            %������Լ��
            if (u0(i) == 0)   %��ʼ״̬�ǹػ�
                
                for a = 1 : t - m + 1
                    
                    %��Щ������������ģ����������ڵ�������ռ��
%                     if(m > 1 && t < m + M(i) - 2)
%                         continue;
%                     end
                    if(facet == 0 || a < 1 / Pdown_wan(i))
                        
                        ramp_down = sparse(1,var + tao_sum);
                        
                        for j = 1 : tao_num(m)   %tao
                            if (tao_h{m}(j) <= (t - a) && (t - a) <= tao_k{m}(j) && t > tao_k{m}(j))
                                if (tao_h{m}(j) > m - 1)
                                    ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                elseif (tao_h{m}(j) == m - 1)
                                    ramp_down(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                end
                            elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                if (tao_h{m}(j) > m - 1)
                                    ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),a * Pdown_wan(i)]);  %tao
                                elseif (tao_h{m}(j) == m - 1)
                                    ramp_down(1,var + num + j) = -1 * min([1,a * Pdown_wan(i)]);  %tao
                                end
                            end
                        end

                        ramp_down(1,t) = -1;            %Pit
                        if(a < t)
                            ramp_down(1,t - a) = 1;        %Pi(t-a)
                        end
                        
                        % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                        b = 0;
                        if(mflag == 3)
                            [ramp_down,b] = ModifyInequality( ramp_down,b,B{m},Blo{m},vlo{m},b0{m} );
                        end
                        A_ramp_down = [A_ramp_down;ramp_down];
                        b_ramp_down = [b_ramp_down;b];
                        
                    end
                    
                end
                
            else              %��ʼ״̬�ǿ���
                
                a1 = t - U(i) - Time_off_min(i);
                a2 = min(1 / Pdown_wan(i),(P0_wan(i) + t * Pup_wan(i)) / (Pup_wan(i) + Pdown_wan(i)));
                a3 = min((1 - Pshut_wan(i)) / Pdown_wan(i) + 1,(P0_wan(i) + t * Pup_wan(i) + Pdown_wan(i) - Pshut_wan(i)) / (Pup_wan(i) + Pdown_wan(i))); 
                a4 = min([a1,1 / Pdown_wan(i),(Pstart_wan(i) + (a1 - 1) * Pup_wan(i)) / (Pup_wan(i) + Pdown_wan(i))]);
                
                for a = 1 : t - m + 1
                    
                    %��Щ������������ģ����������ڵ�������ռ��
%                     if(m > 1 && t < m + M(i) - 2)
%                         continue;
%                     end
                    
                    if(history == 1 && m <= U(i) + Time_off_min(i) + 1)
                        if(facet == 0 || a == 1 || a <= a1 || a > a2 || (U(i) < t && a > a3))
                            if(facet == 0 || a == t || a < a2 || a < a4)

                                ramp_down = sparse(1,var + tao_sum);

                                for j = 1 : tao_num(m)   %tao
                                    if (tao_h{m}(j) <= (t - a) && (t - a) <= tao_k{m}(j) && t > tao_k{m}(j))
                                        if (tao_h{m}(j) <= U(i) + Time_off_min(i))
                                            ramp_down(1,var + num + j) = -1 * min([1,P0_wan(i) + (t - a) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                        elseif (tao_h{m}(j) > U(i) + Time_off_min(i))
                                            if (tao_h{m}(j) > m - 1)
                                                ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                            elseif (tao_h{m}(j) == m - 1)
                                                ramp_down(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                            end
                                        end
                                    elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                        if (tao_h{m}(j) <= U(i) + Time_off_min(i))
                                            ramp_down(1,var + num + j) = -1 * min([1,P0_wan(i) + (t - a) * Pup_wan(i),a * Pdown_wan(i)]);  %tao
                                        elseif (tao_h{m}(j) > U(i) + Time_off_min(i))
                                            if (tao_h{m}(j) > m - 1)
                                                ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),a * Pdown_wan(i)]);  %tao
                                            elseif (tao_h{m}(j) == m - 1)
                                                ramp_down(1,var + num + j) = -1 * min([1,a * Pdown_wan(i)]);  %tao
                                            end
                                        end              
                                    end
                                end

                                ramp_down(1,t) = -1;            %Pit

                                if(a == t)
                                    b = -P0_wan(i);
                                else
                                    ramp_down(1,t - a) = 1;        %Pi(t-a)
                                    b = 0;
                                end
                                
                                % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                                if(mflag == 3)
                                    [ramp_down,b] = ModifyInequality( ramp_down,b,B{m},Blo{m},vlo{m},b0{m} );
                                end
                                A_ramp_down = [A_ramp_down;ramp_down];
                                b_ramp_down = [b_ramp_down;b];
                                
                            end
                        end
                        
                    else     %m > U(i) + Time_off_min(i) + 1 �� �����ǳ�̬
                        if(facet == 0 || a < 1 / Pdown_wan(i))

                            ramp_down = sparse(1,var + tao_sum);

                            for j = 1 : tao_num(m)   %tao
                                if (tao_h{m}(j) <= (t - a) && (t - a) <= tao_k{m}(j) && t > tao_k{m}(j))
                                    if (tao_h{m}(j) > m - 1)
                                        ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                    elseif (tao_h{m}(j) == m - 1)
                                        ramp_down(1,var + num + j) = -1 * min([1,Pshut_wan(i) + (tao_k{m}(j) - t + a) * Pdown_wan(i)]);  %tao
                                    end
                                elseif (tao_h{m}(j) + a <= t && t <= tao_k{m}(j))
                                    if (tao_h{m}(j) > m - 1)
                                        ramp_down(1,var + num + j) = -1 * min([1,Pstart_wan(i) + (t - a - tao_h{m}(j)) * Pup_wan(i),a * Pdown_wan(i)]);  %tao
                                    elseif (tao_h{m}(j) == m - 1)
                                        ramp_down(1,var + num + j) = -1 * min([1,a * Pdown_wan(i)]);  %tao
                                    end
                                end
                            end

                            ramp_down(1,t) = -1;            %Pit

                            if(a == t)
                                b = -P0_wan(i);
                            else
                                ramp_down(1,t - a) = 1;        %Pi(t-a)
                                b = 0;
                            end
                            
                            % ��tao��ϵ�����м�飬��ϵ������tao����taobase,u,v,w
                            if(mflag == 3)
                                [ramp_down,b] = ModifyInequality( ramp_down,b,B{m},Blo{m},vlo{m},b0{m} );
                            end
                            A_ramp_down = [A_ramp_down;ramp_down];
                            b_ramp_down = [b_ramp_down;b];
                            
                        end
                        
                    end
                    
                end
                
            end
            
        end
        
        num = num + tao_num(m);
        
    end
    
%% ɾ���������
    if(mflag == 3)
        lo = [];
        for m = 1 : T - M(i) + 2
            tao_sum = tao_sum - size(vlo{m},2);
            lo = [lo,vlo{m}];
        end
    end
    
%% ����������Լ��
    A_c_ineq{i} = A_spinning_reserve;
    
    if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
        A_c_eq{i} = A_power_balance;
    end
    
    %ɾ�����������Ӧ����
    if(mflag == 3)
        
        A_c_ineq{i}(:,lo) = [];
        
        if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
            A_c_eq{i}(:,lo) = [];
        end
        
    end
    
%% ������е�����Լ��
    A_s_ineq{i} = [A_start_cost;Aineq_state;A_min_up_time;A_min_down_time;A_generation_upper;A_ramp_up;A_ramp_down];
    b_s_ineq{i} = [b_start_cost;bineq_state;b_min_up_time;b_min_down_time;b_generation_upper;b_ramp_up;b_ramp_down];

    A_s_eq{i} = [Aeq_state;A_initial_status];
    b_s_eq{i} = [beq_state;b_initial_status];
    
    if(isempty(A_s_eq{i}))
        A_s_eq{i} = sparse(0,var + tao_sum);
    end
    
    %ɾ�����������Ӧ����
    if(mflag == 3)
        if(~isempty(A_s_ineq{i}))
            A_s_ineq{i}(:,lo) = [];
        end
        if(~isempty(A_s_eq{i}))
            A_s_eq{i}(:,lo) = [];
        end
    end
    
%% Ŀ�꺯�� objective
    %������
    H{i} = sparse(var + tao_sum,var + tao_sum);
    H{i}(1 : T,1 : T) = 2 * Gamma_wan(i) * eye(T);   %pit����
    
    %һ����
    f{i} = sparse(var + tao_sum,1);    
    f{i}(1 : T,1) = Beta_wan(i) * ones(T,1);  %pit����
    f{i}(T + 1 : 2 * T,1) = ones(T,1);  %Sit����
    
    if(mflag == 1)
        for t = 1 : T
            %uit
            m = min(t + 1,T - M(i) + 2);
            tao = u_tao(m,t,M(i),tao_location{i},var);                      %ȷ������tao��λ��
            f{i}(tao,1) = f{i}(tao,1) + Alpha_wan(i);                    %tao

            %vit
            m = max(1,t + 2 - M(i));
            tao = v_tao(m,t,M(i),tao_location{i},var);     %ȷ������tao��λ��
            f{i}(tao,1) = f{i}(tao,1) + Cost_hot(i);    %tao
        end
    else
        f{i}(2 * T + 1 : 3 * T,1) = Alpha_wan(i) * ones(T,1);  %uit
        f{i}(3 * T + 1 : 4 * T,1) = Cost_hot(i) * ones(T,1);  %vit
    end
    
%% �������½�
    lb{i} = sparse(var + tao_sum,1);
    ub{i} = ones(var + tao_sum,1);
    ub{i}(T + 1 : 2 * T,1) = inf * ones(T,1);   %Sit����
    
%% ��������
    ctype{i} = '';
    ctype{i}(1,1 : 2 * T) = 'C';              %pit����,Sit����
    ctype{i}(1,2 * T + 1 : var + tao_sum) = 'B';         %tao
    
%% ÿ������ԭʼ�����ĸ���
    var_num(i,1) = size(ctype{i},2);
    
%% Ŀ�꺯�����Ի�
    if (boolean_MILP == 1)       %1��ʾĿ�꺯�����Ի�����ģ�͵�Ŀ�꺯���������Ի�����
        
        %ԭģ�ͱ��� variable = {'PitWan','C',T;'SitWan','C',T;'uit','B',T;'vit','B',T;'wit','B',T;'taoit','B',tao_sum};    %var + tao_sum������
        %��ģ�ͱ��� variable = {'PitWan','C',T;'SitWan','C',T;'uit','B',T;'vit','B',T;'wit','B',T;'taoit','B',tao_sum;'zit','C',T};%var + tao_sum + T������
        
        orig_H{i} = blkdiag(H{i},sparse(T,T));
        orig_f{i} = [f{i};sparse(T,1)];
        ori_var_num(i,1) = var_num(i,1);

        A_c_ineq{i} = [A_c_ineq{i},sparse(size(A_c_ineq{i},1),T)];
        if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
            A_c_eq{i} = [A_c_eq{i},sparse(size(A_c_eq{i},1),T)];
        end
        
        A_s_ineq{i} = [A_s_ineq{i},sparse(size(A_s_ineq{i},1),T)];
        A_s_eq{i} = [A_s_eq{i},sparse(size(A_s_eq{i},1),T)];
        
        for j = 0 : D
            pilwan = j / D;
            gradiant = sparse(T,ori_var_num(i,1) + T);    %�����Ĳ���ʽԼ��
            gradiant(1 : T,1 : T) = 2 * Gamma_wan(i) * pilwan * eye(T); %Pit
            gradiant(1 : T,ori_var_num(i,1) + 1 : ori_var_num(i,1) + T) = -1 * eye(T); %zit  
            A_s_ineq{i} = [A_s_ineq{i};gradiant];
            b_s_ineq{i} = [b_s_ineq{i};Gamma_wan(i) * power(pilwan,2) * ones(T,1)];
        end
        
        H{i} = [];
        f{i} = [f{i};ones(T,1)];
        
        lb{i} = [lb{i};-inf * ones(T,1)];
        ub{i} = [ub{i};inf * ones(T,1)];
        
        add_type = '';
        add_type(1,1 : T) = 'C';
        ctype{i} = strcat(ctype{i},add_type);
        var_num(i,1) = size(ctype{i},2);
    end
    
end

%% �γ�������ģ������ construct models
Aineq_c = [];
Aeq_c = [];

Aineq_s = [];
bineq_s = [];

Aeq_s = [];
beq_s = [];

Bwan = [];

model.H = [];
model.f = [];

model.lb = [];
model.ub = [];
model.ctype = [];

if(boolean_MILP == 1)
    model.orig_H = [];
    model.orig_f = [];
end

for i = 1 : N
    %�γ����������Լ������
    Bwan = [Bwan,B_wan{i}];
    % �γ������ı���Լ���������
    Aineq_c = [Aineq_c,A_c_ineq{i}];
    
    % �γ������Ĺ���ƽ��������
    if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
        Aeq_c = [Aeq_c,A_c_eq{i}];
    end
    
    % �γ������ĵ����鲻��ʽԼ���������
    Aineq_s = blkdiag(Aineq_s,A_s_ineq{i});
    % �γ������ĵ����鲻��ʽԼ�����Ҷ���
    bineq_s = [bineq_s;b_s_ineq{i}];
    
    % �γ������ĵ������ʽԼ���������
    Aeq_s = blkdiag(Aeq_s,A_s_eq{i});
    % �γ������ĵ������ʽԼ�����Ҷ���
    beq_s = [beq_s;b_s_eq{i}];
    
    model.H = blkdiag(model.H,H{i});
    model.f = [model.f;f{i}];
    
    model.lb = [model.lb;lb{i}];
    model.ub = [model.ub;ub{i}];
    model.ctype = [model.ctype,ctype{i}];
    
    if(boolean_MILP == 1)
        model.orig_H = blkdiag(model.orig_H,orig_H{i});
        model.orig_f = [model.orig_f;orig_f{i}];
    end
    
end

% �γ������Ĺ���ƽ��ͱ���Լ�����Ҷ���
%bineq_c = -PD - Spin;

if(DC_flow == 0)             %�Ƿ����ֱ��������1��ʾ�ǣ�0��ʾ��
    beq_c = PD;
end



%% ģ��
model.Aineq = Aineq_s;
model.bineq = bineq_s;

model.Aeq = [Aeq_c;Aeq_s];
model.beq = [beq_c;beq_s];
model.Bwan = Bwan;
% ÿ������ԭʼ�����ĸ���
model.ori_var_num = ori_var_num;
model.var_num = var_num;

model.N = N;
model.T = T;
model.dataUC = dataUC;
if(DC_flow == 1)
    model.NodeNum = NodeNum;
end

end




