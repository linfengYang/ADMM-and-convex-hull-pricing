%%  D_ADMM solve ED problem
function solve_DPm(pathAndFilename)

% parallel = 1;       %% parallel=0 ����ִ��  =1 ����ִ�г���
% if parallel == 1
%     poolSize =  matlabpool('size');
%     if poolSize == 0
%         matlabpool local 8
% %         matlabpool jobm2
%     end
% else
%     poolSize = matlabpool('size');
%     if poolSize > 0
%         matlabpool close
%     end
% end
tic
%%%�����ļ�����
%    pathAndFilename='UC_AF/example_2_std.mod';   
%    pathAndFilename='UC_AF/example_3_std.mod';   
   pathAndFilename='UC_AF/5_2_std.mod';   
%   pathAndFilename='UC_AF/5_std.mod';
%     pathAndFilename='UC_AF/8_std.mod';
 %    pathAndFilename='UC_AF/10_std.mod';
 %     pathAndFilename='UC_AF/10_0_1_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/75_0_1_w.mod';

%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';
%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%       pathAndFilename='UC_AF/c20_187_based_8_std.mod';
dataUC=readdataUC(pathAndFilename);
%dataUC = example('hua_2');
%dataUC.time_on_off_ini = [1;1];
DP=Model_DP_2(dataUC);
N=dataUC.N;    %������
T=dataUC.T;    %ʱ����

%���ñ������ƺ�����
      model.varnames = DP.names;
      model.vtype = DP.ctype;
      
      %����һ����ϵ��
      model.obj = DP.c;
      model.modelsense = 'min';
      
      %���ñ������½�
      %model.ub = DP.ub;
      %model.lb = DP.lb;
      %���ö�����ϵ��
      %model.Q = UC.Q_UC;
      %���ò���ʽԼ��
      model.A =DP.A;
      model.rhs = DP.b;
      model.sense(1:size(DP.A,1) - size(DP.B,1)) = '<';
      model.sense(size(DP.A,1) - size(DP.B,1) + 1:size(DP.A,1)) = '=';
      
      %��ת����׶Լ��
     Q_num = size(DP.Qrow,2)/2; k = 1;j = 2;
     for i = 1:Q_num
         model.quadcon(i).Qrow = DP.Qrow(k:j);
         model.quadcon(i).Qcol = DP.Qcol(k:j);
         model.quadcon(i).Qval = DP.Qval(k:j);
         model.quadcon(i).q  = DP.Q;
         model.quadcon(i).rhs = 0.0;
         model.quadcon(i).name = ['rot_cone',num2str(i)];
         k = k + 2;
         j = j + 2;
     end
     
     %params.QCPDual = 1;
     params.MIPGap = 0;
     
     gurobi_write(model, 'DP_2.lp');
     result = gurobi(model,params);
     x_p = 0;
     for v=1:length(DP.names(1:N*T))
     fprintf('%d  ',result.x(v));
     x_p = x_p + 1;
     if x_p == T
          fprintf('\n');
          x_p = 0;
     end
     end
     %for v=1:length(DP.names)
     %fprintf('%s %d\n',DP.names{v},result.x(v));
     %end
end
%%%% end of function