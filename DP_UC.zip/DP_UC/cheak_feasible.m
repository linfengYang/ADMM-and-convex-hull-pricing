function cheak_feasible(dataUC,model)


end