function [G1_model] = Build_simpleModel(dataUC,G1,unit_type,L)

model_i_var_num = cell(size(G1,2),1);
model_i_var_type = cell(size(G1,2),1);
model_i_var_names = cell(size(G1,2),1);
model_i_c = cell(size(G1,2),1);
model_i_Q = cell(size(G1,2),1);
model_i_Aineq = cell(size(G1,2),1);
model_i_Aeq = cell(size(G1,2),1);
model_i_bineq = cell(size(G1,2),1);
model_i_beq = cell(size(G1,2),1);
model_i_Bwan = cell(size(G1,2),1);
model_i_Qrow = cell(size(G1,2),1);
model_i_Qcol = cell(size(G1,2),1);
model_i_Qval = cell(size(G1,2),1);
model_i_ub = cell(size(G1,2),1);
model_i_lb = cell(size(G1,2),1);
model_i_soc = cell(size(G1,2),1);

model.var_num = 0; model.var_type = []; model.var_names = [];
model.obj_c = []; model.Q = []; model.Aineq = []; 
model.Aeq = []; model.Bwan = []; model.Qrow = [];
model.Qcol = []; model.Qval = []; model.ub = [];
model.lb = [];   model.soc = [];model.bineq = []; 
model.beq = []; 
%获取单个机组的凸�?
for i = 1:size(G1,2)
    j = G1(i);
    unitType = unit_type(i);
    m = Model_simple(dataUC,j,unitType,L);
    model_i_var_num{i} = m.var_num;
    model_i_var_type{i} = m.var_type;
    model_i_var_names{i} = m.var_names;
    model_i_c{i} = m.obj_c;
    model_i_Q{i} = m.Q;
    model_i_Aineq{i} = m.Aineq;
    model_i_Aeq{i} = m.Aeq;
    model_i_bineq{i} = m.bineq;
    model_i_beq{i} = m.beq;
    model_i_Bwan{i} = m.Bwan;
    model_i_ub{i} = m.ub;
    model_i_lb{i} = m.lb;
    model_i_soc{i} = m.soc;
end

%将G_1里的机组形成完整的gruobi模型
for i = 1:size(G1,2)
    model.var_num = model.var_num + model_i_var_num{i}; 
    model.var_type = [model.var_type,model_i_var_type{i}]; 
    model.var_names = [model.var_names;model_i_var_names{i}];
    model.obj_c = [model.obj_c;model_i_c{i}]; 
    model.Q = [model.Q;model_i_Q{i}]; 
    model.Aineq = blkdiag(model.Aineq,model_i_Aineq{i});
    model.Aeq = blkdiag(model.Aeq,model_i_Aeq{i});
    model.bineq = [model.bineq;model_i_bineq{i}];
    model.beq = [model.beq;model_i_beq{i}];
    model.Bwan = [model.Bwan,model_i_Bwan{i}];
    model.ub = [model.ub;model_i_ub{i}];
    model.lb = [model.lb;model_i_lb{i}];
end
G1_model = model;
end