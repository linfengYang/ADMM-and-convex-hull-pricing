function dataUC = example(flag,mul)

if strcmp(flag,'hua_1')
    dataUC.T = 1;
    dataUC.N = 2;
    dataUC.PD = 35;
    dataUC.p_low = [10;50];
    dataUC.p_up = [50;50];
    dataUC.p_startup = [50;50];
    dataUC.p_shutdown = [50;50];
    dataUC.p_rampup = [50;50];
    dataUC.p_rampdown = [50;50];
    dataUC.alpha = [0;0];
    dataUC.beta = [50;10];
    dataUC.gamma = [0;0];
    dataUC.Cold_cost = [100;100];
    dataUC.Hot_cost = [100;100];
    dataUC.fixedStartCost = [100;100];
    dataUC.Cold_hour = [0;0];
    dataUC.time_min_on = [1;1];
    dataUC.time_min_off = [1;1];
    dataUC.time_on_off_ini = [1;1];
    dataUC.p_initial = [10;50];
    dataUC.u0 = [1;1];
end

if strcmp(flag,'hua_2')
    dataUC.T = 3;
    dataUC.N = 2;
    dataUC.PD = [70;100;170];
    dataUC.p_low = [0;0];
    dataUC.p_up = [100;100];
    dataUC.RampFlag = 1;
    dataUC.iframp = [1;1];
    dataUC.p_startup = [120;60];
    dataUC.p_shutdown = [120;60];
    dataUC.p_rampup = [120;60];
    dataUC.p_rampdown = [120;60];
    dataUC.alpha = [0;600];
    dataUC.beta = [60;56];
    dataUC.gamma = [0;0];
    dataUC.Cold_cost = [0;0];
    dataUC.Hot_cost = [0;0];
    dataUC.fixedStartCost = [0;0];
    dataUC.Cold_hour = [0;0];
    dataUC.time_min_on = [1;1];
    dataUC.time_min_off = [1;1];
    dataUC.time_on_off_ini = [-1;-1];
    dataUC.p_initial = [0;0];
    dataUC.u0 = [0;0];
end
 if strcmp(flag,'Paquet_1')
     %example:Comparison between row generation, column generation and column-and-row generation for computing convex hull prices in day-ahead electricity markets
     dataUC.N = 1;
     dataUC.T = 4;
     dataUC.p_up = 16;
     dataUC.p_low = 6;
     dataUC.p_rampup = 5;
     dataUC.p_rampdown = 5;
     dataUC.p_startup = 6;
     dataUC.p_shutdown = 6;
     dataUC.time_min_on = 1;
     dataUC.time_min_off = 1;
     dataUC.alpha = 10;
     dataUC.beta = 53;
     dataUC.gamma = 0;
     dataUC.Cold_cost = 30;
     dataUC.Hot_cost = 30;
     dataUC.PD = [6,11,16,11]';
     dataUC.time_min_on = 1;
     dataUC.time_min_off = 1;
     dataUC.time_on_off_ini = -1;
     dataUC.p_initial = 0;
     dataUC.u0 = 0;
     dataUC.Cold_hour = 0;
 end
  if strcmp(flag,'10_1')
     dataUC.N = 10;
     dataUC.T = 24;
     dataUC.p_up = [455;455;162;130;130;80;85;55;55;55];
     dataUC.p_low = [150;150;25;20;20;20;25;10;10;10];
     dataUC.p_rampup = [91;91;200;200;26;16;200;200;11;11];
     dataUC.p_rampdown = [91;91;200;200;26;16;200;200;11;11];
     dataUC.p_startup = [150;150;200;200;20;20;25;10;10;10];
     dataUC.p_shutdown = [150;150;200;200;20;20;25;10;10;10];
     dataUC.alpha = [1000;970;450;680;700;370;480;660;665;670];
     dataUC.beta = [16.1900000000000;17.2600000000000;19.7000000000000;16.5000000000000;16.6000000000000;22.2600000000000;27.7400000000000;25.9200000000000;27.2700000000000;27.7900000000000];
     dataUC.gamma = [0.000480000000000000;0.000310000000000000;0.00398000000000000;0.00211000000000000;0.00200000000000000;0.00712000000000000;0.000790000000000000;0.00413000000000000;0.00222000000000000;0.00173000000000000];
     dataUC.Cold_cost = [9000;10000;1800;1120;1100;340;520;60;60;60];
     dataUC.Hot_cost = [4500;5000;900;560;550;170;260;30;30;30];
     dataUC.fixedStartCost = [4500;5000;900;560;550;170;260;30;30;30];
     dataUC.PD = [600;600;850;950;1000;1100;1150;1200;1300;1400;1450;1500;1400;1300;1200;1050;1000;1100;1200;1400;1300;1100;900;800];
     dataUC.time_min_on = [8;8;6;5;5;3;3;1;1;1];
     dataUC.time_min_off = [8;8;6;5;5;3;3;1;1;1];
     dataUC.time_on_off_ini = [8;8;6;5;5;3;3;1;1;1];
     dataUC.p_initial = [318.5;318.5;25;20;20;20;25;10;10;10];
     dataUC.u0 = [1;1;1;1;1;1;1;1;1;1];
     dataUC.Cold_hour = [5;5;4;4;4;4;2;0;0;0];
  end
   if strcmp(flag,'10_1_w')
       dataUC_i = readdataUC('UC_AF/10_1_w.mod');
       for i = 1:dataUC_i.N
           if dataUC_i.p_rampup(i) >= dataUC_i.p_up(i)&& dataUC_i.p_rampdown(i) >= dataUC_i.p_up(i)
           end
       end
       num = 0;
     
       dataUC.N = [];dataUC.T = [];dataUC.p_up = [];dataUC.p_low = [];
       dataUC.p_rampup = [];dataUC.p_rampdown = [];dataUC.p_startup = [];
       dataUC.p_startup = [];dataUC.p_shutdown = [];dataUC.alpha = [];
       dataUC.beta = [];dataUC.gamma = [];dataUC.Cold_cost = [];
       dataUC.Hot_cost = [];dataUC.fixedStartCost = [];
       dataUC.time_min_on = [];dataUC.time_min_off = [];
       dataUC.time_on_off_ini = [];dataUC.p_initial = [];
       dataUC.u0 = [];dataUC.Cold_hour = [];
       for i = 1:mul
           dataUC.N = mul * dataUC_i.N;
           dataUC.T = dataUC_i.T;
           dataUC.p_up = [dataUC.p_up;dataUC_i.p_up];
           dataUC.p_low = [dataUC.p_low;dataUC_i.p_low];
           dataUC.p_rampup = [dataUC.p_rampup;dataUC_i.p_rampup];
           dataUC.p_rampdown = [dataUC.p_rampdown;dataUC_i.p_rampdown];
           dataUC.p_startup = [dataUC.p_startup;dataUC_i.p_startup];
           dataUC.p_shutdown = [dataUC.p_shutdown;dataUC_i.p_shutdown];
           dataUC.alpha = [dataUC.alpha;dataUC_i.alpha];
           dataUC.beta = [dataUC.beta;dataUC_i.beta];
           dataUC.gamma = [dataUC.gamma;dataUC_i.gamma];
           dataUC.Cold_cost = [dataUC.Cold_cost;dataUC_i.Cold_cost];
           dataUC.Hot_cost = [dataUC.Hot_cost;dataUC_i.Hot_cost];
           dataUC.fixedStartCost = [dataUC.fixedStartCost;dataUC_i.fixedStartCost];
           dataUC.time_min_on = [dataUC.time_min_on;dataUC_i.time_min_on];
           dataUC.time_min_off = [dataUC.time_min_off;dataUC_i.time_min_off];
           dataUC.time_on_off_ini = [dataUC.time_on_off_ini;dataUC_i.time_on_off_ini];
           dataUC.p_initial = [dataUC.p_initial;dataUC_i.p_initial];
           dataUC.u0 = [dataUC.u0;dataUC_i.u0];
           dataUC.Cold_hour = [dataUC.Cold_hour;dataUC_i.Cold_hour];
       end
        dataUC.PD = mul * dataUC_i.PD;
    end
end