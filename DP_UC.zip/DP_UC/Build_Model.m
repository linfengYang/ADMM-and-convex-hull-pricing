function [Model,model_i] = Build_Model(dataUC,G3,type,N)
length = size(G3,2);
model_i.var_num = cell(length,1);
model_i.var_type = cell(length,1);
model_i.var_names = cell(length,1);
model_i.obj_c = cell(length,1);
model_i.Q = cell(length,1);
model_i.Aineq = cell(length,1);
model_i.Aeq = cell(length,1);
model_i.bineq = cell(length,1);
model_i.beq = cell(length,1);
model_i.Bwan = cell(length,1);
%model_i.Bwan_u = cell(length,1);
model_i.ub = cell(length,1);
model_i.lb = cell(length,1);


model.var_num = 0; model.var_type = []; model.var_names = [];
model.obj_c = []; model.Q = []; model.Aineq = [];
model.Aeq = []; model.Bwan = []; model.Bwan_u = []; model.Qrow = [];
model.Qcol = []; model.Qval = []; model.ub = [];
model.lb = [];model.bineq = []; model.beq = [];
%��ȡ���������͹��
for i = 1:length
    j = G3(i);
    if (strcmp(type,'DP1'))
       m = model_DP1(dataUC,j,N);
    end
    if (strcmp(type,'DP2'))
       m = model_DP2(dataUC,j,N);
    end
     if (strcmp(type,'3bin'))
       m = model_3bin(dataUC,j,N);
    end
    model_i.var_num{i} = m.var_num;
    model_i.var_type{i} = m.var_type;
    model_i.var_names{i} = m.var_names;
    model_i.obj_c{i} = m.obj_c;
    model_i.Q{i} = m.Q;
    model_i.Aineq{i} = m.Aineq;
    model_i.Aeq{i} = m.Aeq;
    model_i.bineq{i} = m.bineq;
    model_i.beq{i} = m.beq;
    model_i.Bwan{i} = m.Bwan;
    %model_i.Bwan_u{i} = m.Bwan_u;
    model_i.ub{i} = m.ub;
    model_i.lb{i} = m.lb;
end

%��G_1��Ļ����γ�������gruobiģ��
for i = 1:length
    model.var_num = model.var_num + model_i.var_num{i}; 
    model.var_type = [model.var_type,model_i.var_type{i}]; 
    model.var_names = [model.var_names;model_i.var_names{i}];
    model.obj_c = [model.obj_c;model_i.obj_c{i}]; 
    model.Q = [model.Q;model_i.Q{i}]; 
    model.Aineq = blkdiag(model.Aineq,model_i.Aineq{i});
    model.Aeq = blkdiag(model.Aeq,model_i.Aeq{i});
    model.bineq = [model.bineq;model_i.bineq{i}];
    model.beq = [model.beq;model_i.beq{i}];
    model.Bwan = [model.Bwan,model_i.Bwan{i}];
    %model.Bwan_u = [model.Bwan_u,model_i.Bwan_u{i}];
    model.ub = [model.ub;model_i.ub{i}];
    model.lb = [model.lb;model_i.lb{i}];
    
   
end


Model = model;
end