
function [DP] = Model_DP( dataUC )  %�Զ��庯��������dataUC�����qp_i

N = dataUC.N;   
T = dataUC.T;
Node_1 = cell(N,1); W_z = cell(N,1);
B_wan_E = cell(N,1); Node = cell(N,1);
B_wan = cell(N,1);
%Node���鳤�ȣ��ȱ���y_h_k�ĸ���
Node_len_y = cell(N,1);

%����p_h_k_i_t,z_h_k_i_t�ĸ���
sum_t = cell(N,1);

%ԭʼ���֮�仡�ĸ���������z_i�ĸ���
Arc_len_z = cell(N,1);

%�洢��������
ctype_p_i_t = cell(N,1); ctype_p_h_k_i_t = cell(N,1);
ctype_y_h_k =cell(N,1);  ctype_z_h_k_i_t = cell(N,1);
ctype_z_i = cell(N,1);

%�洢������
name_p_i_t = cell(N,1);  name_p_h_k_i_t = cell(N,1);
name_y_h_k = cell(N,1);  name_z_h_k_i_t = cell(N,1);
name_z_i = cell(N,1);

%�洢·��Լ������
B_y_h_k = cell(N,1);   B_z_h_k = cell(N,1);

%�洢���½�Լ������
A_p_L = cell(N,1); A_p_U = cell(N,1);
y_h_k_L = cell(N,1); y_h_k_U = cell(N,1);

%�������½�
p_i_t_u = cell(N,1);
p_i_t_h_k_u = cell(N,1);
z_i_t_h_k_u = cell(N,1);
y_h_k_u = cell(N,1);
z_h_k_u = cell(N,1);
    
varible_l = cell(N,1);
%�洢����Լ������
A_ramp_up = cell(N,1);  A_ramp_down = cell(N,1);
y_h_k_up = cell(N,1);   y_h_k_down = cell(N,1);

%�����ͣԼ��
A_p_start = cell(N,1);  A_p_shut = cell(N,1);
y_h_k_start = cell(N,1); y_h_k_shut = cell(N,1);
A_p_h_up = cell(N,1); b_p_h_up = cell(N,1);
A_p_h_down = cell(N,1);b_p_h_down = cell(N,1);

%Լ��31 
B_p_i_t = cell(N,1);   B_p_h_k  = cell(N,1);

%��ת����׶Լ��
row_p = cell(N,1);  col_p = cell(N,1);  val_p = cell(N,1);
row_y_z = cell(N,1); col_y_z = cell(N,1); val_y_z = cell(N,1);
Qrow = {}; Qcol = {}; Qval = {};

%����ƽ��Լ��
B_P_blance = cell(N,1); b_P_blance = cell(N,1);

%Ŀ�꺯��ϵ������
c_p_i_t = cell(N,1); c_p_h_k_i_t = cell(N,1);
c_y_h_k = cell(N,1); c_z_h_k_i_t = cell(N,1);
c_z_i = cell(N,1);
for i = 1:N %���ջ�����зֿ飬����������ص�Լ����Ϊһ�顣

    U_i = max(min(T,dataUC.u0(i)*(dataUC.time_min_on(i) - dataUC.time_on_off_ini(i))),0);
    L_i = max(min(T,(1 - dataUC.u0(i))*(dataUC.time_min_off(i) + dataUC.time_on_off_ini(i))),0);
    
    Node{i} = {};   %����ͼ��㼯N
    index1 = 1;
    Node{i}{index1,1} = 0;
    Node{i}{index1,2} = 0;
    index1 = index1 + 1;
    Node{i}{index1,1} = Inf;
    Node{i}{index1,2} = Inf;
    sum_t{i} = 0;  %���е�ʱ���ܺ�
    for h = 1:T                
        if dataUC.u0(i) == 0 && h >= L_i + 1
        for k = min(h + dataUC.time_min_on(i) - 1, T):T
            index1  = index1 + 1;
             Node{i}{index1,1} = h;
             Node{i}{index1,2} = k;
             sum_t{i} = sum_t{i} + (k - h + 1);
        end
        end
        if dataUC.u0(i) == 1
           if h == 1
              for k  = max(U_i,1):T
                  index1  = index1 + 1;
                  Node{i}{index1,1} = h;
                  Node{i}{index1,2} = k;
                  sum_t{i} = sum_t{i} + (k - h + 1);
             end
           else
              if  h >= dataUC.time_min_off(i) + 1
                  for k = min(h + dataUC.time_min_on(i) - 1, T):T
                      index1  = index1 + 1;
                      Node{i}{index1,1} = h;
                      Node{i}{index1,2} = k;
                      sum_t{i} = sum_t{i} + (k - h + 1);
                  end
              end
           end
        end 
    end
    
    Node_len_1 = length(Node{i}) - 2; %N1�ڵ㼯�ĳ��ȡ�
    Node_len_y{i} = Node_len_1;
    Node_1{i} = Node{i};     %N1��㼯
    
   
    for h = 3:Node_len_1 + 2      %������չͼ�ڵ㼯N_wan
        index1 = index1 + 1;
        Node{i}{index1,1} = -Node{i}{h,1};
        Node{i}{index1,2} = -Node{i}{h,2};
    end
    
    Arc = {};   %��������
    index1 = 1;
    Arc1 = {};                                                   
    for p = 3:Node_len_1 + 2  %����A1����
        for j = 3:Node_len_1 + 2
            k = Node_1{i}{p,2};
            r = Node_1{i}{j,1};
            if r >= k + dataUC.time_min_off(i) + 1 
                Arc1{index1,1} = Node_1{i}{p,1};
                Arc1{index1,2} = k;
                Arc1{index1,3} = r;
                Arc1{index1,4} = Node_1{i}{j,2};
                index1 = index1 + 1; 
            end         
        end
    end 
    
    W_z{i} = [W_z{i};dataUC.Hot_cost(i) * ones(size(Arc1,1),1)];
    
    Arc2 = {}; 
    index1 = 1;
    for p = 3:Node_len_1 + 2  %����A2����
        if dataUC.u0(i) == 1
            if Node{i}{p,1} == 1 
                Arc2{index1,1} = 0;
                Arc2{index1,2} = 0;
                Arc2{index1,3} = Node_1{i}{p,1};
                Arc2{index1,4} = Node_1{i}{p,2};
                index1 = index1 + 1;
            end 
        end
    end
    W_z{i} = [W_z{i};zeros(size(Arc2,1),1)];
    
    Arc3 = {};
    index1 = 1;
    
    for p = 3:Node_len_1 + 2   %����A3����
        if dataUC.u0(i) == 0
            if Node_1{i}{p,1} >= L_i + 1
                Arc3{index1,1} = 0;
                Arc3{index1,2} = 0;
                Arc3{index1,3} = Node_1{i}{p,1};
                Arc3{index1,4} = Node_1{i}{p,2};
                 index1 = index1 + 1;
            end
        end
    end
    
    W_z{i} = [W_z{i};dataUC.Hot_cost(i) * ones(size(Arc3,1),1)];
    
    Arc4 = {};
    index1 = 1;
    for p = 1:Node_len_1 + 2    %����A4����
        if Node_1{i}{p,1} ~= Inf
           Arc4{index1,1} = Node_1{i}{p,1};
           Arc4{index1,2} = Node_1{i}{p,2};
           Arc4{index1,3} = Inf;
           Arc4{index1,4} = Inf;
           index1 = index1 + 1;
        end
    end
    
    W_z{i} = [W_z{i};zeros(size(Arc4,1),1)];
    Arc_wan = cell(Node_len_1,4); %������չ����
    p = Node_len_1 + 2;
    index1 = 1;
    for h = 3:Node_len_1 + 2
        p = p + 1;
        Arc_wan{index1,1} = Node{i}{h,1};
        Arc_wan{index1,2} = Node{i}{h,2};
        Arc_wan{index1,3} = Node{i}{p,1};
        Arc_wan{index1,4} = Node{i}{p,2};
        index1 = index1 + 1;
    end
    
    for p = 1:size(Arc1,1)   %�޸�A1����
        Arc1{p,1} = -Arc1{p,1};
        Arc1{p,2} = -Arc1{p,2};
    end
    
    for p = 1:size(Arc4,1)    %�޸�A4����
        Arc4{p,1} = -Arc4{p,1};
        Arc4{p,2} = -Arc4{p,2};
    end
    
    Original_Arc = [Arc1;Arc2;Arc3;Arc4];
    Arc_len_original = size(Original_Arc,1);
    Arc_len_z{i} = Arc_len_original;
    Arc = [Arc_wan;Original_Arc];
    
    
    %������������ [p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i] ��������
    ctype_p_i_t{i}(1:T) = 'C';
    ctype_p_h_k_i_t{i}(1:sum_t{i}) = 'C';
    ctype_y_h_k{i}(1:Node_len_1) = 'C';
    ctype_z_h_k_i_t{i}(1:sum_t{i}) = 'C';
    ctype_z_i{i}(1:Arc_len_original) = 'C';
   
    %�����������ƣ�[p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i]
    name_p_i_t{i} = cell(T,1); %��������p_i_t
    for p = 1:length(name_p_i_t{i})
           name_p_i_t{i}{p} = ['p',num2str(i),',',num2str(p)];
    end
    
    name_p_h_k_i_t{i} = cell(sum_t{i},1);  %��������p_h_k_i_t
    index1 = 1;
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        for t1 = h:k
            name_p_h_k_i_t{i}{index1} = ['p',num2str(h),',',num2str(k),'_',num2str(i),',',num2str(t1)];
            index1 = index1 + 1;
        end
    end
    
    name_y_h_k{i} = cell(Node_len_1,1); %��������y_h_k
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        name_y_h_k{i}{p - 2} = ['y',num2str(h),',',num2str(k),'_',num2str(i)];
    end
    
    
    name_z_h_k_i_t{i} = cell(sum_t{i},1);   %��������z_h_k_i_t
    index1 = 1;
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        for t1 = h:k
            name_z_h_k_i_t{i}{index1} = ['z',num2str(h),',',num2str(k),'_',num2str(i),',',num2str(t1)];
            index1 = index1 + 1;
        end
    end
    
    name_z_i{i} = cell(Arc_len_original,1); %��������z_i
    for p = 1:Arc_len_original
        s_1 = Original_Arc{p,1};
        s_2 = Original_Arc{p,3};
        d_1 = Original_Arc{p,2};
        d_2 = Original_Arc{p,4};
        if s_1 == 0 
            name_z_i{i}{p} = ['z',num2str(i),'_','s',',','s','->',num2str(s_2),',',num2str(d_2)];
        else
        if s_2 == Inf
            name_z_i{i}{p} = ['z',num2str(i),'_',num2str(s_1),',',num2str(d_1),'->','d',',','d'];
        else
           name_z_i{i}{p} = ['z',num2str(i),'_',num2str(s_1),',',num2str(d_1),'->',num2str(s_2),',',num2str(d_2)];
        end
        end
    end
    %·��Լ��
    B_y_h_k{i} = sparse(length(Node{i}),Node_len_1);
    B_z_h_k{i} = sparse(length(Node{i}),Arc_len_original);
    for p = 1:length(Node{i})
        for j = 1:size(Arc,1)
            s_1 = Arc{j,1};
            s_2 = Arc{j,2};
            d_1 = Arc{j,3};
            d_2 = Arc{j,4};
            if Node{i}{p,1} == s_1 & Node{i}{p,2} == s_2 
                 if j <= Node_len_1
                     B_y_h_k{i}(p,j) = -1;
                 else 
                     B_z_h_k{i}(p,j - Node_len_1) = -1;
                 end
            end     
            if Node{i}{p,1} == d_1 & Node{i}{p,2} == d_2       
                   if j <= Node_len_1
                     B_y_h_k{i}(p,j) = 1;
                   else 
                     B_z_h_k{i}(p,j - Node_len_1) = 1;
                   end
            end
        end
    end
   
    %·��Լ���Ҷ���
    B_wan_E{i} = zeros(length(Node{i}),1);
    B_wan_E{i}(1,1) = -1;
    B_wan_E{i}(2,1) = 1;
    
    %power balance constraint
    
    B_P_blance{i} = sparse(1:T, 1:T,1);
    

    
    %�ֲ�����Լ��
    
    %�������½�Լ��
    A_p_L{i} = sparse(sum_t{i},sum_t{i});
    A_p_U{i} = sparse(sum_t{i},sum_t{i});
    y_h_k_L{i} = sparse(sum_t{i},Node_len_1);
    y_h_k_U{i} = sparse(sum_t{i},Node_len_1);
    
    for p = 1:sum_t{i}
        A_p_L{i}(p,p) = -1;
        A_p_U{i}(p,p) = 1;       
    end
    
    index1 = 1;
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        t = k - h + 1;
        for j = 1:t
            y_h_k_L{i}(index1,p - 2) = dataUC.p_low(i);
            y_h_k_U{i}(index1,p - 2) = -dataUC.p_up(i);
            index1 = index1 + 1;
        end
    end
    
   
    
    %����Լ��
     len = 0;
     for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        for t = h:k - 1 
                len = len + 1;
        end
    end
    A_ramp_up{i} = sparse(len,sum_t{i});
    A_ramp_down{i} = sparse(len,sum_t{i});
    y_h_k_up{i} = sparse(len,Node_len_1);
    y_h_k_down{i} = sparse(len,Node_len_1);
    
    index1 = 1; index2 = 1; index3 = 1;
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        for t = h:k - 1 
               A_ramp_up{i}(index1,index2) = -1;
               A_ramp_up{i}(index1,index2 + 1) = 1;
               A_ramp_down{i}(index1,index2) = 1;
               A_ramp_down{i}(index1,index2 + 1) = -1;
       
               y_h_k_up{i}(index1,index3) = -dataUC.p_rampup(i);
               y_h_k_down{i}(index1,index3) = -dataUC.p_rampdown(i); 
               index1 = index1 + 1;
               index2 = index2 + 1;
        end
        index2 = index2 + 1;
        index3 = index3 + 1;
        
    end
    
   
    %�����ͣ����
    row = 0;
    for p = 3:Node_len_1 + 2
        k = Node_1{i}{p,2};
        if k ~= T
            row = row + 1;
        end
    end
    A_p_start{i} = sparse(Node_len_1,sum_t{i});
    A_p_shut{i} = sparse(row,sum_t{i});
    y_h_k_start{i} = sparse(Node_len_1,Node_len_1);
    y_h_k_shut{i} = sparse(row,Node_len_1);
    
    %phk <= Pstart
    index1 = 1;index2 = 1;
    index_y = 1;
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        if h == 1 && dataUC.u0(i) == 1
            A_p_start{i}(index1,index2) = 1;
            y_h_k_start{i}(index1,index_y) = -dataUC.p_initial(i) - dataUC.p_rampup(i);
            index1 = index1 + 1;
            A_p_start{i}(index1,index2) = -1;
            y_h_k_start{i}(index1,index_y) = dataUC.p_initial(i) - dataUC.p_rampdown(i);
            index1 = index1 + 1;
            index_y = index_y + 1;
            index2 = index2 + k - h + 1;
        else
            A_p_start{i}(index1,index2) = 1;
            y_h_k_start{i}(index1,index_y) = -dataUC.p_startup(i);
            index1 = index1 + 1; 
            index_y = index_y + 1;
            index2 = index2 + k - h + 1;
        end
        
    end
    
    % phk <= Pshut
    index1 = 1;
    index2 = 0;
    index_y = 1;
    for p = 3:Node_len_1 + 2 
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        index2 = index2 + (k - h + 1);
        if k ~= T
           A_p_shut{i}(index1,index2) = 1;
           y_h_k_shut{i}(index1,index_y) = -dataUC.p_shutdown(i);
           index1 = index1 + 1;
        end
        index_y = index_y + 1;
    end
    
    %Լ����31��
    
    B_p_i_t{i} = diag(ones(T,1));
    B_p_h_k{i} = sparse(T,sum_t{i});
    
    for p = 1:T
        index1 = 1;
        for j = 3:Node_len_1 + 2
            h = Node_1{i}{j,1};
            k = Node_1{i}{j,2};
            for t = h:k
                if t == p
                   B_p_h_k{i}(p,index1) = -1;
                end
                index1 = index1 + 1;
            end
        end
    end

    
   %��������ϵ������
   w_z_i = zeros(Arc_len_original,1);
   index = 1;
   for  p = 1:size(Arc1,1)
        k = Arc1{p,2};
        r = Arc1{p,3};
        t = r + k - 1;
        if t <= (dataUC.time_min_off(i) + dataUC.Cold_hour(i))
            w_z_i(index) = dataUC.Hot_cost(i);
        else
            w_z_i(index) = dataUC.Cold_cost(i);
        end
        index = index + 1;
   end
   index = index + size(Arc2,1);
   for  p = 1:size(Arc3,1)
        r = Arc3{p,3};
        t = r - dataUC.time_on_off_ini(i) - 1;
        if t <= (dataUC.time_min_off(i) + dataUC.Cold_hour(i))
            w_z_i(index) = dataUC.Hot_cost(i);
        else
            w_z_i(index) = dataUC.Cold_cost(i);
        end
        index = index + 1;
   end
       
       
   %Ŀ�꺯��
   c_p_i_t{i} = zeros(T,1);
    c_p_h_k_i_t{i} = dataUC.beta(i) * ones(sum_t{i},1);
    c_z_h_k_i_t{i} = dataUC.gamma(i) * ones(sum_t{i},1);
    c_y_h_k{i} = ones(Node_len_1,1);
    for p = 3:Node_len_1 + 2
        h = Node_1{i}{p,1};
        k = Node_1{i}{p,2};
        c_y_h_k{i}(p - 2) = dataUC.alpha(i)*(k - h + 1);
    end
    c_z_i{i} = w_z_i .* ones(Arc_len_original,1);
    var_length = T + Node_len_y{i} + 2*sum_t{i} + Arc_len_z{i};
    %���Լ��
    B_wan{i} = sparse(1:T,1:T,1);
    %�������½�
    p_i_t_u{i} = inf*ones(T,1);
    p_i_t_h_k_u{i} = inf*ones(sum_t{i},1);
    z_i_t_h_k_u{i} = inf*ones(sum_t{i},1);
    y_h_k_u{i} = ones(Node_len_y{i},1);
    z_h_k_u{i} = ones(Arc_len_z{i},1);
    
    varible_l{i} = zeros(var_length,1);
    
end


%����������QCPģ�Ͳ���
%����������
yhk_num = 0; phk_num = 0; zi_num = 0;
DP.ctype = [];DP.names = [];DP.B = []; DP.b = [];DP.Qrow = [];
DP.Qcol = []; DP.Qval = []; DP.Q = []; DP.c = []; DP.c_B_wan = [];

ctype_phkit = '';ctype_yhk = '';ctype_zhkit = '';
ctype_zi = ''; ctype_pit = '';


name_pit = [];  name_phkit = [];  name_yhk = [];  name_zhkit = [];  
name_zi = [];   Bwan = [];  

B_yhk = [];   B_zhk = [];
B_pit = [];   B_phk = [];
B_Pblance = [];
A_pL = []; A_pU = []; y_hkL = []; y_hkU = [];
A_rampup = [];  A_rampdown = []; y_hkup = [];   y_hkdown = [];
A_pstart = []; A_pshut = [];y_hkstart = []; y_hkshut = [];
A_phup = []; A_phdown  = []; 
b_Pblance = []; b_phup = []; b_phdown = []; b_E = []; 

c_pit = []; c_phkit = [];c_yhk = []; c_zhkit = [];c_zi = [];

row_p = [];col_p = []; val_p = [];
row_yz = []; col_yz = []; val_yz = [];

pit_up = []; pithk_up = []; zithk_up = [];yhk_up = []; zhk_up = [];
var_low = [];

sum_Node = [];
for i = 1:N
%Node���鳤�ȣ��ȱ���y_h_k�ĸ���
yhk_num = yhk_num+ Node_len_y{i};
%����p_h_k_i_t,z_h_k_i_t�ĸ���
phk_num = phk_num + sum_t{i};
%ԭʼ���֮�仡�ĸ���������z_i�ĸ���
zi_num = zi_num + Arc_len_z{i};

%�ϲ��������½�
pit_up = [pit_up;p_i_t_u{i}]; pithk_up = [pithk_up;p_i_t_h_k_u{i}]; 
zithk_up = [zithk_up;z_i_t_h_k_u{i}];yhk_up = [yhk_up;y_h_k_u{i}]; 
zhk_up = [zhk_up;z_h_k_u{i}];

var_low = [var_low;varible_l{i}];

%�ϲ���������
ctype_pit = [ctype_pit,ctype_p_i_t{i}];
ctype_phkit = [ctype_phkit,ctype_p_h_k_i_t{i}];
ctype_yhk = [ctype_yhk,ctype_y_h_k{i}];  
ctype_zhkit = [ctype_zhkit,ctype_z_h_k_i_t{i}];
ctype_zi = [ctype_zi,ctype_z_i{i}];

%�ϲ�������
name_pit = [name_pit;name_p_i_t{i}];  
name_phkit = [name_phkit;name_p_h_k_i_t{i}];  
name_yhk = [name_yhk;name_y_h_k{i}];  
name_zhkit = [name_zhkit;name_z_h_k_i_t{i}];  
name_zi = [name_zi;name_z_i{i}]; 


%�ϲ�·��Լ������
B_yhk = blkdiag(B_yhk,B_y_h_k{i});
B_zhk = blkdiag(B_zhk,B_z_h_k{i});
b_E = [b_E;B_wan_E{i}];

%�ϲ����½�Լ������
A_pL = blkdiag(A_pL,A_p_L{i}); A_pU = blkdiag(A_pU,A_p_U{i});
y_hkL = blkdiag(y_hkL,y_h_k_L{i}); y_hkU = blkdiag(y_hkU,y_h_k_U{i});

%�ϲ�����Լ������
A_rampup = blkdiag(A_rampup,A_ramp_up{i});  A_rampdown = blkdiag(A_rampdown,A_ramp_down{i});
y_hkup = blkdiag(y_hkup,y_h_k_up{i});   y_hkdown =  blkdiag(y_hkdown, y_h_k_down{i});


%�ϲ������ͣԼ��
A_pshut = blkdiag(A_pshut,A_p_shut{i});
y_hkshut = blkdiag(y_hkshut,y_h_k_shut{i});
A_phup = blkdiag(A_phup,A_p_h_up{i}); b_phup = [b_phup;b_p_h_up{i}];
A_phdown = blkdiag(A_phdown,A_p_h_down{i});b_phdown = [b_phdown;b_p_h_down{i}];
A_pstart = blkdiag(A_pstart,A_p_start{i}); 
y_hkstart = blkdiag(y_hkstart,y_h_k_start{i}); 
    
%�ϲ�Լ��31 
B_pit = blkdiag(B_pit,B_p_i_t{i});   B_phk  = blkdiag(B_phk,B_p_h_k{i});

%�ϲ�����ƽ��Լ��
B_Pblance = [B_Pblance,B_P_blance{i}];

%�ϲ�Ŀ�꺯��ϵ��
c_pit = [c_pit;c_p_i_t{i}]; c_phkit = [c_phkit;c_p_h_k_i_t{i}];
c_yhk = [c_yhk;c_y_h_k{i}]; c_zhkit = [c_zhkit;c_z_h_k_i_t{i}];
c_zi = [c_zi;c_z_i{i}];

%�ϲ����Node
sum_Node = [sum_Node;Node_1{i}];

%�ϲ����Լ��
Bwan = [Bwan,B_wan{i}];
end

%��ת����׶����Լ��
Qrow = []; Qcol = []; Qval = []; index_p = N*T; index_y =  N*T + phk_num;
index_z = N*T + phk_num + yhk_num; index = 1;
for p = 1:size(sum_Node,1)
    h = sum_Node{p,1};
    k = sum_Node{p,2};
   if h ~= 0 && k ~= Inf
      for t = h:k
          Qrow(index) = index_p + 1;
          Qcol(index) = index_p + 1;
          Qval(index) = 1;
          index = index + 1;
          Qrow(index) = index_y + 1;
          Qcol(index) = index_z + 1;
          Qval(index) = -1;
          index = index + 1;
          index_p = index_p + 1;
          index_z = index_z + 1;
      end
      index_y = index_y + 1;
   end
       
    
end

%Qrow = [row_p,row_yz];
%Qcol = [col_p,col_yz];
%Qval = [val_p,val_yz];
   

%�����ܳ���
var_num = N*T + yhk_num + 2*phk_num + zi_num;

DP.ctype = [ctype_pit,ctype_phkit,ctype_yhk,ctype_zhkit,ctype_zi];
DP.names = [name_pit;name_phkit;name_yhk;name_zhkit;name_zi];

B_E = [sparse(size(B_yhk,1),N*T),sparse(size(B_yhk,1),phk_num),B_yhk,sparse(size(B_yhk,1),phk_num),B_zhk]; 
B_blance = [B_Pblance,sparse(size(B_Pblance,1),var_num - size(B_Pblance,2))];
B_p_31 = [B_pit,B_phk,sparse(size(B_pit,1),yhk_num),sparse(size(B_pit,1),phk_num),sparse(size(B_pit,1),zi_num)];

constraint_p_L = [sparse(size(A_pL,1),N*T),A_pL,y_hkL,sparse(size(A_pL,1),phk_num),sparse(size(A_pL,1),zi_num)]; 
constraint_p_U = [sparse(size(A_pU,1),N*T),A_pU,y_hkU,sparse(size(A_pU,1),phk_num),sparse(size(A_pU,1),zi_num)]; 
constraint_p_ramp_up = [sparse(size(A_rampup,1),N*T),A_rampup,y_hkup,sparse(size(A_rampup,1),phk_num),sparse(size(A_rampup,1),zi_num)]; 
constraint_p_ramp_down = [sparse(size(A_rampdown,1),N*T),A_rampdown,y_hkdown,sparse(size(A_rampdown,1),phk_num),sparse(size(A_rampdown,1),zi_num)];
constraint_p_start = [sparse(size(A_pstart,1),N*T),A_pstart,y_hkstart,sparse(size(A_pstart,1),phk_num),sparse(size(A_pstart,1),zi_num)];
constraint_p_shut = [sparse(size(A_pshut,1),N*T),A_pshut,y_hkshut,sparse(size(A_pshut,1),phk_num),sparse(size(A_pshut,1),zi_num)];

b_p_U = zeros(size(constraint_p_U,1),1);
b_p_L = zeros(size(constraint_p_L,1),1);
b_p_ramp_up = zeros(size(constraint_p_ramp_up,1),1);
b_p_ramp_down = zeros(size(constraint_p_ramp_down,1),1);
b_p_start = zeros(size(constraint_p_start,1),1);
b_p_shut = zeros(size(constraint_p_shut,1),1);
b_p_31 = zeros(size(B_p_31,1),1);

DP.A = [constraint_p_U;constraint_p_L;constraint_p_ramp_up;constraint_p_ramp_down;constraint_p_start;constraint_p_shut];
DP.B = [B_E;B_p_31];
DP.b = [b_p_U;b_p_L;b_p_ramp_up;b_p_ramp_down;b_p_start;b_p_shut;b_E;b_p_31];
DP.A = [DP.A;DP.B];
DP.Qrow = Qrow;
DP.Qcol = Qcol;
DP.Qval = Qval;
DP.c = [c_pit;c_phkit;c_yhk;c_zhkit;c_zi];
DP.Q = sparse(var_num,1);
DP.c_CHP = [c_phkit;c_yhk;c_zhkit;c_zi];
DP.obj_Q = sparse(var_num,var_num);
DP.c_B_wan = [Bwan,sparse(T,var_num - N*T)];
DP.ub = [pit_up;pithk_up;yhk_up;zithk_up;zhk_up];
DP.lb = var_low;
%%%% end of function
end
