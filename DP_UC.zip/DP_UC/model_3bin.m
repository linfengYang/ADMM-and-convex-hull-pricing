function model = model_3bin(dataUC,unitNum,L) %����3binUCģ��
T = dataUC.T;


%�������� Pit Sit uit dit sit
P_type(1:T) = 'C'; z_type(1:T) = 'C'; S_type(1:T) = 'C'; u_type(1:T) = 'B';
d_type(1:T) = 'B'; s_type(1:T) = 'B';

%������
P_name = cell(T,1); z_name = cell(T,1); S_name = cell(T,1); u_name = cell(T,1);
d_name = cell(T,1); s_name = cell(T,1);

for i = 1:T
    P_name{i} = ['p',num2str(unitNum),'_',num2str(i)];
    z_name{i} = ['z',num2str(unitNum),'_',num2str(i)];
    S_name{i} = ['S',num2str(unitNum),'_',num2str(i)];
    u_name{i} = ['u',num2str(unitNum),'_',num2str(i)];
    d_name{i} = ['d',num2str(unitNum),'_',num2str(i)];
    s_name{i} = ['s',num2str(unitNum),'_',num2str(i)];
end


%������ʽԼ������
%��ʼ״̬Լ��

Ui = max(min(T,dataUC.u0(unitNum)*(dataUC.time_min_on(unitNum) - dataUC.time_on_off_ini(unitNum))),0);
Li = max(min(T,(1 - dataUC.u0(unitNum))*(dataUC.time_min_off(unitNum) + dataUC.time_on_off_ini(unitNum))),0);

initial_u = sparse(Ui + Li,T);
for i = 1:Ui + Li
    initial_u(i,i) = 1;
end
beq_initial = dataUC.u0(unitNum) * ones(Ui + Li,1);

%״̬Լ��
status_s = sparse(1:T,1:T,1); status_d = sparse(1:T,1:T,-1);  status_u = sparse(T,T);

for i = 1:T
    status_u(i,i) = -1;
    if i > 1
        status_u(i,i - 1) = 1;
    end
end

beq_status = [-dataUC.u0(unitNum);zeros(T - 1,1)];

%����ƽ�����Լ��
Bwan = sparse(1:T,1:T,1);

%��ת����Լ��
Bwan_u = sparse(1:T,1:T,1);

%����ʽԼ��
%��С��ͣʱ��
L_i = dataUC.time_min_on(unitNum);
E_i = dataUC.time_min_off(unitNum);
startup_s = sparse(T - Ui,T); startup_u = sparse(T - Ui,T);
shutdown_d = sparse(T - Li,T); shutdown_u = sparse(T - Li,T);

s_row = 1; u_row = 1;
for t = Ui + 1:T
    for w = max(t - L_i,0) + 1:t
        startup_s(s_row,w) = 1;
    end
    startup_u(u_row,t) = -1;
    s_row = s_row + 1;
    u_row = u_row + 1;
end
d_row = 1; u_row = 1;
for t = Li + 1:T
    for w = max(t - E_i,0) + 1:t
        shutdown_d(d_row,w) = 1;
    end
    shutdown_u(u_row,t) = 1;
    d_row = d_row + 1;
    u_row = u_row + 1;
end

beq_min_on_off = [zeros(T - Ui,1);ones(T - Li,1)];


%�������½�
p_up = sparse(1:T,1:T,1); u_up = sparse(1:T,1:T,-dataUC.p_up(unitNum));
p_low = sparse(1:T,1:T,-1); u_low = sparse(1:T,1:T,dataUC.p_low(unitNum));

bineq_up_low = zeros(2*T,1);

%����Լ��
p_rampUp = sparse(T,T); u_rampUp = sparse(T,T); s_rampUp = sparse(T,T);
p_rampDown = sparse(T,T); u_rampDown = sparse(T,T); d_rampDown = sparse(T,T);

for i = 1:T
    p_rampUp(i,i) = 1;
    u_rampUp(i,i) = -(dataUC.p_rampup(unitNum) + dataUC.p_low(unitNum));
    s_rampUp(i,i) = -(dataUC.p_startup(unitNum) - dataUC.p_rampup(unitNum) - dataUC.p_low(unitNum));
    p_rampDown(i,i) = -1;
    u_rampDown(i,i) = dataUC.p_low(unitNum);
    d_rampDown(i,i) = -(dataUC.p_shutdown(unitNum) - dataUC.p_rampdown(unitNum) - dataUC.p_low(unitNum));
    if i > 1
       p_rampUp(i,i - 1) = -1;
       u_rampUp(i,i - 1) = dataUC.p_low(unitNum);
       p_rampDown(i,i - 1) = 1;
       u_rampDown(i,i - 1) = -(dataUC.p_rampdown(unitNum) + dataUC.p_low(unitNum));
    end
end
if dataUC.u0(unitNum) == 1
    bineq_rampUp = [dataUC.p_initial(unitNum) - dataUC.p_low(unitNum);zeros(T - 1,1)];
    bineq_rampDown = [-dataUC.p_initial(unitNum) + (dataUC.p_rampdown(unitNum) + dataUC.p_low(unitNum));zeros(T - 1,1)];
else
    bineq_rampUp = zeros(T,1);
    bineq_rampDown = zeros(T,1);
end

%��������Լ��
hotCost_S = sparse(1:T,1:T,-1); hotCost_s = sparse(1:T,1:T,dataUC.Hot_cost(unitNum)); 
coldCost_S = sparse(1:T,1:T,-1); coldCost_s = sparse(1:T,1:T,dataUC.Cold_cost(unitNum)); 
coldCost_d = sparse(T,T); bineq_hot = zeros(T,1); bineq_cold = zeros(T,1);

for i = 1:T
    for tao = max(i - E_i - dataUC.Cold_hour(unitNum),1):i - 1
        coldCost_d(i,tao) = -dataUC.Cold_cost(unitNum);
    end
    if i - E_i - dataUC.Cold_hour(unitNum) <= 0 && max(-dataUC.time_on_off_ini(unitNum),0) < abs(i - E_i - dataUC.Cold_hour(unitNum) - 1) + 1
       bineq_cold(i,1) = dataUC.Cold_cost(unitNum);
    end
end

%二阶锥约�? p2 <= u*z 
Qrow = []; Qcol = []; Qval = [];
 
index_u = 2 * T + 1;
for i = 1:2*T
    if i <= T
        Qrow(i) = i;
        Qcol(i) = i;
        Qval(i) = 1;
    else
        Qrow(i) = i;
        Qcol(i) = T + i;
        Qval(i) = -1;
    end
end

%目标函数
c_u = dataUC.alpha(unitNum)*ones(T,1);
c_p = dataUC.beta(unitNum)*ones(T,1);
c_z = dataUC.gamma(unitNum)*ones(T,1);
c_S = ones(T,1);

%构建完整的单机机组gruobi模型
model.var_type = [P_type,z_type,S_type,u_type,s_type,d_type];
model.var_names = [P_name;z_name;S_name;u_name;s_name;d_name];
model.obj_c = [zeros(T,1);ones(T,1);ones(T,1);zeros(T,1);zeros(T,1);zeros(T,1)];
%model.obj_c = [c_p;c_z;c_S;c_u;zeros(T,1);zeros(T,1)];
var_num = 6*T;
model.var_num = var_num;
constraint_initial = [sparse(Ui + Li,T),sparse(Ui + Li,T),sparse(Ui + Li,T),initial_u,sparse(Ui + Li,T),sparse(Ui + Li,T)];
constraint_status = [sparse(T,T),sparse(T,T),sparse(T,T),status_u,status_s,status_d];
constraint_startUp = [sparse(T - Ui,T),sparse(T - Ui,T),sparse(T - Ui,T),startup_u,startup_s,sparse(T - Ui,T)];
constraint_shutDown = [sparse(T - Li,T),sparse(T - Li,T),sparse(T - Li,T),shutdown_u,sparse(T - Li,T),shutdown_d];
constraint_up = [p_up,sparse(T,T),sparse(T,T),u_up,sparse(T,T),sparse(T,T)];
constraint_low = [p_low,sparse(T,T),sparse(T,T),u_low,sparse(T,T),sparse(T,T)];
constraint_rampUp = [p_rampUp,sparse(T,T),sparse(T,T),u_rampUp,s_rampUp,sparse(T,T)];
constraint_rampDown = [p_rampDown,sparse(T,T),sparse(T,T),u_rampDown,sparse(T,T),d_rampDown];
constraint_hotCost = [sparse(T,T),sparse(T,T),hotCost_S,sparse(T,T),hotCost_s,sparse(T,T)];
constraint_coldCost = [sparse(T,T),sparse(T,T),coldCost_S,sparse(T,T),coldCost_s,coldCost_d];

model.Aineq = [constraint_startUp;constraint_shutDown;constraint_up;constraint_low;constraint_rampUp;constraint_rampDown;constraint_hotCost;constraint_coldCost];
model.Aeq = [constraint_initial;constraint_status];
% model.Aineq = [constraint_up;constraint_low];
% model.Aeq = constraint_status;
% model.bineq = bineq_up_low;
% model.beq = beq_status;
model.bineq = [beq_min_on_off;bineq_up_low;bineq_rampUp;bineq_rampDown;bineq_hot;bineq_cold];
model.beq = [beq_initial;beq_status];

%目标函数线�?�化
for i = 0:L
     pil = dataUC.p_low(unitNum) + i * (dataUC.p_up(unitNum) - dataUC.p_low(unitNum)) / L;
     gradiant = sparse(T,var_num);
     gradiant(1:T,1:T) = (2 * dataUC.gamma(unitNum)*pil + dataUC.beta(unitNum)) * eye(T); %pit
     gradiant(1:T,3*T + 1:4*T) = (dataUC.alpha(unitNum) - dataUC.gamma(unitNum) * power(pil,2)) * eye(T); %uit
     gradiant(1:T,T + 1:2*T) = -1 * eye(T); %zit
     b_linear = zeros(T,1);
     model.Aineq = [model.Aineq;gradiant];
     model.bineq = [model.bineq;b_linear];
end
model.Q = sparse(var_num,1);
model.Bwan = [Bwan,sparse(T,var_num - T)];
model.Bwan_u = [sparse(T,3*T),Bwan_u,sparse(T,2*T)];
model.Qrow = [];
model.Qcol = [];
model.Qval = [];
model.lb = [-inf*ones(3*T,1);zeros(3*T,1)];
model.ub = [inf*ones(3*T,1);ones(3*T,1)];
model.soc = 1;