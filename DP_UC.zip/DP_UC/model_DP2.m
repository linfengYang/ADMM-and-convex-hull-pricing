
function [DP] = model_DP2(dataUC,unitNum,N)  %An Extended Integral Unit Commitment Formulation and an Iterative Algorithm for Convex Hull Pricing - Yanan Yu 
                                      %�����е�ģ��  
T = dataUC.T;

 
s0 = dataUC.time_on_off_ini(unitNum);  %����ĳ�ʼ״̬
L = dataUC.time_min_on(unitNum);   %��С����ʱ��
e = dataUC.time_min_off(unitNum);  %��С�ػ�ʱ��
t0 = max((L - s0),0);   %�ӵ�һ��ʱ�̿�ʼ�������ٻ�Ҫ������ʱ��
L_t = L; e_t = e;
k_init = [];
length_w_k = 0;
index = 1;
for k = t0:T  %�������Ӽ�
    k_init(index) = k;
    index = index + 1;
    length_w_k = length_w_k + 1;
end
T_K_1 = {};
T_K_2 = {};
length_T_K_1 = 0;
length_T_K_2 = 0;
num_T_K_1 = 0;
num_T_K_2 = 0;
index = 1;

t = t0 + 1;
if t0 ~= 0
     t = t0;
end
for k = t:T  %����T_K_1����
    T_K_1{index,1} = 1;
    T_K_1{index,2} = k;
    index = index + 1;
    length_T_K_1 = length_T_K_1 + k;
    num_T_K_1 = num_T_K_1 + 1;
end
index = 1;
for t = t0 + e_t + 1:T  %����T_K_2����
    for k = min(t + L_t - 1,T):T
        T_K_2{index,1} = t;
        T_K_2{index,2} = k;
        index = index + 1;
        length_T_K_2 = length_T_K_2 + k - t + 1;
        num_T_K_2 = num_T_K_2 + 1;
    end
end
length_T_K = length_T_K_1 + length_T_K_2;
T_K = [T_K_1;T_K_2];
num_T_K = num_T_K_1 + num_T_K_2;

K_T_1 = {};
length_K_T_1 = 0;
num_K_T_1 = 0;
index = 1;
for k = t0:min(T - e_t - 1,T)
    for t = k + e_t + 1:T
        K_T_1{index,1} = k;
        K_T_1{index,2} = t;
        index = index + 1;
        length_K_T_1 = length_K_T_1 + t - k + 1;
        num_K_T_1 = num_K_T_1 + 1;
    end
end
        
K_T = K_T_1;
length_K_T = length_K_T_1;

xita = sparse(max(T - t0,0),1);
length_xita = max(T - t0,0);
index = 1;
for p = t0:max(T - 1,0)
    xita(index) = p;
    index = index + 1;
end
%��ʽԼ��15b��15c��15d

%15b
w_k_b = sparse(1,1:length_w_k,1);
b_w_k_b = 1;

%����ƽ��Լ��
%B_P_blance = sparse(1:T, 1:T,1);
p_i_t_blance = diag(ones(T,1));
q_s_t_k_blance = sparse(T,length_T_K);
for p = 1:T
    index = 1;
    for j = 1:num_T_K
        t = T_K{j,1};
        k = T_K{j,2};
        for s = t:k
            if s == p
                q_s_t_k_blance(p,index) = -1;
            end
            index = index + 1;
        end
    end
end

%15c
w_k_c = sparse(max(T - t0,0),length_w_k); 
z_t_k_c = sparse(max(T - t0,0),num_K_T_1);
y_k_t_c = sparse(max(T - t0,0),num_T_K_2);
xita_t_c = sparse(max(T - t0,0),length_xita);
index = 1; index_x = 1;   
for p = t0:T - 1
    for s = 1:length_w_k
        t = k_init(s);
        if p == t
           w_k_c(index,s)  = -1;
           break;
        end
    end
    for s = 1:num_K_T_1
        t = K_T{s,1};
        if t == p
            z_t_k_c(index,s) = 1;
        end
    end
    for s = 1:num_T_K_2
        t = T_K_2{s,2};
        if t == p
            y_k_t_c(index,s) = -1;
        end
    end
    if index_x <= length_xita
       if  p ~= xita(index_x)
           break;
       else
           xita_t_c(index,index_x) = 1;
           index_x = index_x  + 1;
       end
    end
        
    index = index + 1;
end

%15d
y_t_k_d = sparse(max(T - t0 - e_t,0),num_T_K_2);  
z_k_t_d = sparse(max(T - t0 - e_t,0),num_K_T_1);
row_1 = 1; 
row_2 = 1; 
for s = t0 + e_t + 1:T
    col_1 = 1;col_2 = 1;
    for p = 1:num_T_K_2
        t = T_K_2{p,1};
        if s == t
           y_t_k_d(row_1,col_1) = 1;
           col_1 = col_1 + 1;
        else
            col_1 = col_1 + 1;
        end
    end
    row_1 = row_1 + 1;
    for p = 1:num_K_T_1
        t = K_T_1{p,2};
        if s == t
           z_k_t_d(row_2,col_2) = -1;
           col_2 = col_2 + 1;
        else
            col_2 = col_2 + 1;
        end
    end
    row_2 = row_2 + 1;
end

%���������� [w_k, y_t_k, z_k_t, xita_t, q_s_t_k, p_s_t_k] ��������
ctype_w_k(1:length_w_k) = 'B';
ctype_y_t_k(1:num_T_K_2) = 'B';
ctype_z_k_t(1:num_K_T_1) = 'B';
ctype_xita_t(1:length_xita) = 'B';
ctype_q_s_t_k(1:length_T_K) = 'C';
ctype_p_s_t_k(1:length_T_K) = 'C';
ctype_p_i_t(1:T) = 'C';

%������������ [w_k, y_t_k, z_k_t, xita_t, q_s_t_k, p_s_t_k]
name_w_k = cell(length_w_k,1);
name_y_t_k = cell(num_T_K_2,1);
name_z_k_t  = cell(num_K_T_1,1);
name_xita_t = cell(length_xita,1);
name_q_s_t_k = cell(length_T_K,1);
name_p_s_t_k = cell(length_T_K,1);
name_p_i_t = cell(T,1);

for p = 1:T
    name_p_i_t{p} = ['p','_',num2str(unitNum),'_',num2str(p)];
end

for p = 1:length_w_k
    name_w_k{p} = ['w','_',num2str(k_init(p)),'_',num2str(unitNum)];
end

for p = 1:num_T_K_2
    t = T_K_2{p,1};
    k = T_K_2{p,2};
    name_y_t_k{p} = ['y',num2str(t),'_',num2str(k),'_',num2str(unitNum)];
end

for p = 1:num_K_T_1
    k = K_T_1{p,1};
    t = K_T_1{p,2};
    name_z_k_t{p} = ['z',num2str(k),'_',num2str(t),'_',num2str(unitNum)];
end

for p = 1:length_xita
    name_xita_t{p} = ['xita','_',num2str(xita(p)),'_',num2str(unitNum)];
end

index = 1;
for p = 1:num_T_K
    t = T_K{p,1};
    k = T_K{p,2};
    for s = t:k
        name_q_s_t_k{index} = ['q','_',num2str(t),num2str(k),'_',num2str(s),'_',num2str(unitNum)];
        name_p_s_t_k{index} = ['p','_',num2str(t),num2str(k),'_',num2str(s),'_',num2str(unitNum)];
        index = index + 1;
    end
end

%15e ���½�Լ�� ���ڼ���T_K_1
q_s_t_k_up_1 = sparse(1:length_T_K_1,1:length_T_K_1,1); 
q_s_t_k_low_1 = sparse(1:length_T_K_1,1:length_T_K_1,-1); 
w_k_up_1 = sparse(length_T_K_1,length_w_k);
w_k_low_1 = sparse(length_T_K_1,length_w_k);
index1 = 1; index2 = 1;
for p = 1:num_T_K_1
    t = T_K_1{p,1};
    k = T_K_1{p,2};
    for j = index2:length_w_k
        k0 = k_init(j);
        if k0 == k
           break;
        else
           index2 = index2 + 1;    
        end
    end
    for s = t:k
        w_k_up_1(index1,index2) = -dataUC.p_up(unitNum);
        w_k_low_1(index1,index2) = dataUC.p_low(unitNum);
        index1 = index1 + 1;
    end      
end
q_s_t_k_up_1 = [q_s_t_k_up_1,sparse(size(q_s_t_k_up_1,1),length_T_K_2)];
q_s_t_k_low_1 = [q_s_t_k_low_1,sparse(size(q_s_t_k_low_1,1),length_T_K_2)];

%15f ���½�Լ�� ���ڼ���T_K_2
q_s_t_k_up_2 = sparse(1:length_T_K_2,1:length_T_K_2,1); 
q_s_t_k_low_2 = sparse(1:length_T_K_2,1:length_T_K_2,-1); 
y_t_k_up_2 = sparse(length_T_K_2,num_T_K_2);
y_t_k_low_2 = sparse(length_T_K_2,num_T_K_2);
index = 1;
for p = 1:num_T_K_2
    t = T_K_2{p,1};
    k = T_K_2{p,2};
    for s = t:k
        y_t_k_up_2(index,p) = -dataUC.p_up(unitNum);
        y_t_k_low_2(index,p) = dataUC.p_low(unitNum);
        index = index + 1;
    end      
end
q_s_t_k_up_2 = [sparse(size(q_s_t_k_up_2,1),length_T_K_1),q_s_t_k_up_2];
q_s_t_k_low_2 = [sparse(size(q_s_t_k_low_2,1),length_T_K_1),q_s_t_k_low_2];

%��������Լ�����ڼ���T_K_1
row = 0;
for p = 1:num_T_K_1
    k = T_K_1{p,2};
    if k ~= T
        row = row + 1;
    end
end
q_t_t_k_rampup_1 = sparse(row,length_T_K_1); w_k_rampup_1 = sparse(row,length_w_k); 
q_t_t_k_rampdown_1 = sparse(row,length_T_K_1); w_k_rampdown_1 = sparse(row,length_w_k); 

row_ramp_q = 1; col_ramp_q = 1;
row_ramo_w = 1; col_ramp_w = 1;
for p = 1:num_T_K_1
    t = T_K_1{p,1};
    k = T_K_1{p,2};
    for j = col_ramp_w:length_w_k
        k0 = k_init(j);
        if k0 == k
            break;
        else
            col_ramp_w = col_ramp_w + 1;
        end
    end
    q_t_t_k_rampup_1(row_ramp_q,col_ramp_q) = 1;
    w_k_rampup_1(row_ramo_w,col_ramp_w) = - dataUC.p_rampup(unitNum) - dataUC.p_initial(unitNum);
    q_t_t_k_rampdown_1(row_ramp_q,col_ramp_q) = -1;
    w_k_rampdown_1(row_ramo_w,col_ramp_w) = - dataUC.p_rampdown(unitNum) + dataUC.p_initial(unitNum);
    row_ramp_q = row_ramp_q + 1;
    col_ramp_q = col_ramp_q + k - t + 1;
    row_ramo_w  = row_ramo_w + 1;
end
q_t_t_k_rampup_1 =  [q_t_t_k_rampup_1,sparse(size(q_t_t_k_rampup_1,1),length_T_K_2)];
q_t_t_k_rampdown_1 =  [q_t_t_k_rampdown_1,sparse(size(q_t_t_k_rampdown_1,1),length_T_K_2)];


%15g ���ڼ���T_K_2����������Լ���͹ػ�����Լ��
row = 0;
for p = 1:num_T_K_2
    k = T_K_2{p,2};
    if k ~= T
        row = row + 1;
    end
end
q_t_t_k_start = sparse(num_T_K_2,length_T_K_2); y_t_k_start = sparse(num_T_K_2,num_T_K_2);
q_k_t_k_shut = sparse(row,length_T_K_2); y_t_k_shut = sparse(row,num_T_K_2);
row_start_q = 1; col_start_q = 1;
row_start_y = 1; col_start_y = 1;
row_shut_q = 1; col_shut_q = 0;
row_shut_y = 1; col_shut_y = 1;
for p = 1:num_T_K_2
    t = T_K_2{p,1};
    k = T_K_2{p,2};
    q_t_t_k_start(row_start_q, col_start_q) = 1;
    y_t_k_start(row_start_y,col_start_y) = -dataUC.p_startup(unitNum);
    row_start_q = row_start_q + 1;
    row_start_y = row_start_y + 1;
    col_start_q = col_start_q + k - t + 1;
    col_start_y = col_start_y + 1;
    
    col_shut_q = col_shut_q + k - t + 1;
    if k ~= T
       q_k_t_k_shut(row_shut_q,col_shut_q) = 1;
       y_t_k_shut(row_shut_y,col_shut_y) = -dataUC.p_shutdown(unitNum);
       row_shut_q = row_shut_q + 1;
       row_shut_y = row_shut_y + 1;
    end
    col_shut_y = col_shut_y + 1;
end
q_t_t_k_start = [sparse(size(q_t_t_k_start,1),length_T_K_1),q_t_t_k_start];
q_k_t_k_shut = [sparse(size(q_k_t_k_shut,1),length_T_K_1),q_k_t_k_shut];

%15h �ػ�����Լ�� ���ڼ���T_K_1
row = 0;
for p = 1:num_T_K_1
    k = T_K_1{p,2};
    if k ~= T && k ~= 1
        row = row + 1;
    end
end
q_k_t_k_shut_h = sparse(row,length_T_K_1); w_k_shut_h = sparse(row,length_w_k);
row_shut_q = 1; col_shut_q = 0;
row_shut_w = 1; col_shut_w = 1;
for p = 1:num_T_K_1
    t = T_K_1{p,1};
    k = T_K_1{p,2};
    if k > 1
        for j = col_shut_w:length_w_k
            k0 = k_init(j);
            if k0 == k
                break;
            else
                col_shut_w = col_shut_w + 1;
            end
        end
        col_shut_q = col_shut_q + k - t + 1;
        if k ~= T
            q_k_t_k_shut_h(row_shut_q,col_shut_q) = 1;
            w_k_shut_h(row_shut_w,col_shut_w) = -dataUC.p_shutdown(unitNum);
            row_shut_q = row_shut_q + 1;
            row_shut_w = row_shut_w + 1;
        end
    else
        col_shut_q = col_shut_q + k - t + 1;
    end
    
end
q_k_t_k_shut_h =  [q_k_t_k_shut_h,sparse(size(q_k_t_k_shut_h,1),length_T_K_2)];

%����Լ��15j�����ڼ���T_K_1
q_s_t_k_ramp_up_1 = sparse(0,length_T_K_1); w_k_ramp_up_1 = sparse(0,length_w_k);
q_s_t_k_ramp_down_1 = sparse(0,length_T_K_1); w_k_ramp_down_1 = sparse(0,length_w_k);
row_q = 1; col_q = 1; row_w = 1; col_w = 1;
if t0 == 0
    col_w = col_w + 1;
end
for p = 1:num_T_K_1
    t = T_K_1{p,1};
    k = T_K_1{p,2};
    s = t + 1;
    if s <= k
       for j = s:k
           q_s_t_k_ramp_up_1(row_q,col_q) = -1;
           q_s_t_k_ramp_up_1(row_q,col_q + 1) = 1;
           q_s_t_k_ramp_down_1(row_q,col_q) = 1;
           q_s_t_k_ramp_down_1(row_q,col_q + 1) = -1;
        
           w_k_ramp_up_1(row_w,col_w) = -dataUC.p_rampup(unitNum);
           w_k_ramp_down_1(row_w,col_w) = -dataUC.p_rampdown(unitNum);
           row_q = row_q + 1;
           col_q = col_q + 1;
           row_w = row_w + 1;
       
       end
           col_q = col_q + 1;
    else
        col_q = col_q + 1;
    end
    col_w = col_w + 1;
end
q_s_t_k_ramp_up_1 = [q_s_t_k_ramp_up_1,sparse(size(q_s_t_k_ramp_up_1,1),length_T_K_2)];
q_s_t_k_ramp_down_1 = [q_s_t_k_ramp_down_1,sparse(size(q_s_t_k_ramp_down_1,1),length_T_K_2)];



%����Լ��15k�����ڼ���T_K_2
q_s_t_k_ramp_up_2 = sparse(0,length_T_K_2); y_t_k_ramp_up_2 = sparse(0,num_T_K_2);
q_s_t_k_ramp_down_2 = sparse(0,length_T_K_2); y_t_k_ramp_down_2 = sparse(0,num_T_K_2);
row_q = 1; col_q = 1; row_y = 1; col_y = 1;
for p = 1:num_T_K_2
    t = T_K_2{p,1};
    k = T_K_2{p,2};
    s = t + 1;
    if s <= k
       for j = s:k
           q_s_t_k_ramp_up_2(row_q,col_q) = -1;
           q_s_t_k_ramp_up_2(row_q,col_q + 1) = 1;
           q_s_t_k_ramp_down_2(row_q,col_q) = 1;
           q_s_t_k_ramp_down_2(row_q,col_q + 1) = -1;
        
           y_t_k_ramp_up_2(row_y,col_y) = -dataUC.p_rampup(unitNum);
           y_t_k_ramp_down_2(row_y,col_y) = -dataUC.p_rampdown(unitNum);
           row_q = row_q + 1;
           col_q = col_q + 1;
           row_y = row_y + 1;
       end
       col_q = col_q + 1;
    else
        col_q = col_q + 1;
    end
    col_y = col_y + 1;
end
q_s_t_k_ramp_up_2 = [sparse(size(q_s_t_k_ramp_up_2,1),length_T_K_1),q_s_t_k_ramp_up_2];
q_s_t_k_ramp_down_2 = [sparse(size(q_s_t_k_ramp_up_2,1),length_T_K_1),q_s_t_k_ramp_down_2];


%�������½�
ub = [inf*ones(T,1);inf*ones(length_w_k,1);inf*ones(num_T_K_2,1);inf*ones(num_K_T_1,1);inf*ones(length_xita,1);inf*ones(length_T_K,1);inf*ones(length_T_K,1)];
lb = [-inf*ones(T,1);zeros(length_w_k,1);zeros(num_T_K_2,1);zeros(num_K_T_1,1);zeros(length_xita,1);-inf*ones(length_T_K,1);-inf*ones(length_T_K,1)];
%Ŀ�꺯��
c_w_k = zeros(length_w_k,1);
c_y_t_k_2 = zeros(num_T_K_2,1);
c_z_k_t_1 = zeros(num_K_T_1,1);
%�������
c_q_s_t_k = zeros(length_T_K,1); 
c_p_s_t_k = ones(length_T_K,1); 



%��ȥ��̬�Ŀ�������
for p = 1:num_K_T_1
    k = K_T_1{p,1};
    t = K_T_1{p,2};
    c = t - k - 1;
    if c <= (dataUC.time_min_off(unitNum) + dataUC.Cold_hour(unitNum))
       c_z_k_t_1(p) = dataUC.Hot_cost(unitNum);
    else
       c_z_k_t_1(p) = dataUC.Cold_cost(unitNum);
    end
end



%����Gruobiģ��
length_w = length_w_k;
length_y = num_T_K_2;
length_z = num_K_T_1;
length_p = length_T_K_1 + length_T_K_2;
length_q = length_T_K_1 + length_T_K_2;
length_Xita = length_xita; 
var_num = T + length_w + length_y + length_z  + length_p + length_q + length_Xita;
DP.var_num = var_num;
DP.var_type = [ctype_p_i_t,ctype_w_k,ctype_y_t_k,ctype_z_k_t,ctype_xita_t,ctype_q_s_t_k,ctype_p_s_t_k];
DP.var_names = [name_p_i_t;name_w_k;name_y_t_k;name_z_k_t;name_xita_t;name_q_s_t_k;name_p_s_t_k];
constraint_15b = [sparse(size(w_k_b,1),T),w_k_b,sparse(size(w_k_b,1),length_y),sparse(size(w_k_b,1),length_z),...
                 sparse(size(w_k_b,1),length_Xita),sparse(size(w_k_b,1),length_q),...
                 sparse(size(w_k_b,1),length_p)];
constraint_blance_1 = [p_i_t_blance,sparse(size(p_i_t_blance,1),var_num - T - length_q - length_p),...
                      q_s_t_k_blance,sparse(size(p_i_t_blance,1),length_p)];
constraint_15c = [sparse(size(xita_t_c,1),T),w_k_c,y_k_t_c,z_t_k_c,xita_t_c,sparse(size(xita_t_c,1),length_q),...
                 sparse(size(xita_t_c,1),length_p)];
constraint_15d = [sparse(size(y_t_k_d,1),T),sparse(size(y_t_k_d,1),length_w),y_t_k_d,z_k_t_d,sparse(size(y_t_k_d,1),...
                 length_Xita),sparse(size(y_t_k_d,1),length_q),sparse(size(y_t_k_d,1),length_p)];
constraint_U1_15e = [sparse(size(w_k_up_1,1),T),w_k_up_1,sparse(size(w_k_up_1,1),length_y),sparse(size(w_k_up_1,1),length_z),...
                 sparse(size(w_k_up_1,1),length_Xita),q_s_t_k_up_1,sparse(size(w_k_up_1,1),length_p)];
constraint_U2_15f = [sparse(size(y_t_k_up_2,1),T),sparse(size(y_t_k_up_2,1),length_w),y_t_k_up_2,sparse(size(y_t_k_up_2,1),length_z),...
                 sparse(size(y_t_k_up_2,1),length_Xita),q_s_t_k_up_2,sparse(size(y_t_k_up_2,1),length_p)];
constraint_L1_15e = [sparse(size(w_k_low_1,1),T),w_k_low_1,sparse(size(w_k_low_1,1),length_y),sparse(size(w_k_low_1,1),length_z),...
                 sparse(size(w_k_low_1,1),length_Xita),q_s_t_k_low_1,sparse(size(w_k_low_1,1),length_p)];
constraint_L2_15f = [sparse(size(y_t_k_low_2,1),T),sparse(size(y_t_k_low_2,1),length_w),y_t_k_low_2,sparse(size(y_t_k_low_2,1),length_z),...
                 sparse(size(y_t_k_low_2,1),length_Xita),q_s_t_k_low_2,sparse(size(y_t_k_low_2,1),length_p)];
constraint_rampup_1 = [sparse(size(w_k_rampup_1,1),T),w_k_rampup_1,sparse(size(w_k_rampup_1,1),length_y),sparse(size(w_k_rampup_1,1),length_z),...
                  sparse(size(w_k_rampup_1,1),length_Xita),q_t_t_k_rampup_1,sparse(size(w_k_rampup_1,1),length_p)];           
constraint_rampdown_1 = [sparse(size(w_k_rampdown_1,1),T),w_k_rampdown_1,sparse(size(w_k_rampdown_1,1),length_y),sparse(size(w_k_rampdown_1,1),length_z),...
                  sparse(size(w_k_rampdown_1,1),length_Xita),q_t_t_k_rampdown_1,sparse(size(w_k_rampdown_1,1),length_p)];               
constraint_15g = [sparse(size(y_t_k_start,1),T),sparse(size(y_t_k_start,1),length_w),y_t_k_start,sparse(size(y_t_k_start,1),length_z),...
                  sparse(size(y_t_k_start,1),length_Xita),q_t_t_k_start,sparse(size(y_t_k_start,1),length_p)];
constraint_15h = [sparse(size(w_k_shut_h,1),T),w_k_shut_h,sparse(size(w_k_shut_h,1),length_y),sparse(size(w_k_shut_h,1),length_z),...
                  sparse(size(w_k_shut_h,1),length_Xita),q_k_t_k_shut_h,sparse(size(w_k_shut_h,1),length_p)];
constraint_15i = [sparse(size(y_t_k_shut,1),T),sparse(size(y_t_k_shut,1),length_w),y_t_k_shut,sparse(size(y_t_k_shut,1),length_z),...
                  sparse(size(y_t_k_shut,1),length_Xita),q_k_t_k_shut,sparse(size(y_t_k_shut,1),length_p)];
constraint_U1_15j = [sparse(size(w_k_ramp_up_1,1),T),w_k_ramp_up_1,sparse(size(w_k_ramp_up_1,1),length_y),sparse(size(w_k_ramp_up_1,1),length_z),...
                 sparse(size(w_k_ramp_up_1,1),length_Xita),q_s_t_k_ramp_up_1,sparse(size(w_k_ramp_up_1,1),length_p)]; 
constraint_D1_15j = [sparse(size(w_k_ramp_down_1,1),T),w_k_ramp_down_1,sparse(size(w_k_ramp_down_1,1),length_y),sparse(size(w_k_ramp_down_1,1),length_z),...
                 sparse(size(w_k_ramp_down_1,1),length_Xita),q_s_t_k_ramp_down_1,sparse(size(w_k_ramp_down_1,1),length_p)]; 
constraint_U1_15k = [sparse(size(y_t_k_ramp_up_2,1),T),sparse(size(y_t_k_ramp_up_2,1),length_w),y_t_k_ramp_up_2,sparse(size(y_t_k_ramp_up_2,1),length_z),...
                 sparse(size(y_t_k_ramp_up_2,1),length_Xita),q_s_t_k_ramp_up_2,sparse(size(y_t_k_ramp_up_2,1),length_p)]; 
constraint_D1_15k = [sparse(size(y_t_k_ramp_down_2,1),T),sparse(size(y_t_k_ramp_down_2,1),length_w),y_t_k_ramp_down_2,sparse(size(y_t_k_ramp_down_2,1),length_z),...
                 sparse(size(y_t_k_ramp_down_2,1),length_Xita),q_s_t_k_ramp_down_2,sparse(size(y_t_k_ramp_down_2,1),length_p)];

             
b_15b = ones(size(constraint_15b,1),1);
b_15c = zeros(size(constraint_15c,1),1);
b_15d = zeros(size(constraint_15d,1),1);
b_U1_15e = zeros(size(constraint_U1_15e,1),1);
b_U2_15f = zeros(size(constraint_U2_15f,1),1);
b_L1_15e = zeros(size(constraint_L1_15e,1),1);
b_L2_15f = zeros(size(constraint_L2_15f,1),1);
b_rampup_1 = zeros(size(constraint_rampup_1,1),1);
b_rampdown_1 = zeros(size(constraint_rampdown_1,1),1);
b_15g = zeros(size(constraint_15g,1),1);
b_15h = zeros(size(constraint_15h,1),1);
b_15i = zeros(size(constraint_15i,1),1);
b_U1_15j = zeros(size(constraint_U1_15j,1),1);
b_D1_15j = zeros(size(constraint_D1_15j,1),1);
b_U1_15k = zeros(size(constraint_U1_15k,1),1);
b_D1_15k = zeros(size(constraint_D1_15k,1),1);
b_blance_1 = zeros(size(constraint_blance_1,1),1);

DP.Aineq = [constraint_U1_15e;constraint_U2_15f;...
        constraint_L1_15e;constraint_L2_15f;constraint_rampup_1;constraint_rampdown_1;constraint_15g;constraint_15h;...
        constraint_15i;constraint_U1_15j;constraint_D1_15j;constraint_U1_15k;...
        constraint_D1_15k];
DP.Aeq = [constraint_15b;constraint_15c;constraint_15d;constraint_blance_1];
DP.bineq = [b_U1_15e;b_U2_15f;b_L1_15e;b_L2_15f;b_rampup_1;b_rampdown_1;b_15g;b_15h;...
        b_15i;b_U1_15j;b_D1_15j;b_U1_15k;b_D1_15k];
DP.beq = [b_15b;b_15c;b_15d;b_blance_1];

%�ֶ����Ի�
for i = 0:N
    pil = dataUC.p_low(unitNum) + i * (dataUC.p_up(unitNum) - dataUC.p_low(unitNum)) / N;
    gradiant = sparse(length_q,var_num);
    gradiant(1:length_q,var_num - 2*length_q + 1:var_num - length_q) = (2 * dataUC.gamma(unitNum)*pil + dataUC.beta(unitNum)) * eye(length_q); %qtk
    row_1 = 1; col_1 = 1;
    if t0 == 0
       col_1 = col_1 + 1;
    end
    for p = 1:num_T_K_1
        k = T_K_1{p,2};
        gradiant(row_1:row_1 + k - 1,T + col_1) = (dataUC.alpha(unitNum) - dataUC.gamma(unitNum) * power(pil,2));
        row_1 = row_1 + k;
        col_1 = col_1 + 1;
    end
    row_2 = row_1; col_2 = col_1;
    for p = 1:num_T_K_2
        t = T_K_2{p,1};
        k = T_K_2{p,2};
        l = k - t + 1;
        gradiant(row_2:row_2 + l - 1,T + col_2) = (dataUC.alpha(unitNum) - dataUC.gamma(unitNum) * power(pil,2));
        row_2 = row_2 + l;
        col_2 = col_2 + 1;
    end
    gradiant(1:length_q,var_num - length_q + 1:DP.var_num) = -1 * eye(length_q); %zit
    b_linear = zeros(length_q,1);
    DP.Aineq = [DP.Aineq;gradiant];
    DP.bineq = [DP.bineq;b_linear];   
end



DP.obj_c = [zeros(T,1);c_w_k;c_y_t_k_2;c_z_k_t_1;zeros(length_Xita,1);c_q_s_t_k;c_p_s_t_k];
DP.Bwan = [sparse(1:T,1:T,1),sparse(T,DP.var_num - T)];
DP.ub = ub;
DP.lb = lb;
DP.Q = sparse(var_num,1);
end
