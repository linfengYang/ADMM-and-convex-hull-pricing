%%  D_ADMM solve ED problem
function ADMM_CHP(pathAndFilename)

tic
%%%�����ļ�����

%     pathAndFilename='UC_AF/example-68-24.mod';
%   pathAndFilename='UC_AF/example_3_std.mod';
%   pathAndFilename='UC_AF/2_std.mod';
%     pathAndFilename='UC_AF/5_std.mod';   
%     pathAndFilename='UC_AF/10_std.mod';
%     pathAndFilename='UC_AF/10_0_1_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/200_0_1_w.mod';

%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';

%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%      pathAndFilename='UC_AF/c20_187_based_8_std.mod';


%dataUC=readdataUC(pathAndFilename);
dataUC = example('hua_2');
%dataUC = example('Paquet_1');



N=dataUC.N;    %������
T=dataUC.T;    %ʱ����
PD = dataUC.PD;  %����ƽ�⸺��

[G1,G2,G2_data,unit_type] = divide_Units(dataUC);
% for i = 1:N
%     G1(i) = i;
%     unit_type(i) = 1;
% end
%model = Build_DP_1_Model(dataUC,N);
G1_model = Build_simpleModel(dataUC,G1,unit_type,N);
%G2_model_i = model_MP3(G2_data,0,1,size(G2,2),6,0,0,0,0,3); %��ʩ�Ƶ��ɳ�MP3
G2_model_i = Build_3bin_Model(dataUC,G2,N);
G2_model = Build_G2_model(G2_model_i,G2);
model = merge_models(G1_model,G2_model);

%% 
% % D_ADMM�㷨��ʼ(δ����)
% % ��ʼ���㷨����
   M=1000;
   M2 = 1000;  %��¼K�ĵ������� 
   r=10;       %�������ղ���
   %p_r = 0;    %ԭʼ�в�
   %d_r = 0;    %��ż�в�
   
   %pri_tol = 1e-3;
   %dual_tol = 1e-3;
   abs_tol = 1e-3;  %�������
   rel_tol = 1e-4;  %���������������������йأ�ԽС��������Խ������ȷ��Խ�ߣ�
   %��ʼ����������
    z_k=zeros(T,N);
    y_k=zeros(T,N);
    p_k=zeros(T,1);                 
for k = 0:M
    % p-update
    p_k_old = p_k;
    p_k = sum(z_k,2) / N - sum(y_k,2) / (N * r);
    
    for i = 1:N
        % solve-x
        x_i = solve_Subproblem_1(PD,T,i,model,y_k,p_k,r,1);
        % z-update
        %z_k(:,i) = p_k - (DP.c_B_wan * x_i - PD + y_k(:,i)) / r;
        z_k(:,i) = p_k + (model.Bwan * x_i - PD + y_k(:,i)) / r;
        % p-update
        y_k(:,i) = y_k(:,i) + r * (-z_k(:,i) + p_k);
    end 
    
    %for i = 1:N
        % p-update  
        %y_k(:,i) = y_k(:,i) + r * (z_k(:,i) - p_k);
    %end
    
    
   %% ��¼�в�
    p_r = reshape(z_k,T * N,1) - repmat(p_k,N,1);    %ԭʼ�в�
    d_r = -1 * r * repmat(p_k - p_k_old,N,1);    %��ż�в�
    a = reshape(z_k,T * N,1);
    b = repmat(p_k,N,1);
    %����ֹͣ����
     
    if k >= 1
        
        epsilon_1 = norm(p_r,2);
        epsilon_2 = norm(d_r,2);
        
        
        
        %�������
        tol_pri = size(p_r,1)^0.5 * abs_tol + rel_tol * max([norm(a),norm(b),0]);
        tol_dul = size(d_r,1)^0.5 * abs_tol + rel_tol * norm(reshape(y_k,T * N,1));
        %tol_pri = N^0.5 * pri_tol;
        %tol_dul = N^0.5 * dual_tol;
        
        fprintf('����������%d\n',k);
        %disp('z_k');
        %disp(z_k);
        %disp('p_k');
        disp(-p_k);
        fprintf('%f  %f\n',epsilon_1,epsilon_2);
        
        if (epsilon_1 <= tol_pri && epsilon_2 <= tol_dul)
             fprintf('����������%d\n',k);
              M2 = k;
             break;
%             [flag1,new_G2_model,new_G2_model_i] = DP_cut1(dataUC,G2,G1_model.var_num,G2_model_i,x_i,T);
%             model =merge_models(G1_model,new_G2_model);
%             G2_model_i = new_G2_model_i;
%             %flag2 = DP_cut2();
%             if flag1 == 0 %&& flag2 ~= 0
%                 M2 = k;
%                 break;
%             end
        end
        
    end
    
end

%%��� 
all_time = toc;
disp('-----------------------------------------------------------------------------------');
fprintf('�����ƽ���ĵ��������� %d\n', M2);
disp(-p_k);
%fprintf('p_r = %f\n', p_r);
%fprintf('d_r = %f\n', d_r);
fprintf('cpu_time = %f\n', all_time);
    
