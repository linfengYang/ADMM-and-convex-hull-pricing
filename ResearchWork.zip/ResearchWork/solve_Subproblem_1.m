function xi = solve_Subproblem_1(PD,T,i,tol_Model,y_k,p_k,rou,relax)

%��Gurobi���
params.outputflag = 0;           %0��ʾ�����д��ڲ���ʾ�����̣�1��ʾ��ʾ����
%params.NonConvex = 2;
%params.QCPDual = 1;
%params.MIPGap = 0.0001; 
%params.timelimit = 1000;
%params.BarConvTol = 1e-12;        %Barrier convergence tolerance Ĭ��1e-8

obj_c = tol_Model.obj_c + tol_Model.Bwan'*(y_k(:,i) - PD + rou*p_k) / rou;
obj.Q = tol_Model.Bwan'* tol_Model.Bwan / (2*rou);

model.obj = full(obj_c);
model.Q = obj.Q;
model.A = [tol_Model.Aineq;tol_Model.Aeq];
model.rhs = full([tol_Model.bineq;tol_Model.beq]);
model.sense(1:size(tol_Model.Aineq,1)) = '<';
model.sense(size(tol_Model.Aineq,1)+1:size(tol_Model.Aineq,1)+size(tol_Model.Aeq,1)) = '=';
% model.vtype = tol_Model.var_type;
model.modelsense = 'min';
model.varnames = tol_Model.var_names;
model.lb = full(tol_Model.lb);
model.ub = full(tol_Model.ub);
% %��ת����׶Լ��
% Q_num = size(tol_Model.Qrow,2)/2; k = 1;j = T + 1;
% for i = 1:Q_num
%     model.quadcon(i).Qrow = [tol_Model.Qrow(k),tol_Model.Qrow(j)];
%     model.quadcon(i).Qcol = [tol_Model.Qcol(k),tol_Model.Qcol(j)];
%     model.quadcon(i).Qval = [tol_Model.Qval(k),tol_Model.Qval(j)];
%     model.quadcon(i).q  = tol_Model.Q;
%     model.quadcon(i).rhs = 0.0;
%     model.quadcon(i).name = ['rot_cone',num2str(i)];
%     k = k + 1;
%     j = j + 1;
%     if mod(k-1,T) == 0
%         k = k + T;
%         j = j + T;
%     end
% end
% 
% if relax == 1    %�����������ɳڵ�����
%     model.vtype(find(model.vtype == 'B')) = 'C';                        %�����������ĳ���������   
% end
gurobi_write(model, 'model.lp');
result = gurobi(model,params);

%{
x_p = 0;
for v=1:length(names(1:model.N*model.T))
     fprintf('%d  ',result.x(v));
     x_p = x_p + 1;
     if x_p == model.T
          fprintf('\n');
          x_p = 0;
     end
end
%}
% 
% for v=1:length(model.varnames)
%      fprintf('%s %d\n',model.varnames{v},result.x(v));
% end

xi = result.x;
end
