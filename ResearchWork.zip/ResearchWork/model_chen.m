function model = model_chen(dataUC,unit_num,n)
dataUC_i.N = 1;
dataUC_i.T = dataUC.T;
dataUC_i.unitNum = unit_num;
dataUC_i.p_up = dataUC.p_up(unit_num);
dataUC_i.p_low = dataUC.p_low(unit_num);
dataUC_i.p_rampup = dataUC.p_rampup(unit_num);
dataUC_i.p_rampdown = dataUC.p_rampdown(unit_num);
dataUC_i.p_startup = dataUC.p_startup(unit_num);
dataUC_i.p_shutdown = dataUC.p_shutdown(unit_num);
dataUC_i.alpha = dataUC.alpha(unit_num);
dataUC_i.beta = dataUC.beta(unit_num);
dataUC_i.gamma = dataUC.gamma(unit_num);
dataUC_i.Cold_cost = dataUC.Cold_cost(unit_num);
dataUC_i.Hot_cost = dataUC.Hot_cost(unit_num);
dataUC_i.fixedStartCost = dataUC.fixedStartCost(unit_num);
dataUC_i.PD = dataUC.PD;
dataUC_i.time_min_on = dataUC.time_min_on(unit_num);
dataUC_i.time_min_off = dataUC.time_min_off(unit_num);
dataUC_i.time_on_off_ini = dataUC.time_on_off_ini(unit_num);
dataUC_i.p_initial = dataUC.p_initial(unit_num);
dataUC_i.u0 = dataUC.u0(unit_num);
dataUC_i.Cold_hour = dataUC.Cold_hour(unit_num);

model = model_MP3(dataUC_i,0,1,n,dataUC_i.T,1,1,1,1,3);
end