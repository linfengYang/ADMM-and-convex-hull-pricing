function [model_PI,model_PI_i,num] = get_model(dataUC,PI,slack_type,MILP,DP)
n = size(PI,2); num = 0;
model_PI = cell(n,1); %��͹��ģ�ͼ��ɳ�ģ��
for j = 1:n
    model_PI{j}.Aineq = [];
    model_PI{j}.bineq = [];
    model_PI{j}.Aeq = [];
    model_PI{j}.beq = [];
    model_PI{j}.lb = [];
    model_PI{j}.ub = [];
    model_PI{j}.var_type = [];
    model_PI{j}.var_names = [];
    model_PI{j}.var_num = [];
    model_PI{j}.Bwan = [];
    model_PI{j}.b = [];
    model_PI{j}.obj_c = [];
    model_PI{j}.slack = [];
    model_PI{j}.unitNum = [];
end

%����ÿ�������ĵ�����ģ��
model_PI_i = cell(n,1);

for i = 1:n
    set_unit = PI{i};
    model_PI_i{i} = cell(size(set_unit,2),1);
    for j = 1:size(set_unit,2)
        unit_num = set_unit(j);
        [single_model,num] = unit_division(dataUC,unit_num,10,slack_type,MILP,DP,num);
        model_PI_i{i}{j} = single_model;
        model_PI{i}.var_num = [model_PI{i}.var_num,single_model.var_num];
        model_PI{i}.var_type = [ model_PI{i}.var_type,single_model.var_type];
        model_PI{i}.var_names = [model_PI{i}.var_names;single_model.var_names];
        model_PI{i}.obj_c = [model_PI{i}.obj_c;single_model.obj_c];
        model_PI{i}.Aineq = blkdiag(model_PI{i}.Aineq,single_model.Aineq);
        model_PI{i}.Aeq = blkdiag(model_PI{i}.Aeq,single_model.Aeq);
        model_PI{i}.bineq = [model_PI{i}.bineq;single_model.bineq];
        model_PI{i}.beq = [model_PI{i}.beq;single_model.beq];
        model_PI{i}.Bwan = [model_PI{i}.Bwan,single_model.Bwan];
        model_PI{i}.lb = [model_PI{i}.lb;single_model.lb];
        model_PI{i}.ub = [model_PI{i}.ub;single_model.ub];
        model_PI{i}.slack = [model_PI{i}.slack,single_model.slack];
        model_PI{i}.unitNum = [model_PI{i}.unitNum,unit_num];
    end
end
end