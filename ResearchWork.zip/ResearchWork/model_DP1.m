
function [DP] = model_DP1(dataUC,unitNum,L)  %自定义函数，dataUC数据�?
T = dataUC.T;

U_i = max(min(T,dataUC.u0(unitNum)*(dataUC.time_min_on(unitNum) - dataUC.time_on_off_ini(unitNum))),0);
L_i = max(min(T,(1 - dataUC.u0(unitNum))*(dataUC.time_min_off(unitNum) + dataUC.time_on_off_ini(unitNum))),0);

Node = {};   %创建图结点集N
index1 = 1;
Node{index1,1} = 0;
Node{index1,2} = 0;
index1 = index1 + 1;
Node{index1,1} = Inf;
Node{index1,2} = Inf;
sum_t = 0;  %�?有的时间总和
for h = 1:T
    if dataUC.u0(unitNum) == 0
        for k = min(h + dataUC.time_min_on(unitNum) - 1, T):T
            index1  = index1 + 1;
            Node{index1,1} = h;
            Node{index1,2} = k;
            sum_t = sum_t + (k - h + 1);
        end
    end
    if dataUC.u0(unitNum) == 1
        if h == 1
            for k  = max(U_i,1):T
                index1  = index1 + 1;
                Node{index1,1} = h;
                Node{index1,2} = k;
                sum_t = sum_t + (k - h + 1);
            end
        else
            if  h >= 1
                for k = min(h + dataUC.time_min_on(unitNum) - 1, T):T
                    index1  = index1 + 1;
                    Node{index1,1} = h;
                    Node{index1,2} = k;
                    sum_t = sum_t + (k - h + 1);
                end
            end
        end
    end
end

Node_len_1 = length(Node) - 2; %N1节点集的长度�?
Node_len_y = Node_len_1;
Node_1 = Node;     %N1结点�?


for h = 3:Node_len_1 + 2      %创建拓展图节点集N_wan
    index1 = index1 + 1;
    Node{index1,1} = -Node{h,1};
    Node{index1,2} = -Node{h,2};
end

Arc = {};   %创建弧集
index1 = 1;
Arc1 = {};
for p = 3:Node_len_1 + 2  %创建A1弧集
    for j = 3:Node_len_1 + 2
        k = Node_1{p,2};
        r = Node_1{j,1};
        if r >= k + dataUC.time_min_off(unitNum) + 1
            Arc1{index1,1} = Node_1{p,1};
            Arc1{index1,2} = k;
            Arc1{index1,3} = r;
            Arc1{index1,4} = Node_1{j,2};
            index1 = index1 + 1;
        end
    end
end
W_z = [];
W_z = [W_z;dataUC.Hot_cost(unitNum) * ones(size(Arc1,1),1)];

Arc2 = {};
index1 = 1;
for p = 3:Node_len_1 + 2  %创建A2弧集
    if dataUC.u0(unitNum) == 1
        if Node{p,1} == 1
            Arc2{index1,1} = 0;
            Arc2{index1,2} = 0;
            Arc2{index1,3} = Node_1{p,1};
            Arc2{index1,4} = Node_1{p,2};
            index1 = index1 + 1;
        end
    end
end
W_z = [W_z;zeros(size(Arc2,1),1)];

Arc3 = {};
index1 = 1;

for p = 3:Node_len_1 + 2   %创建A3弧集
    if dataUC.u0(unitNum) == 0
        if Node_1{p,1} >= L_i + 1
            Arc3{index1,1} = 0;
            Arc3{index1,2} = 0;
            Arc3{index1,3} = Node_1{p,1};
            Arc3{index1,4} = Node_1{p,2};
            index1 = index1 + 1;
        end
    end
end

W_z = [W_z;dataUC.Hot_cost(unitNum) * ones(size(Arc3,1),1)];

Arc4 = {};
index1 = 1;
for p = 1:Node_len_1 + 2    %创建A4弧集
    if Node_1{p,1} ~= Inf
        Arc4{index1,1} = Node_1{p,1};
        Arc4{index1,2} = Node_1{p,2};
        Arc4{index1,3} = Inf;
        Arc4{index1,4} = Inf;
        index1 = index1 + 1;
    end
end

W_z = [W_z;zeros(size(Arc4,1),1)];
Arc_wan = cell(Node_len_1,4); %创建拓展弧集
p = Node_len_1 + 2;
index1 = 1;
for h = 3:Node_len_1 + 2
    p = p + 1;
    Arc_wan{index1,1} = Node{h,1};
    Arc_wan{index1,2} = Node{h,2};
    Arc_wan{index1,3} = Node{p,1};
    Arc_wan{index1,4} = Node{p,2};
    index1 = index1 + 1;
end

for p = 1:size(Arc1,1)   %修改A1弧集
    Arc1{p,1} = -Arc1{p,1};
    Arc1{p,2} = -Arc1{p,2};
end

for p = 1:size(Arc4,1)    %修改A4弧集
    Arc4{p,1} = -Arc4{p,1};
    Arc4{p,2} = -Arc4{p,2};
end

Original_Arc = [Arc1;Arc2;Arc3;Arc4];
Arc_len_original = size(Original_Arc,1);
Arc_len_z = Arc_len_original;
Arc = [Arc_wan;Original_Arc];


%创建变量类型 [p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i] 变量排序
ctype_p_i_t(1:T) = 'C';
ctype_p_h_k_i_t(1:sum_t) = 'C';
ctype_y_h_k(1:Node_len_1) = 'B';
ctype_z_h_k_i_t(1:sum_t) = 'C';
ctype_z_i(1:Arc_len_original) = 'B';

ctype_y_h_k_int(1:Node_len_1) = 'C';
ctype_z_i_int(1:Arc_len_original) = 'C';

%创建变量名称：[p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i]
name_p_i_t = cell(T,1); %创建变量p_i_t
for p = 1:T
    name_p_i_t{p} = ['p',num2str(unitNum),',',num2str(p)];
end

name_p_h_k_i_t = cell(sum_t,1);   %创建变量p_h_k_i_t
index1 = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    for t1 = h:k
        name_p_h_k_i_t{index1} = ['p',num2str(h),',',num2str(k),'_',num2str(unitNum),',',num2str(t1)];
        index1 = index1 + 1;
    end
end

name_y_h_k = cell(Node_len_1,1);  %创建变量y_h_k
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    name_y_h_k{p - 2} = ['y',num2str(h),',',num2str(k),'_',num2str(unitNum)];
end


name_z_h_k_i_t =  cell(sum_t,1);   %创建变量z_h_k_i_t
index1 = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    for t1 = h:k
        name_z_h_k_i_t{index1} = ['z',num2str(h),',',num2str(k),'_',num2str(unitNum),',',num2str(t1)];
        index1 = index1 + 1;
    end
end

name_z_i = cell(Arc_len_original,1); %创建变量z_i
for p = 1:Arc_len_original
    s_1 = Original_Arc{p,1};
    s_2 = Original_Arc{p,3};
    d_1 = Original_Arc{p,2};
    d_2 = Original_Arc{p,4};
    if s_1 == 0
        name_z_i{p} = ['z',num2str(unitNum),'_','s',',','s','->',num2str(s_2),',',num2str(d_2)];
    else
        if s_2 == Inf
            name_z_i{p} = ['z',num2str(unitNum),'_',num2str(s_1),',',num2str(d_1),'->','d',',','d'];
        else
            name_z_i{p} = ['z',num2str(unitNum),'_',num2str(s_1),',',num2str(d_1),'->',num2str(s_2),',',num2str(d_2)];
        end
    end
end
%路径约束
B_y_h_k = sparse(length(Node),Node_len_1);
B_z_h_k = sparse(length(Node),Arc_len_original);
for p = 1:length(Node)
    for j = 1:size(Arc,1)
        s_1 = Arc{j,1};
        s_2 = Arc{j,2};
        d_1 = Arc{j,3};
        d_2 = Arc{j,4};
        if Node{p,1} == s_1 & Node{p,2} == s_2
            if j <= Node_len_1
                B_y_h_k(p,j) = -1;
            else
                B_z_h_k(p,j - Node_len_1) = -1;
            end
        end
        if Node{p,1} == d_1 & Node{p,2} == d_2
            if j <= Node_len_1
                B_y_h_k(p,j) = 1;
            else
                B_z_h_k(p,j - Node_len_1) = 1;
            end
        end
    end
end

%路径约束右端�?
B_wan_E = zeros(length(Node),1);
B_wan_E(1,1) = -1;
B_wan_E(2,1) = 1;

%power balance constraint

B_P_blance = sparse(1:T, 1:T,1);



%�?部机组约�?

%变量上下界约�?
A_p_L = sparse(sum_t,sum_t);
A_p_U = sparse(sum_t,sum_t);
y_h_k_L = sparse(sum_t,Node_len_1);
y_h_k_U = sparse(sum_t,Node_len_1);

for p = 1:sum_t
    A_p_L(p,p) = -1;
    A_p_U(p,p) = 1;
end

index1 = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    t = k - h + 1;
    for j = 1:t
        y_h_k_L(index1,p - 2) = dataUC.p_low(unitNum);
        y_h_k_U(index1,p - 2) = -dataUC.p_up(unitNum);
        index1 = index1 + 1;
    end
end



%��������Լ��
len = 0;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    for t = h:k - 1
        len = len + 1;
    end
end
A_ramp_up = sparse(len,sum_t);
A_ramp_down = sparse(len,sum_t);
y_h_k_up = sparse(len,Node_len_1);
y_h_k_down = sparse(len,Node_len_1);

index1 = 1; index2 = 1; index3 = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    for t = h:k - 1
        A_ramp_up(index1,index2) = -1;
        A_ramp_up(index1,index2 + 1) = 1;
        A_ramp_down(index1,index2) = 1;
        A_ramp_down(index1,index2 + 1) = -1;
        
        y_h_k_up(index1,index3) = -dataUC.p_rampup(unitNum);
        y_h_k_down(index1,index3) = -dataUC.p_rampdown(unitNum);
        index1 = index1 + 1;
        index2 = index2 + 1;
    end
    index2 = index2 + 1;
    index3 = index3 + 1;
    
end


%����������Լ��
row = 0;
for p = 3:Node_len_1 + 2
    k = Node_1{p,2};
    if k ~= T
        row = row + 1;
    end
end
A_p_start = sparse(Node_len_1,sum_t);
A_p_shut = sparse(row,sum_t);
y_h_k_start = sparse(Node_len_1,Node_len_1);
y_h_k_shut = sparse(row,Node_len_1);
b_y_startup = zeros(Node_len_1,1);
%phk <= Pstart
index1 = 1;index2 = 1;
index_y = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    if h == 1 && dataUC.u0(unitNum) == 1
        A_p_start(index1,index2) = 1;
        y_h_k_start(index1,index_y) = -dataUC.p_initial(unitNum) - dataUC.p_rampup(unitNum);
        index1 = index1 + 1;
        A_p_start(index1,index2) = -1;
        y_h_k_start(index1,index_y) = dataUC.p_initial(unitNum) - dataUC.p_rampdown(unitNum);
        index1 = index1 + 1;
        index_y = index_y + 1;
        index2 = index2 + k - h + 1;
    else
        A_p_start(index1,index2) = 1;
        y_h_k_start(index1,index_y) = -dataUC.p_startup(unitNum);
        index1 = index1 + 1;
        index_y = index_y + 1;
        index2 = index2 + k - h + 1;
    end
    
end
% phk <= Pshut
index1 = 1;
index2 = 0;
index_y = 1;
for p = 3:Node_len_1 + 2
    h = Node_1{p,1};
    k = Node_1{p,2};
    index2 = index2 + (k - h + 1);
    if k ~= T
        A_p_shut(index1,index2) = 1;
        y_h_k_shut(index1,index_y) = -dataUC.p_shutdown(unitNum);
        index1 = index1 + 1;
    end
    index_y = index_y + 1;
end

%约束�?31�?

B_p_i_t = diag(ones(T,1));
B_p_h_k = sparse(T,sum_t);

for p = 1:T
    index1 = 1;
    for j = 3:Node_len_1 + 2
        h = Node_1{j,1};
        k = Node_1{j,2};
        for t = h:k
            if t == p
                B_p_h_k(p,index1) = -1;
            end
            index1 = index1 + 1;
        end
    end
end


%�?机费用系数向�?
w_z_i = zeros(Arc_len_original,1);
index = 1;
for  p = 1:size(Arc1,1)
    k = Arc1{p,2};
    r = Arc1{p,3};
    t = r + k - 1;
    if t <= (dataUC.time_min_off(unitNum) + dataUC.Cold_hour(unitNum))
        w_z_i(index) = dataUC.Hot_cost(unitNum);
    else
        w_z_i(index) = dataUC.Cold_cost(unitNum);
    end
    index = index + 1;
end
index = index + size(Arc2,1);
for  p = 1:size(Arc3,1)
    r = Arc3{p,3};
    t = r - dataUC.time_on_off_ini(unitNum) - 1;
    if t <= (dataUC.time_min_off(unitNum) + dataUC.Cold_hour(unitNum))
        w_z_i(index) = dataUC.Hot_cost(unitNum);
    else
        w_z_i(index) = dataUC.Cold_cost(unitNum);
    end
    index = index + 1;
end


%Ŀ�꺯��
c_p_i_t = zeros(T,1);
c_p_h_k_i_t = zeros(sum_t,1);
c_z_h_k_i_t = ones(sum_t,1);
c_y_h_k = zeros(Node_len_1,1);
c_z_i = w_z_i .* ones(Arc_len_original,1);

%���Լ��
B_wan = sparse(1:T,1:T,1);
%�������½�
p_i_t_u = inf*ones(T,1);
p_i_t_h_k_u = inf*ones(sum_t,1);
z_i_t_h_k_u = inf*ones(sum_t,1);
y_h_k_u = inf*ones(Node_len_y,1);
z_h_k_u = inf*ones(Arc_len_z,1);

p_i_t_l = -inf*ones(T,1);
p_i_t_h_k_l = -inf*ones(sum_t,1);
z_i_t_h_k_l = -inf*ones(sum_t,1);
y_h_k_l = zeros(Node_len_y,1);
z_h_k_l = zeros(Arc_len_z,1);    


%返回完整的QCP模型参数


%旋转二阶锥二次约�?
Qrow = []; Qcol = []; Qval = []; 

%变量总长�?
DP.var_num = T +Node_len_y + 2*sum_t + Arc_len_z;

DP.var_type = [ctype_p_i_t,ctype_p_h_k_i_t,ctype_y_h_k,ctype_z_h_k_i_t,ctype_z_i];
DP.var_names = [name_p_i_t;name_p_h_k_i_t;name_y_h_k;name_z_h_k_i_t;name_z_i];

B_E = [sparse(size(B_y_h_k,1),T),sparse(size(B_y_h_k,1),sum_t),B_y_h_k,sparse(size(B_y_h_k,1),sum_t),B_z_h_k]; 
B_p_31 = [B_p_i_t,B_p_h_k,sparse(size(B_p_i_t,1),Node_len_y),sparse(size(B_p_i_t,1),sum_t),sparse(size(B_p_i_t,1),Arc_len_z)];
constraint_p_L = [sparse(size(A_p_L,1),T),A_p_L,y_h_k_L,sparse(size(A_p_L,1),sum_t),sparse(size(A_p_L,1),Arc_len_z)]; 
constraint_p_U = [sparse(size(A_p_U,1),T),A_p_U,y_h_k_U,sparse(size(A_p_U,1),sum_t),sparse(size(A_p_U,1),Arc_len_z)]; 
constraint_p_ramp_up = [sparse(size(A_ramp_up,1),T),A_ramp_up,y_h_k_up,sparse(size(A_ramp_up,1),sum_t),sparse(size(A_ramp_up,1),Arc_len_z)]; 
constraint_p_ramp_down = [sparse(size(A_ramp_down,1),T),A_ramp_down,y_h_k_down,sparse(size(A_ramp_down,1),sum_t),sparse(size(A_ramp_down,1),Arc_len_z)];
constraint_p_start = [sparse(size(A_p_start,1),T),A_p_start,y_h_k_start,sparse(size(A_p_start,1),sum_t),sparse(size(A_p_start,1),Arc_len_z)];
constraint_p_shut = [sparse(size(A_p_shut,1),T),A_p_shut,y_h_k_shut,sparse(size(A_p_shut,1),sum_t),sparse(size(A_p_shut,1),Arc_len_z)];

b_p_U = zeros(size(constraint_p_U,1),1);
b_p_L = zeros(size(constraint_p_L,1),1);
b_p_ramp_up = zeros(size(constraint_p_ramp_up,1),1);
b_p_ramp_down = zeros(size(constraint_p_ramp_down,1),1);
b_p_start = zeros(size(constraint_p_start,1),1);
b_p_shut = zeros(size(constraint_p_shut,1),1);
b_p_31 = zeros(size(B_p_31,1),1);

DP.Aineq = [constraint_p_U;constraint_p_L;constraint_p_ramp_up;constraint_p_ramp_down;constraint_p_start;constraint_p_shut];
DP.Aeq = [B_E;B_p_31];
DP.bineq = [b_p_U;b_p_L;b_p_ramp_up;b_p_ramp_down;b_p_start;b_p_shut];
DP.beq = [B_wan_E;b_p_31];
a = sparse(T,T);

%Ŀ�꺯�����Ի�
for i = 0:L
     pil = dataUC.p_low(unitNum) + i * (dataUC.p_up(unitNum) - dataUC.p_low(unitNum)) / L;
     gradiant = sparse(sum_t,DP.var_num);
     gradiant(1:sum_t,T + 1:T + sum_t) = (2 * dataUC.gamma(unitNum)*pil + dataUC.beta(unitNum)) * eye(sum_t); %pit
     row = 1; col = 1;
     for p = 3:Node_len_1 + 2
         h = Node_1{p,1};
         k = Node_1{p,2};
         t = k - h + 1;
         gradiant(row:row + t - 1,T + sum_t + col) = (dataUC.alpha(unitNum) - dataUC.gamma(unitNum) * power(pil,2));
         row = row + t;
         col = col + 1;
     end
     gradiant(1:sum_t,T + sum_t + Node_len_y + 1:DP.var_num - Arc_len_z) = -1 * eye(sum_t); %zit
     b_linear = zeros(sum_t,1);
     DP.Aineq = [DP.Aineq;gradiant];
     DP.bineq = [DP.bineq;b_linear];
end

DP.Qrow = [];
DP.Qcol = [];
DP.Qval = [];
DP.obj_c = [c_p_i_t;c_p_h_k_i_t;c_y_h_k;c_z_h_k_i_t;c_z_i];
DP.Q = sparse(DP.var_num,1);
DP.Bwan = [B_wan,sparse(T,DP.var_num - T)];
DP.ub = [p_i_t_u;p_i_t_h_k_u;y_h_k_u;z_i_t_h_k_u;z_h_k_u];
DP.lb = [p_i_t_l;p_i_t_h_k_l;y_h_k_l;z_i_t_h_k_l;z_h_k_l];
DP.slack = 0;
DP.unitNum = unitNum;
%%%% end of function
end
