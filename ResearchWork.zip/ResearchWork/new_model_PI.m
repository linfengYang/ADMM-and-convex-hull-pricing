function [new_model] = new_model_PI(model_i,unit_set)
new_model.var_num = []; G2_unitNum = 0;new_model.var_type = []; new_model.var_names = [];
new_model.obj_c = []; new_model.Q = []; new_model.Aineq = [];new_model.bineq = [];
new_model.Aeq = []; new_model.beq = []; new_model.Bwan = []; new_model.ub = [];
new_model.lb = [];  new_model.Qrow = []; new_model.Qcol = []; new_model.Qval = [];
new_model.slack = []; new_model.unitNum = [];
for i = 1:size(unit_set,2)
    G2_unitNum = G2_unitNum + 1;
    new_model.var_num = [new_model.var_num,model_i{i}.var_num];
    new_model.var_names = [new_model.var_names;model_i{i}.var_names];
    new_model.var_type = [new_model.var_type,model_i{i}.var_type]; 
    new_model.obj_c = [new_model.obj_c;model_i{i}.obj_c]; 
    %G2_model.Q = [G2_model.Q;G2_model_i.Q{i}]; 
    new_model.Aineq = blkdiag(new_model.Aineq,model_i{i}.Aineq);
    new_model.Aeq = blkdiag(new_model.Aeq,model_i{i}.Aeq);
    new_model.bineq = [new_model.bineq;model_i{i}.bineq];
    new_model.beq = [new_model.beq;model_i{i}.beq];
    new_model.Bwan = [new_model.Bwan,model_i{i}.Bwan];
    new_model.ub = [new_model.ub;model_i{i}.ub];
    new_model.lb = [new_model.lb;model_i{i}.lb];
    new_model.slack = [new_model.slack,model_i{i}.slack];
    new_model.unitNum = [new_model.unitNum,model_i{i}.unitNum];
end

end