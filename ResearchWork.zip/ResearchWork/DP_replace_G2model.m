function new_G2_model_i = DP_replace_G2model(i,j,model_i,data)
%����Ӧ���ɳ�ģ���滻Ϊ͹��ģ��
DP = select_DP(data,j);
model_i{i}.var_num = DP.var_num;
model_i{i}.var_type = DP.var_type;
model_i{i}.var_names = DP.var_names;
model_i{i}.obj_c = DP.obj_c;
model_i{i}.Aineq = DP.Aineq;
model_i{i}.Aeq = DP.Aeq;
model_i{i}.bineq = DP.bineq;
model_i{i}.beq = DP.beq;
model_i{i}.Bwan = DP.Bwan;
model_i{i}.ub = DP.ub;
model_i{i}.lb = DP.lb;
model_i{i}.unitNum = j;
model_i{i}.slack = 0;
new_G2_model_i = model_i;

end