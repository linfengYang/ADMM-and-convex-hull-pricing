
function [ qcp_i ] = qpED_CHP( dataUC )  %�Զ��庯��������dataUC�����qp_i

N = dataUC.N;   T = dataUC.T;
%N = 8; T = 24;
%dataUC.u0(1) = 0; dataUC.time_min_on(1) = 8; dataUC.time_min_off(1) = 8;
%dataUC.time_on_off_ini(1) = 8; dataUC.p_low(1) = 150; dataUC.p_up(1) = 150;
%dataUC.p_rampup(1) = 50;  dataUC.p_rampdown(1) = 50;
%dataUC.beta(1) = 1; dataUC.gamma(1) = 1;
x_L = cell(N,1);    x_U = cell(N,1);
A = cell(N,1);      b = cell(N,1);
B = cell(N,1);      B_wan = cell(N,1);
ctype = cell(N,1);  L = cell(N,1);
sum_t = cell(N,1);  Q_UC = cell(N,1);
Q = cell(N,1);   c_UC = cell(N,1);
Q_r = cell(N,1);  names = cell(N,1);
Qrow = cell(N,1); Qcol = cell(N,1);
Qval = cell(N,1);  W_z = cell(N,1);


for i = 1:N %���ջ�����зֿ飬����������ص�Լ����Ϊһ�顣
    
  
   
    U_i = max(min(T,dataUC.u0(i)*(dataUC.time_min_on(i) - dataUC.time_on_off_ini(i))),0);
    L_i = max(min(T,(1-dataUC.u0(i))*(dataUC.time_min_off(i) + dataUC.time_on_off_ini(i))),0);
    
    Node = cell(T,2);   %����ͼ��㼯N
    index1 = 1;
    Node{index1,1} = 0;
    Node{index1,2} = 0;
    index1 = index1 + 1;
    Node{index1,1} = inf;
    Node{index1,2} = inf;
    sum_t{i} = 0;  %���е�ʱ���ܺ�
    for h = 1:T                
        for k = min(h + dataUC.time_min_on(i) + 1, T):T
            index1  = index1 + 1;
            Node{index1,1} = h;
            Node{index1,2} = k;
            sum_t{i} = sum_t{i} + (k - h + 1);
         end
    end
    
    Node_len_1 = length(Node) - 2; %N1�ڵ㼯�ĳ��ȡ�
    
    Node_1 = Node;     %N1��㼯
    
   
    for h = 3:Node_len_1 + 2      %������չͼ�ڵ㼯N_wan
        index1 = index1 + 1;
        Node{index1,1} = -Node{h,1};
        Node{index1,2} = -Node{h,2};
    end
    
    Arc = {};   %��������
    index1 = 1;
    Arc1 = {};                                                   
    for p = 3:Node_len_1 + 2  %����A1����
        for j = 3:Node_len_1 + 2
            k = Node{p,2};
            r = Node{j,1};
            if r >= k + dataUC.time_min_off(i) + 1 
                Arc1{index1,1} = Node{p,1};
                Arc1{index1,2} = k;
                Arc1{index1,3} = r;
                Arc1{index1,4} = Node{j,2};
                index1 = index1 + 1; 
            end         
        end
    end
    
    W_z{i} = [W_z{i};dataUC.Hot_cost(i) * ones(size(Arc1,1),1)];
    
    Arc2 = {}; 
    index1 = 1;
    for p = 3:Node_len_1 + 2  %����A2����
        if dataUC.u0(i) == 1
            if Node{p,1} == 1 && Node{p,2} >= U_i
                Arc2{index1,1} = 0;
                Arc2{index1,2} = 0;
                Arc2{index1,3} = Node{p,1};
                Arc2{index1,4} = Node{p,2};
            end
             index1 = index1 + 1;
        end
    end
    W_z{i} = [W_z{i};zeros(size(Arc2,1),1)];
    
    Arc3 = {};
    index1 = 1;
    
    for p = 3:Node_len_1 + 2   %����A3����
        if dataUC.u0(i) == 0
            if Node{p,1} >= L_i + 1
                Arc3{index1,1} = 0;
                Arc3{index1,2} = 0;
                Arc3{index1,3} = Node{p,1};
                Arc3{index1,4} = Node{p,2};
            end
        end
        index1 = index1 + 1;
    end
    
    W_z{i} = [W_z{i};dataUC.Hot_cost(i) * ones(size(Arc3,1),1)];
    
    Arc4 = {};
    index1 = 1;
    for p = 3:Node_len_1 + 2    %����A4����
        Arc4{index1,1} = -Node{p,1};
        Arc4{index1,2} = -Node{p,2};
        Arc4{index1,3} = Inf;
        Arc4{index1,4} = Inf;
        index1 = index1 + 1;
    end
    
    W_z{i} = [W_z{i};zeros(size(Arc4,1),1)];
    Arc = [Arc1;Arc2;Arc3;Arc4];
    Arc_len_original = size(Arc,1);
    
    Arc_wan = cell(Node_len_1,4); %������չ����
    p = Node_len_1 + 2;
    index1 = 1;
    for h = 3:Node_len_1 + 2
        p = p + 1;
        Arc_wan{index1,1} = Node{h,1};
        Arc_wan{index1,2} = Node{h,2};
        Arc_wan{index1,3} = Node{p,1};
        Arc_wan{index1,4} = Node{p,2};
        index1 = index1 + 1;
    end
    
    Arc = [Arc_wan;Arc];
    %������������ [p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i] ��������
    ctype{i} = '';
    ctype{i}(1:T + sum_t{i}) = 'C';
    ctype{i}(T + sum_t{i} + 1:T + sum_t{i} + Node_len_1) = 'B';
    ctype{i}(T + sum_t{i} + Node_len_1 + 1:T + 2*sum_t{i} + Node_len_1) = 'C';
    ctype{i}(T + 2*sum_t{i} + Node_len_1 + 1:T + 2*sum_t{i} + Node_len_1 + Arc_len_original) = 'B';
   
    %�����������ƣ�[p_i_t, p_h_k_i_t, y_h_k, z_h_k_i_t, z_i]
    name_p_i_t = cell(T,1); %��������p_i_t
    for p = 1:length(name_p_i_t)
           name_p_i_t{p} = ['p',num2str(i),num2str(p)];
    end
    
    name_p_h_k_i_t = cell(sum_t{i},1);  %��������p_h_k_i_t
    index1 = 1;
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        for t1 = h:k
            name_p_h_k_i_t{index1} = ['p',num2str(h),num2str(k),num2str(i),num2str(t1)];
            index1 = index1 + 1;
        end
    end
    
    name_y_h_k = cell(Node_len_1,1); %��������y_h_k
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        name_y_h_k{p - 2} = ['y',num2str(h),num2str(k)];
    end
    
    
    name_z_h_k_i_t = cell(sum_t{i},1);   %��������z_h_k_i_t
    index1 = 1;
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        for t1 = h:k
            name_z_h_k_i_t{index1} = ['z',num2str(h),num2str(k),num2str(i),num2str(t1)];
            index1 = index1 + 1;
        end
    end
    
    name_z_i = cell(Arc_len_original,1); %��������z_i
    for p = 1:Arc_len_original
        name_z_i{p} = ['z',num2str(p)];
    end
    
    names{i} = [name_p_i_t;name_p_h_k_i_t;name_y_h_k;name_z_h_k_i_t;name_z_i];
  
    %�������½�
    p_i_t_L = sparse(1:T,1,dataUC.p_low(i));% �����½�dataUC.p_low(i)
    p_i_t_U = sparse(1:T,1,dataUC.p_up(i));% �����Ͻ�
    p_h_k_L = sparse(1:sum_t{i},1,dataUC.p_low(i));
    p_h_k_U = sparse(1:sum_t{i},1,dataUC.p_up(i));
    y_h_k_L = sparse(1:Node_len_1,1,0);
    y_h_k_U = sparse(1:Node_len_1,1,1);
    z_i_t_L = sparse(1:sum_t{i},1,dataUC.p_low(i));
    z_i_t_U = sparse(1:sum_t{i},1,dataUC.p_up(i));
    z_h_k_L = sparse(1:Arc_len_original,1,0);
    z_h_k_U = sparse(1:Arc_len_original,1,1);
    x_L{i} = [p_i_t_L;p_h_k_L;y_h_k_L;z_i_t_L;z_h_k_L];
    x_U{i} = [p_i_t_U;p_h_k_U;y_h_k_U;z_i_t_U;z_h_k_U];
  
    %·��Լ��
    B_y_h_k = sparse(length(Node),Node_len_1);
    B_z_h_k = sparse(length(Node),Arc_len_original);
    for p = 1:length(Node)
        for j = 1:size(Arc,1)
            s_1 = Arc{j,1};
            s_2 = Arc{j,2};
            d_1 = Arc{j,3};
            d_2 = Arc{j,4};
            if Node{p,1} == s_1 & Node{p,2} == s_2 
                 if j <= Node_len_1
                     B_y_h_k(p,j) = -1;
                 else 
                     B_z_h_k(p,j - Node_len_1) = -1;
                 end
            end     
            if Node{p,1} == d_1 & Node{p,2} == d_2       
                   if j <= Node_len_1
                     B_y_h_k(p,j) = 1;
                   else 
                     B_z_h_k(p,j - Node_len_1) = 1;
                   end
            end
        end
    end
   
    B_E = [sparse(length(Node),T),sparse(length(Node),sum_t{i}), ...
           B_y_h_k,sparse(length(Node),sum_t{i}),B_z_h_k,];
    %·��Լ���Ҷ���
    B_wan_E = zeros(length(Node),1);
    B_wan_E(1,1) = -1;
    B_wan_E(2,1) = 1;
    
    %power balance constraint
    
    B_wan{i} = sparse(1:T, 1:T,1);
    % �γɹ���ƽ��Լ�����Ҷ���
    %c_wan = dataUC.PD;
    
    %�ֲ�����Լ��
    
    %�������½�Լ��
    A_p_L = sparse(sum_t{i},sum_t{i});
    A_p_U = sparse(sum_t{i},sum_t{i});
    y_h_k_L = sparse(sum_t{i},Node_len_1);
    y_h_k_U = sparse(sum_t{i},Node_len_1);
    
    for p = 1:sum_t{i}
        A_p_L(p,p) = -1;
        A_p_U(p,p) = 1;       
    end
    
    index1 = 1;
    for p = 3:length(Node_1)
        h = Node_1{p,1};
        k = Node_1{p,2};
        t = k - h + 1;
        for j = 1:t
            y_h_k_L(index1,p - 2) = dataUC.p_low(i);
            y_h_k_U(index1,p - 2) = -dataUC.p_up(i);
            index1 = index1 + 1;
        end
    end
    
    %�ϲ�����ʽ����ϵ������
    temp1 = [sparse(sum_t{i},T),A_p_L, y_h_k_L,sparse(sum_t{i},sum_t{i}),...
             sparse(sum_t{i},Arc_len_original)];
    temp2 = [sparse(sum_t{i},T),A_p_U, y_h_k_U,sparse(sum_t{i},sum_t{i}),...
             sparse(sum_t{i},Arc_len_original)];
    A{i} = [temp1; temp2];
    
    %����Լ��
     len = 0;
     for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        for t = h:k - 1 
                len = len + 1;
        end
    end
    A_ramp_up = sparse(len,sum_t{i});
    A_ramp_down = sparse(len,sum_t{i});
    y_h_k_up = sparse(len,Node_len_1);
    y_h_k_down = sparse(len,Node_len_1);
    
    index1 = 1; index2 = 1;
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        for t = h:k - 1 
               A_ramp_up(index1,index1) = -1;
               A_ramp_up(index1,index1 + 1) = 1;
               A_ramp_down(index1,index1) = 1;
               A_ramp_down(index1,index1 + 1) = -1;
       
               y_h_k_up(index1,index2) = -dataUC.p_rampup(i);
               y_h_k_down(index1,index2) = -dataUC.p_rampdown(i); 
                index1 = index1 + 1;
        end
        index2 = index2 + 1;
        
    end
    
    temp1 = [sparse(len,T),A_ramp_up,y_h_k_up, ...
             sparse(len,sum_t{i}),sparse(len,Arc_len_original)];
    temp2 = [sparse(len,T),A_ramp_down,y_h_k_down, ...
             sparse(len,sum_t{i}),sparse(len,Arc_len_original)];
   
    %A{i} = [A{i};temp1;temp2];
    
    %�����ͣ����
    A_p_start = sparse(Node_len_1,sum_t{i});
    A_p_shut = sparse(Node_len_1,sum_t{i});
    y_h_k_start = sparse(Node_len_1,Node_len_1);
    y_h_k_shut = sparse(Node_len_1,Node_len_1);
    
    index1 = 1;
    index2 = 1;
    for p = 3:Node_len_1 + 2 
        h = Node{p,1};
        k = Node{p,2};
        A_p_start(index1,index2) = 1;
        y_h_k_start(index1,index1) = -dataUC.p_startup(i);
        index1 = index1 + 1;
        index2 = index2 + (k - h + 1);
    end
    index1 = 1;
    index2 = 0;
    for p = 3:Node_len_1 + 2 
        h = Node{p,1};
        k = Node{p,2};
        index2 = index2 + (k - h + 1);
        A_p_shut(index1,index2) = 1;
        y_h_k_shut(index1,index1) = -dataUC.p_shutdown(i);
        index1 = index1 + 1;
    end
    
    temp1 = [sparse(Node_len_1,T),A_p_start, y_h_k_start,...
             sparse(Node_len_1,sum_t{i}),...
             sparse(Node_len_1,Arc_len_original)];
    temp2 = [sparse(Node_len_1,T),A_p_shut, y_h_k_shut,...
             sparse(Node_len_1,sum_t{i}),...
             sparse(Node_len_1,Arc_len_original),];
    %A{i} = [A{i};[temp1;temp2]];
    
    %Լ����31��
    
    B_p_i_t = diag(ones(T,1));
    B_p_h_k = sparse(T,sum_t{i});
    
    for p = 1:T
        index1 = 1;
        for j = 3:Node_len_1 + 2
            h = Node{j,1};
            k = Node{j,2};
            for t = h:k
                if t == p
                   B_p_h_k(p,index1) = -1;
                end
                index1 = index1 + 1;
            end
        end
    end
    
    temp = [B_p_i_t,B_p_h_k, sparse(T,Node_len_1),...
            sparse(T,sum_t{i}),sparse(T,Arc_len_original)]; 
    B_E = [B_E;temp];
    B_wan_p = zeros(T,1);
   
    %��ת����׶����Լ��                                                
    row_p = [];col_p = []; val_p = [];
    row_yz = []; col_yz = []; val_yz = [];
   
    for p = 1:sum_t{i}
        row_p(p) = p + T;
        col_p(p) = p + T;
        val_p(p) = 1;
    end
    
    index_val = 1;
    index_row = 1;
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        for t = h:k
            row_yz(index_row) = p - 2 + T + sum_t{i};
            col_yz(index_val) = index_val + T + sum_t{i} + Node_len_1;
            val_yz(index_val) = -1;
            index_row = index_row + 1;
            index_val = index_val + 1;
        end
    end
            
    Qrow{i} = [row_p,row_yz];
    Qcol{i} = [col_p,col_yz];
    Qval{i} = [val_p,val_yz];
    
   
    % Ŀ�꺯��
    c_p_h_k = dataUC.beta(i) * ones(sum_t{i},1);
    c_z_h_k = dataUC.gamma(i) * ones(sum_t{i},1);
    c_y_h_k = zeros(Node_len_1,1);
    for p = 3:Node_len_1 + 2
        h = Node{p,1};
        k = Node{p,2};
        c_y_h_k(p - 2) = dataUC.alpha(i)*(k - h + 1);
    end
    c_z_i = 0 * ones(Arc_len_original,1);
    c_UC{i} = [c_p_h_k;c_y_h_k;c_z_h_k;c_z_i];
    
    Q_UC{i} = sparse(T + 2*sum_t{i} + Node_len_1 + Arc_len_original,...
                     T + 2*sum_t{i} + Node_len_1 + Arc_len_original);
    
Q{i} = sparse(T + 2*sum_t{i} + Node_len_1 + Arc_len_original,1);    
B{i} = B_E; 

b{i} = [zeros(size(A{i},1),1);B_wan_E;B_wan_p];
A{i} = [A{i};B{i}];
end


% ���طֿ��ģ������
qcp_i.A = A;           qcp_i.b = b;
qcp_i.B_wan = B_wan;   qcp_i.B = B;
qcp_i.L = L;     qcp_i.Q = Q;
qcp_i.x_L = x_L;   qcp_i.x_U = x_U;     
qcp_i.T = T;        qcp_i.N = N;     
qcp_i.c_UC = c_UC;  qcp_i.ctype = ctype;   
qcp_i.Q_UC = Q_UC;  qcp_i.names = names; 
qcp_i.Qrow = Qrow;  qcp_i.Qcol = Qcol;   
qcp_i.Qval = Qval;  qcp_i.Q_r = Q_r;


n = 1; %ÿ��Ƭ���Ļ������������л���ֳ�һ����Ƭ����
p_num = ceil(N/n); %Ƭ������
index1 = 1; index2 = 1;
omega = cell(p_num,1);
A_j = {};
for i = 1:N
    if index1 <= n
       A_j{index1}.A = A{i};
       A_j{index1}.b = b{i};
       A_j{index1}.B = B{i};
       A_j{index1}.c_UC = c_UC{i};
       A_j{index1}.Q_UC = Q_UC{i};
       A_j{index1}.ctype = ctype{i};
       A_j{index1}.names = names{i};
       A_j{index1}.Qrow = Qrow{i};
       A_j{index1}.Qcol = Qcol{i};
       A_j{index1}.Qval = Qval{i};
       A_j{index1}.Q = Q{i};
       index1 = index1 + 1;
    end
    if index1 > n
        index1 = 1;
        omega{index2} = A_j;
        index2 = index2 + 1;
    end
  
end
    
    
%����������MIPģ�Ͳ���
%UC.c_UC = []; UC.A = [];
%UC.b = []; UC.B = [];
%UC.ctype = []; UC.names = [];
%UC.Qrow = []; UC.Qcol = [];
%UC.Qval = []; UC.Q = [];
%for i = 1:N
    %UC.c_UC = [UC.c_UC; c_UC{i}];
    %UC.A = [UC.A; A{i}];
    %UC.b = [UC.b; b{i}];
    %UC.B = [UC.B; B{i}];
    %UC.ctype = [UC.ctype; ctype{i}];
    %UC.names = [UC.names; names{i}];
    %UC.Qrow = [UC.Qrow; Qrow{i}];
    %UC.Qcol = [UC.Qcol; Qcol{i}];
    %UC.Qval = [UC.Qval; Qval{i}];
    %UC.Q = [UC.Q; Q{i}];
%end
%%%% end of function
end
