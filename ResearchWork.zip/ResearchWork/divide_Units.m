function [G1,G2,G2_data,unit_type] = divide_Units(dataUC) 
N = dataUC.N;
G1 = [];
G2 = [];
G2_data = [];
unit_type = [];
%���ֻ���
for i = 1:N
    if dataUC.p_rampup(i) >= dataUC.p_up(i)&& dataUC.p_rampdown(i) >= dataUC.p_low(i)
       if dataUC.p_startup(i) < dataUC.p_up(i)
           unit_type = [unit_type,2];
       else
           unit_type = [unit_type,1];
       end
        G1 = [G1,i];
    else
        G2 = [G2,i];
    end
end
%����G2���ϵĻ�������
for i = 1:size(G2,2)
    unit = G2(i);
    G2_data.p_rampup(i) = dataUC.p_rampup(unit);
    G2_data.p_rampdown(i) = dataUC.p_rampdown(unit);
    G2_data.alpha(i) = dataUC.alpha(unit);
    G2_data.beta(i) = dataUC.beta(unit);
    G2_data.gamma(i) = dataUC.gamma(unit);
    G2_data.p_low(i) = dataUC.p_low(unit);
    G2_data.p_up(i) = dataUC.p_up(unit);
    G2_data.time_on_off_ini(i) = dataUC.time_on_off_ini(unit);
    G2_data.time_min_on(i) = dataUC.time_min_on(unit);
    G2_data.time_min_off(i) = dataUC.time_min_off(unit);
    G2_data.fixedStartCost(i) = dataUC.fixedStartCost(unit);
    G2_data.p_initial(i) = dataUC.p_initial(unit);
    G2_data.Cold_hour(i) = dataUC.Cold_hour(unit);
    G2_data.p_startup(i) = dataUC.p_startup(unit);
    G2_data.p_shutdown(i) = dataUC.p_shutdown(unit);
    G2_data.Cold_cost(i) = dataUC.Cold_cost(unit);
    G2_data.Hot_cost(i) = dataUC.Hot_cost(unit);
    G2_data.u0(i) = dataUC.u0(unit);
    G2_data.T = dataUC.T;
    G2_data.N = size(G2,2);
end

end