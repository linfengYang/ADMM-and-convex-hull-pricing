function [single_model,num] = unit_division(dataUC,unit_num,n,slack_type,MILP,DP,num)
%���ֻ���,���ݻ�������Խ����黮�ֵ�G1������G2������ȥ
gap = dataUC.p_up(unit_num) - dataUC.p_low(unit_num);
if dataUC.p_rampup(unit_num) >= gap && dataUC.p_rampdown(unit_num) >= gap
       if dataUC.p_startup(unit_num) < gap
          single_model = Model_simple(dataUC,unit_num,2,n);
          num = num + 1;
       else
          single_model = Model_simple(dataUC,unit_num,1,n);
          num = num + 1;
       end
else
    if strcmp(slack_type,'model_3bin') && MILP == 0
       single_model = model_3bin(dataUC,unit_num,n);
    elseif strcmp(slack_type,'model_chen') && MILP == 0
       single_model = model_chen(dataUC,unit_num,n);
    end
    if DP == 1
       single_model = model_DP2(dataUC,unit_num,n);
    end
    if MILP == 1
        single_model = model_3bin(dataUC,unit_num,n);
    end
end
end