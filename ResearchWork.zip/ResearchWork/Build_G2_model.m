function [G2_model] = Build_G2_model(G2_model_i,G2)
G2_model.var_num = 0; G2_unitNum = 0;G2_model.var_type = []; G2_model.var_names = [];
G2_model.obj_c = []; G2_model.Q = []; G2_model.Aineq = [];G2_model.bineq = [];
G2_model.Aeq = []; G2_model.beq = []; G2_model.Bwan = []; G2_model.ub = [];
G2_model.lb = [];  G2_model.Qrow = []; G2_model.Qcol = []; G2_model.Qval = [];

%将G2里的机组形成完整的gruobi模型
for i = 1:size(G2,2)
    G2_unitNum = G2_unitNum + 1;
    G2_model.var_num = G2_model.var_num + G2_model_i.var_num{i};
    G2_model.var_names = [G2_model.var_names;G2_model_i.var_names{i}];
    G2_model.var_type = [G2_model.var_type,G2_model_i.var_type{i}]; 
    G2_model.obj_c = [G2_model.obj_c;G2_model_i.obj_c{i}]; 
    %G2_model.Q = [G2_model.Q;G2_model_i.Q{i}]; 
    G2_model.Aineq = blkdiag(G2_model.Aineq,G2_model_i.Aineq{i});
    G2_model.Aeq = blkdiag(G2_model.Aeq,G2_model_i.Aeq{i});
    G2_model.bineq = [G2_model.bineq;G2_model_i.bineq{i}];
    G2_model.beq = [G2_model.beq;G2_model_i.beq{i}];
    G2_model.Bwan = [G2_model.Bwan,G2_model_i.Bwan{i}];
    G2_model.ub = [G2_model.ub;G2_model_i.ub{i}];
    G2_model.lb = [G2_model.lb;G2_model_i.lb{i}];
    
%     if G2_model_i.soc{i} == 1
%         index = G2_model.var_num - G2_model_i.var_num(i);
%         %合并二阶锥约束
%         for k = 1:size(G2_model_i.Qrow{i},2)
%             G2_model_i.Qrow{i}(k) = index + G2_model_i.Qrow{i}(k);
%             G2_model_i.Qcol{i}(k) = index + G2_model_i.Qcol{i}(k);
%         end
%         G2_model.Qrow = [G2_model.Qrow,G2_model_i.Qrow{i}];
%         G2_model.Qcol = [G2_model.Qcol,G2_model_i.Qcol{i}];
%         G2_model.Qval = [G2_model.Qval,G2_model_i.Qval{i}];
%     end
end

end