function DP_2_Model = Build_DP_2_Model(dataUC,DP_2)
DP_i_var_num = cell(size(DP_2),1);
DP_i_var_type = cell(size(DP_2),1);
DP_i_var_names = cell(size(DP_2),1);
DP_i_c = cell(size(DP_2),1);
DP_i_Q = cell(size(DP_2),1);
DP_i_Aineq = cell(size(DP_2),1);
DP_i_Aeq = cell(size(DP_2),1);
DP_i_rhs = cel(size(DP_1),1);
DP_i_c_B_wan = cell(size(DP_2),1);
DP_i_Qrow = cell(size(DP_2),1);
DP_i_Qcol = cell(size(DP_2),1);
DP_i_Qval = cell(size(DP_2),1);
DP_i_ub = cell(size(DP_2),1);
DP_i_lb = cell(size(DP_2),1);


DP.var_num = []; DP.var_type = []; DP.var_names = [];
DP.var_c = []; DP.Q = []; DP.A = [];
DP.B = []; DP.c_B_wan = []; DP.Qrow = [];
DP.Qcol = []; DP.Qval = []; DP.ub = [];
DP.lb = [];
%��ȡ���������͹��
for i = 1:size(DP_2)
    DP = Model_DP_1_sigle(dataUC,1,i,1);
    DP_i_var_num{i} = DP.var_num;
    DP_i_var_type{i} = DP.var_type;
    DP_i_var_names{i} = DP.var_names;
    DP_i_c{i} = DP.c;
    DP_i_Q{i} = DP.Q;
    DP_i_Aineq{i} = DP.Aineq;
    DP_i_Aeq{i} = DP.Aieq;
    DP_i_rhs{i} = DP.b;
    DP_i_c_B_wan{i} = DP.c_B_wan;
    DP_i_Qrow{i} = DP.Qrow;
    DP_i_Qcol{i} = DP.Qcol;
    DP_i_Qval{i} = DP.Qval;
    DP_i_ub{i} = DP.ub;
    DP_i_lb{i} = DP.lb;
end

%��G_1��Ļ����γ�������gruobiģ��
for i = 1:size(DP_2)
    DP.var_num = DP.var_num + DP_i_var_num{i}; 
    DP.var_type = [DP.var_type,DP_i_var_type{i}]; 
    DP.var_names = [DP.var_names;DP_i_var_names{i}];
    DP.var_c = [DP.var_c;DP_i_c{i}]; 
    DP.Q = [DP.Q;DP_i_Q{i}]; 
    DP.Aineq = blkdiag(DP.Aineq,DP_i_Aineq{i});
    DP.Aeq = blkdiag(DP.Aeq,DP_i_Aeq{i});
     DP.rhs = [DP.rhs;DP_i_rhs{i}];
    DP.c_B_wan = [DP.c_B_wan,DP_i_c_B_wan];
    DP.ub = [DP.ub;DP_i_ub];
    DP.lb = [DP.lb;DP_i_lb];
    
    %�ϲ�����׶Լ��
    for j = 1:size(DP.Qrow,1)
       DP_i_Qrow(j) =  DP.var_num + DP_i_Qrow(j);
       DP_i_Qcol(j) = DP.var_num + DP_i_Qcol(j);
    end
    DP.Qrow = [DP.Qrow,DP_i_Qrow];
    DP.Qcol = [DP.Qcol,DP_i_Qcol]; 
    DP.Qval = [DP.Qval,DP_i_Qval]; 
end


DP_2_Model = DP;
end