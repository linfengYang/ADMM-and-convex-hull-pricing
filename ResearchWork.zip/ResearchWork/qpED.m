
function [ qp_i,qp ] = qpED( dataUC )
ramp = 1;

N = dataUC.N;   T = dataUC.T;
x_L = cell(N,1);    x_U = cell(N,1);
A = cell(N,1);      b = cell(N,1);
B = cell(N,1);      B_wan = cell(N,1);
Q_UC = cell(N,1);   c_UC = cell(N,1);
ctype = cell(N,1);

for i = 1:N   % ���ջ���ֿ��γ�Լ�����Ի���i���������������Լ����Ϊһ��
    % unit generation limits 
    A_x_L{i} = sparse(1:T,T,-1);% �����½�dataUC.p_low(i)
    A_x_U{i} = sparse(1:T,T,1);% �����Ͻ�
    
    b_x_L{i} = -dataUC.p_low(i) * ones(T,1);
    b_x_U{i} = dataUC.p_up(i) * ones(T,1);
    %������������
    ctype{i} = '';
    ctype{i}(1:T) = 'C';
    
    % Ramp rate limits constrains
    A_ramp_up = ones(T,T); 
    A_ramp_down = ones(T,T);
    b_ramp_up = ones(T,1);
    b_ramp_down = ones(T,1);
    for t = 1:T 
        if t == 1      
            A_ramp_up(t, t) = 1;
            b_ramp_up(t) =  dataUC.p_rampup(i)+dataUC.p_initial(i);
          
            A_ramp_down(t, t) = -1;
            b_ramp_down(t) = -dataUC.p_initial(i) + dataUC.p_rampdown(i);

        else
%             if dataUC.p_initial(i)>dataUC.p_rampup(i)      
            A_ramp_up(t, t-1) = -1;
            A_ramp_up(t, t) = 1;
            b_ramp_up(t) =  dataUC.p_rampup(i);
            %     b_ramp_up(t) =  0;
            
            A_ramp_down(t,  t-1) = 1;
            A_ramp_down(t,  t) = -1;
            b_ramp_down(t) =  dataUC.p_rampdown(i);
%             %      b_ramp_down(t) = 0;
         end
        
    end
    % form A_i  b_i          
    if ramp == 1
        A{i} = [  
                    A_ramp_up;
                    A_ramp_down;
            ];
        b{i} = [  
                    b_ramp_up;
                    b_ramp_down;
        ];    
    end
    %power balance constraint
    B_wan{i} = ones(T,T);
    % �γɹ���ƽ��Լ�����Ҷ���
    c_wan = dataUC.PD;
    % Ŀ�꺯�� 
    c_UC{i} = dataUC.beta(i) * ones(T,1);      
    Q_UC{i} = sparse(1:T,1:T, 2*dataUC.gamma(i));

A{i} = [A{i}; A_x_L{i}; A_x_U{i};B_wan{i}];
b{i} = [b{i}; b_x_L{i}; b_x_U{i}; c_wan];
end

% ���طֿ��ģ������
qp_i.A = A;           qp_i.b = b;
qp_i.B_wan = B_wan;   qp_i.c_wan = c_wan;
qp_i.c_UC = c_UC;     qp_i.Q_UC = Q_UC;
qp_i.x_L = x_L;       qp_i.x_U = x_U;
qp_i.N = N;           qp_i.T = T;
qp_i.ctype = ctype;
% miqp_i.ctype = ctype;
% �γɲ����� ����MIQPģ�͵Ĳ���
qp.A = [];           qp.b = [];
qp.c_UC = [];     qp.Q_UC = [];
qp.B_wan = [];   qp.c_wan = c_wan;
qp.x_L = [];       qp.x_U = [];
% qp.ctype = [];
for i = 1:N
   qp.A = blkdiag(qp.A, A{i});
   qp.b = [qp.b; b{i}];
   qp.B_wan = [qp.B_wan, B_wan{i}];
   qp.c_UC = [qp.c_UC; c_UC{i}];
   qp.Q_UC = blkdiag(qp.Q_UC, Q_UC{i});
   qp.x_L = [qp.x_L; x_L{i}];
   qp.x_U = [qp.x_U; x_U{i}];
%    qp.ctype = [qp.ctype, ctype{i}];
end
qp.A_all = [qp.A;    
     qp.B_wan;
    ];
qp.lhs_all = [ -inf * ones(size(qp.A,1),1);   
    qp.c_wan;
    ];
qp.rhs_all =    [qp.b;  
    qp.c_wan;
    ];
qp.N = N;
qp.T = T;
%%%% end of function
end


