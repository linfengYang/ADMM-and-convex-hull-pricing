function [G2_model_i] = Build_3bin_Model(dataUC,G2,L)
length = size(G2,2);
model_i.var_num = cell(length,1);
model_i.var_type = cell(length,1);
model_i.var_names = cell(length,1);
model_i.obj_c = cell(length,1);
model_i.Q = cell(length,1);
model_i.Aineq = cell(length,1);
model_i.Aeq = cell(length,1);
model_i.bineq = cell(length,1);
model_i.beq = cell(length,1);
model_i.Bwan = cell(length,1);
model_i.ub = cell(length,1);
model_i.lb = cell(length,1);
model_i.soc = cell(length,1);
model_i.slackModel = cell(length,1);

M.var_num = 0; M.var_type = []; M.var_names = [];
M.var_c = []; M.Q = []; M.Aineq = [];M.bineq = [];
M.Aeq = []; M.beq = []; M.c_B_wan = []; M.ub = [];
M.lb = [];
%��ȡ���������ģ��
for i = 1:size(G2,2)
    j = G2(i);
    M = model_3bin(dataUC,j,L); %����3binģ��
    model_i.var_num{i} = M.var_num;
    model_i.var_type{i} = M.var_type;
    model_i.var_names{i} = M.var_names;
    model_i.obj_c{i} = M.obj_c;
    model_i.Aineq{i} = M.Aineq;
    model_i.Aeq{i} = M.Aeq;
    model_i.bineq{i} = M.bineq;
    model_i.beq{i} = M.beq;
    model_i.Bwan{i} = M.Bwan;
    model_i.ub{i} = M.ub;
    model_i.lb{i} = M.lb;
    model_i.soc{i} = 0;
    model_i.slackModel{i} = 1;
end

G2_model_i = model_i;
end