function result = solve_P(tol_Model,p_k)  
%����������ն�ż����
%{c(x) - <r,Bx - 1/N*PD>}

params.outputflag = 0;           %0��ʾ�����д��ڲ���ʾ�����̣�1��ʾ��ʾ����
params.MIPGap = 0.001; 

obj_c = tol_Model.obj_c - tol_Model.Bwan' * p_k;

Gmodel.obj = full(obj_c);
Gmodel.A = [tol_Model.Aineq;tol_Model.Aeq];
Gmodel.rhs = full([tol_Model.bineq;tol_Model.beq]);
Gmodel.sense(1:size(tol_Model.Aineq,1)) = '<';
Gmodel.sense(size(tol_Model.Aineq,1)+1:size(tol_Model.Aineq,1)+size(tol_Model.Aeq,1)) = '=';
Gmodel.vtype = tol_Model.var_type;
Gmodel.modelsense = 'min';
Gmodel.varnames = tol_Model.var_names;
Gmodel.lb = full(tol_Model.lb);
Gmodel.ub = full(tol_Model.ub);
Gmodel.vtype(Gmodel.vtype == 'B') = 'C';                        
%gurobi_write(Gmodel, 'dual.lp');
result = gurobi(Gmodel,params);

% for v=1:length(tol_Model.var_names)
%      fprintf('%s %d\n',tol_Model.var_names{v},result.x(v));
% end

end