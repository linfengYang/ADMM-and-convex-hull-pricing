%%  D_ADMM solve ED problem
function ADMM_CHP(pathAndFilename)

tic
%%%�����ļ�����

      pathAndFilename='UC_AF/example_2_std.mod';
%    pathAndFilename='UC_AF/2_std.mod';
%     pathAndFilename='UC_AF/3_std.mod';   
%     pathAndFilename='UC_AF/4_std.mod';   
%     pathAndFilename='UC_AF/5_std.mod';
%     pathAndFilename='UC_AF/10_0_1_w.mod';
%     pathAndFilename='UC_AF/20_0_1_w.mod'; 
%     pathAndFilename='UC_AF/75_0_1_w.mod';

%      pathAndFilename='UC_AF/c1_28_based_8_std.mod';
%      pathAndFilename='UC_AF/c2_35_based_8_std.mod';
%     pathAndFilename='UC_AF/c3_44_based_8_std.mod'; 
%     pathAndFilename='UC_AF/c4_45_based_8_std.mod';
%     pathAndFilename='UC_AF/c5_49_based_8_std.mod';
%     pathAndFilename='UC_AF/c6_50_based_8_std.mod';
%     pathAndFilename='UC_AF/c7_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c8_51_based_8_std.mod';
%       pathAndFilename='UC_AF/c9_52_based_8_std.mod';
%       pathAndFilename='UC_AF/c10_54_based_8_std.mod';
%       pathAndFilename='UC_AF/c11_132_based_8_std.mod';
%       pathAndFilename='UC_AF/c12_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c13_156_based_8_std.mod';
%       pathAndFilename='UC_AF/c14_165_based_8_std.mod';
%       pathAndFilename='UC_AF/c15_167_based_8_std.mod';
%      pathAndFilename='UC_AF/c20_187_based_8_std.mod';
dataUC=readdataUC(pathAndFilename);
qcp_i=qpED_CHP(dataUC);
qp_i = qpED(dataUC);
N = dataUC.N;
option = 0; %ֵΪ0ʹ�������õ�UCģ����⣬ֵΪ1ʹ��DPģ�����
for i = 1:1
    solve_UC(dataUC,qcp_i,qp_i,i,option); 
end
end
