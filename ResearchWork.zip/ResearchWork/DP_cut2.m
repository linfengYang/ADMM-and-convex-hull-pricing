function [Flag2,new_model_i,cut] = DP_cut2(dataUC,model,model_DP,model_i,rou,BxISO,p_k,y_k,cut)
T = dataUC.T;
new_model_i = model_i;
Flag2 = 0;  %��¼��Ҫ�滻Ϊ͹��ģ�͵�������
slack = 0;
for i = 1:size(model.unitNum,2)
    slack = slack + model.slack(i);
end
if slack > 0
    %������Ŀ�꺯��һ����
    model.obj_f = model.obj_c +  model.Bwan' * (rou * p_k - BxISO + y_k)/ rou;
    model_DP.obj_f = model_DP.obj_c +  model_DP.Bwan' * (rou * p_k - BxISO + y_k)/ rou;
    %������Ŀ�꺯��������
    model.obj_Q = model.Bwan' * model.Bwan / (2*rou);
    model_DP.obj_Q = model_DP.Bwan' * model_DP.Bwan / (2*rou);
    xi_relax = solve_Subproblem(model,1);
    xi_DP = solve_Subproblem(model_DP,1);
    
    s_r = 1; s_dp = 1;
    for i = 1:size(model.unitNum,2)
        var_num_r = model.var_num(i);
        var_num_d = model_DP.var_num(i);
        d_r = s_r + var_num_r - 1;
        d_dp = s_dp + var_num_d - 1;
        if model.slack(i) == 1
            dist = norm(model.Bwan(:,s_r:d_r) * xi_relax(s_r:d_r) - model_DP.Bwan(:,s_dp:d_dp) * xi_DP(s_dp:d_dp),2);
            val_slack = xi_relax(s_r:d_r)' * model.obj_c(s_r:d_r);
            val_DP = xi_DP(s_dp:d_dp)' * model_DP.obj_c(s_dp:d_dp);
            gap = abs(val_slack - val_DP);
            if dist >= 1e-3 && gap >= 1e-3      
                fprintf('�����ƽ��cut2:');
                cut = [cut;model.unitNum(i)];
                new_model_i = DP_replace_G2model(i,model.unitNum(i),new_model_i,dataUC);    %unit j��ģ�Ͳ���͹��ģ��
                Flag2 = Flag2 + 1;      %Flag++
            end
            if dist >= 1e-3 && gap < 1e-3
                if isInfeasible(dataUC,model.unitNum(i),xi_relax(s_r:d_r),model.Bwan(:,s_r:d_r))
                    fprintf('�����м����ƽ��cut2:');
                    cut = [cut;model.unitNum(i)];
                    new_model_i = DP_replace_G2model(i,model.unitNum(i),new_model_i,dataUC);    %unit j��ģ�Ͳ���͹��ģ��
                    Flag2 = Flag2 + 1;      %Flag++
                end
            end
        end
        s_r = s_r + var_num_r;
        s_dp = s_dp + var_num_d;
    end
end
end