function [xi,objval,r_eq] = solve(dataUC,model_PI,relax)

n = size(model_PI,1);
T = dataUC.T;
tol_model.Aineq = [];
tol_model.bineq = [];
tol_model.Aeq = [];
tol_model.beq = [];
tol_model.lb = [];
tol_model.ub = [];
tol_model.var_type = [];
tol_model.var_names = [];
tol_model.var_num = [];
tol_model.Bwan = [];
tol_model.b = [];
tol_model.obj_c = [];
tol_model.slack = [];

for i = 1:n
    tol_model.var_num = [tol_model.var_num,model_PI{i}.var_num];
    tol_model.var_type = [tol_model.var_type,model_PI{i}.var_type];
    tol_model.var_names = [tol_model.var_names;model_PI{i}.var_names];
    tol_model.obj_c = [tol_model.obj_c;model_PI{i}.obj_c];
    tol_model.Aineq = blkdiag(tol_model.Aineq,model_PI{i}.Aineq);
    tol_model.Aeq = blkdiag(tol_model.Aeq,model_PI{i}.Aeq);
    tol_model.bineq = [tol_model.bineq;model_PI{i}.bineq];
    tol_model.beq = [tol_model.beq;model_PI{i}.beq];
    tol_model.Bwan = [tol_model.Bwan,model_PI{i}.Bwan];
    tol_model.lb = [tol_model.lb;model_PI{i}.lb];
    tol_model.ub = [tol_model.ub;model_PI{i}.ub];
    tol_model.slack = [tol_model.slack,model_PI{i}.slack];
end

%��Gurobi���
params.outputflag = 0;           %0��ʾ�����д��ڲ���ʾ�����̣�1��ʾ��ʾ����
%params.NonConvex = 2;
%params.QCPDual = 1;
params.MIPGap = 0.001; 
%params.timelimit = 1000;
%params.BarConvTol = 1e-12;        %Barrier convergence tolerance Ĭ��1e-8


tol_model.Aeq = [tol_model.Aeq;tol_model.Bwan];
tol_model.beq = [tol_model.beq;dataUC.PD];
model.obj = full(tol_model.obj_c);
model.A = [tol_model.Aineq;tol_model.Aeq];
model.rhs = full([tol_model.bineq;tol_model.beq]);
model.sense(1:size(tol_model.Aineq,1)) = '<';
model.sense(size(tol_model.Aineq,1)+1:size(tol_model.Aineq,1)+size(tol_model.Aeq,1)) = '=';
model.vtype = tol_model.var_type;
model.modelsense = 'min';
model.varnames = tol_model.var_names;
model.lb = full(tol_model.lb);
model.ub = full(tol_model.ub);

if relax == 1    %�����������ɳڵ�����
    model.vtype(model.vtype == 'B') = 'C';                        %�����������ĳ���������   
end
%gurobi_write(model, 'model.lp');
result = gurobi(model,params);


xi = result.x;
objval = result.objval;
if relax == 1
    r_eq = result.pi(size(model.rhs,1) - T + 1:end);
end

end