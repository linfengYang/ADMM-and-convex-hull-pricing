function Model = Build_Model(dataUC,G3,type)
length = size(G3,2);
model_i_var_num = cell(length,1);
model_i_var_type = cell(length,1);
model_i_var_names = cell(length,1);
model_i_obj_c = cell(length,1);
model_i_Q = cell(length,1);
model_i_Aineq = cell(length,1);
model_i_Aeq = cell(length,1);
model_i_bineq = cell(length,1);
model_i_beq = cell(length,1);
model_i_Bwan = cell(length,1);
model_i_Qrow = cell(length,1);
model_i_Qcol = cell(length,1);
model_i_Qval = cell(length,1);
model_i_ub = cell(length,1);
model_i_lb = cell(length,1);
model_i_slackModel = cell(length,1);

model.var_num = 0; model.var_type = []; model.var_names = [];
model.obj_c = []; model.Q = []; model.Aineq = [];
model.Aeq = []; model.Bwan = []; model.Qrow = [];
model.Qcol = []; model.Qval = []; model.ub = [];
model.lb = [];model.bineq = []; model.beq = [];
model.slackModel = [];
%��ȡ���������͹��
for i = 1:length
    j = G3(i);
    if (strcmp(type,'DP1'))
       m = model_DP1(dataUC,j);
    end
    if (strcmp(type,'DP2'))
       m = model_DP2(dataUC,j);
    end
     if (strcmp(type,'3bin'))
       m = model_3bin(dataUC,j,lnegth);
    end
    model_i_var_num{i} = m.var_num;
    model_i_var_type{i} = m.var_type;
    model_i_var_names{i} = m.var_names;
    model_i_obj_c{i} = m.obj_c;
    model_i_Q{i} = m.Q;
    model_i_Aineq{i} = m.Aineq;
    model_i_Aeq{i} = m.Aeq;
    model_i_bineq{i} = m.bineq;
    model_i_beq{i} = m.beq;
    model_i_Bwan{i} = m.Bwan;
    model_i_Qrow{i} = m.Qrow;
    model_i_Qcol{i} = m.Qcol;
    model_i_Qval{i} = m.Qval;
    model_i_ub{i} = m.ub;
    model_i_lb{i} = m.lb;
    model_i_slackModel{i} = 0;
end

%��G_1��Ļ����γ�������gruobiģ��
for i = 1:length
    model.var_num = model.var_num + model_i_var_num{i}; 
    model.var_type = [model.var_type,model_i_var_type{i}]; 
    model.var_names = [model.var_names;model_i_var_names{i}];
    model.obj_c = [model.obj_c;model_i_obj_c{i}]; 
    model.Q = [model.Q;model_i_Q{i}]; 
    model.Aineq = blkdiag(model.Aineq,model_i_Aineq{i});
    model.Aeq = blkdiag(model.Aeq,model_i_Aeq{i});
    model.bineq = [model.bineq;model_i_bineq{i}];
    model.beq = [model.beq;model_i_beq{i}];
    model.Bwan = [model.Bwan,model_i_Bwan{i}];
    model.ub = [model.ub;model_i_ub{i}];
    model.lb = [model.lb;model_i_lb{i}];
    model.slackModel = [model.slackModel;model_i_slackModel{i}];
end


Model = model;
end