%% ***************************************************************
%             ���ߣ���ʩ��
%             ԭ�����ڣ�2021��6��7��
%             �޸����ڣ�
%             ����˵������ȡ����ռ��еĽ����
%% ***************************************************************
function result = GetLog_GUROBI(ModelName,model,data,boolean_MILP,access_relax,times_T,times_Uit,index,solver,Orig_result,DC_flow)
result = Orig_result;

%�ռ�������ʽGUROBI\MIQP\MIP\data1\5_160unit_expandTime_1_expandUnit_1_ģ������
FileFoder = fullfile('.\log\');   %�ļ�·��
FileFoder = strcat(FileFoder,solver,'\');    %�ļ���

if(boolean_MILP == 1)             %1��ʾĿ�꺯�����Ի�
    FileFoder = strcat(FileFoder,'MILP\');
else
    FileFoder = strcat(FileFoder,'MIQP\');
end

if(access_relax == 0)         %1��ʾ��������ɳڣ�0��ʾ���MIP����
    FileFoder = strcat(FileFoder,'MIP\');
else
    FileFoder = strcat(FileFoder,'Relax\');
end
    
if(DC_flow == 1)
    FileName = strcat('DC','\',num2str(index),'_',num2str(model.NodeNum),'bus_',num2str(model.N),'unit_expandTime_',num2str(times_T),'_expandUnit_',num2str(times_Uit),'_',ModelName,'.txt');
else
    FileName = strcat('data',num2str(data),'\',num2str(index),'_',num2str(model.N),'unit_expandTime_',num2str(times_T),'_expandUnit_',num2str(times_Uit),'_',ModelName,'.txt');
end
FilePath = strcat(FileFoder,FileName);  %�ļ�·��

fidin = fopen(FilePath);                %���ļ�
cuts = 0;
end_flag = 0;
begin_flag = 0;
while ~feof(fidin)                      %judging whether the end of file
    tline = fgetl(fidin);               %��ȡһ��
    if(~isempty(tline))                 %�ж��ǲ��ǿ���
        
        %��str������pattern�����str��ÿ�γ��ֵ�pattern����ʼ���������δ�ҵ����򷵻�һ��������[]���������ִ�Сд��
        %ͳ��cons��vars��nonzs
        if(~isempty(strfind(tline,'Optimize a model with ')))
            str_loc = strfind(tline,'Optimize a model with ');
            rows_loc = strfind(tline,' rows, ');
            cons = str2double(tline(str_loc + length('Optimize a model with ') : rows_loc - 1));
            columns_loc = strfind(tline,' columns and ');
            vars = str2double(tline(rows_loc + length(' rows, ') : columns_loc - 1));
            nonzeros_loc = strfind(tline,' nonzeros');
            nonzs = str2double(tline(columns_loc + length(' columns and ') : nonzeros_loc - 1));
        end
        
        %ͳ��Ԥ�������cons��vars��nonzs
        if(~isempty(strfind(tline,'Presolved: ')))
            str_loc = strfind(tline,'Presolved: ');
            rows_loc = strfind(tline,' rows, ');
            pre_cons = str2double(tline(str_loc + length('Presolved: ') : rows_loc - 1));
            columns_loc = strfind(tline,' columns, ');
            pre_vars = str2double(tline(rows_loc + length(' rows, ') : columns_loc - 1));
            nonzeros_loc = strfind(tline,' nonzeros');
            pre_nonzs = str2double(tline(columns_loc + length(' columns, ') : nonzeros_loc - 1));
        end
        
        %ͳ��cuts
        if(~isempty(strfind(tline,'Explored')))
            end_flag = 1;
            begin_flag = 0;
        end
        
        if(begin_flag == 1 && end_flag == 0)
            if(~isempty(strfind(tline,': ')))
                str_loc = strfind(tline,': ');
                cuts = cuts + str2double(tline(str_loc + length(': ') : length(tline)));
            end
        end
        
        if(~isempty(strfind(tline,'Cutting planes:')))
            begin_flag = 1;
            end_flag = 0;
        end
        
        if(~isempty(strfind(tline,'Explored')))

            result.cons = cons;
            result.vars = vars;
            result.nonzs = nonzs;
            result.pre_cons = pre_cons;
            result.pre_vars = pre_vars;
            result.pre_nonzs = pre_nonzs;
            result.cuts = cuts;

            cons = 0;
            vars = 0;
            nonzs = 0;
            pre_cons = 0;
            pre_vars = 0;
            pre_nonzs = 0;
            cuts = 0;
            
        end
    end
end

fclose(fidin);

end


