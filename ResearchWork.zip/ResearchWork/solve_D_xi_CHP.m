
 function xi = solve_D_xi_CHP(dataUC,i,DP,y_k,p_k,r,relax)
 %ʹ��gruobi����ڲ�������
    PD = dataUC.PD;
    obj_c = DP.c + DP.c_B_wan'*(y_k(:,i) - PD - r*p_k) / r;
    DP.obj_Q = DP.c_B_wan'* DP.c_B_wan / (2*r);
    
    
    %���ñ������ƺ�����
      model.varnames = DP.names;
      if relax == 1
         model.vtype = DP.ctype_int;
      else
          model.vtype = DP.ctype;
      end
      
      %����һ����ϵ��
      model.obj = obj_c;
      model.modelsense = 'min';
      
      if relax == 1
       %�����ɳڱ������½�
       model.ub = DP.ub;
       model.lb = DP.lb;
      end
      %���ö�����ϵ��
      model.Q = DP.obj_Q;
      %���ò���ʽԼ��
      model.A =DP.A;
      model.rhs = DP.b;
      model.sense(1:size(DP.A,1) - size(DP.B,1)) = '<';
      model.sense(size(DP.A,1) - size(DP.B,1) + 1:size(DP.A,1)) = '=';
      
     
     %��ת����׶Լ��
     Q_num = size(DP.Qrow,2)/2; k = 1;j = 2;
     for i = 1:Q_num
         model.quadcon(i).Qrow = DP.Qrow(k:j);
         model.quadcon(i).Qcol = DP.Qcol(k:j);
         model.quadcon(i).Qval = DP.Qval(k:j);
         model.quadcon(i).q  = DP.Q;
         model.quadcon(i).rhs = 0.0;
         model.quadcon(i).name = ['rot_cone',num2str(i)];
         k = k + 2;
         j = j + 2;
     end
     
     
     %params.QCPDual = 1;
     %params.MIPGap = 0;
     params.OutputFlag = 0; 
     %params.Time = 1;
     %gurobi_write(model, 'qcp.lp');
     result = gurobi(model, params);
     %for v=1:length(DP.names)
     %fprintf('%s %d\n',DP.names{v},result.x(v));
     %end
     xi = result.x;
  
     
     
end