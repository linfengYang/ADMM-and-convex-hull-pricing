function DP_1_Model = Build_DP_1_Model(dataUC,N)
DP_i_var_num = cell(N,1);
DP_i_var_type = cell(N,1);
DP_i_var_names = cell(N,1);
DP_i_obj_c = cell(N,1);
DP_i_Q = cell(N,1);
DP_i_Aineq = cell(N,1);
DP_i_Aeq = cell(N,1);
DP_i_bineq = cell(N,1);
DP_i_beq = cell(N,1);
DP_i_Bwan = cell(N,1);
DP_i_Qrow = cell(N,1);
DP_i_Qcol = cell(N,1);
DP_i_Qval = cell(N,1);
DP_i_ub = cell(N,1);
DP_i_lb = cell(N,1);


DP.var_num = []; DP.var_type = []; DP.var_names = [];
DP.obj_c = []; DP.Q = []; DP.Aineq = [];
DP.Aeq = []; DP.Bwan = []; DP.Qrow = [];
DP.Qcol = []; DP.Qval = []; DP.ub = [];
DP.lb = [];DP.bineq = []; DP.beq = [];
%��ȡ���������͹��
for i = 1:N
    DP = model_DP1(dataUC,i);
    DP_i_var_num{i} = DP.var_num;
    DP_i_var_type{i} = DP.var_type;
    DP_i_var_names{i} = DP.var_names;
    DP_i_obj_c{i} = DP.obj_c;
    DP_i_Q{i} = DP.Q;
    DP_i_Aineq{i} = DP.Aineq;
    DP_i_Aeq{i} = DP.Aeq;
    DP_i_bineq{i} = DP.bineq;
    DP_i_beq{i} = DP.beq;
    DP_i_Bwan{i} = DP.Bwan;
    DP_i_Qrow{i} = DP.Qrow;
    DP_i_Qcol{i} = DP.Qcol;
    DP_i_Qval{i} = DP.Qval;
    DP_i_ub{i} = DP.ub;
    DP_i_lb{i} = DP.lb;
end

%��G_1��Ļ����γ�������gruobiģ��
for i = 1:N
    DP.var_num = DP.var_num + DP_i_var_num{i}; 
    DP.var_type = [DP.var_type,DP_i_var_type{i}]; 
    DP.var_names = [DP.var_names;DP_i_var_names{i}];
    DP.obj_c = [DP.obj_c;DP_i_obj_c{i}]; 
    DP.Q = [DP.Q;DP_i_Q{i}]; 
    DP.Aineq = blkdiag(DP.Aineq,DP_i_Aineq{i});
    DP.Aeq = blkdiag(DP.Aeq,DP_i_Aeq{i});
    DP.bineq = [DP.bineq;DP_i_bineq{i}];
    DP.beq = [DP.beq;DP_i_beq{i}];
    DP.Bwan = [DP.Bwan,DP_i_Bwan{i}];
    DP.ub = [DP.ub;DP_i_ub{i}];
    DP.lb = [DP.lb;DP_i_lb{i}];
    
   
end


DP_1_Model = DP;
end