function [ M_i,M ] = test( dataUC )  %�Զ��庯��������dataUC�����qp_i,qp

N = dataUC.N;   T = dataUC.T;

%dataUC.u0(1) = 0; dataUC.time_min_on(1) = 8; dataUC.time_min_off(1) = 8;
%dataUC.time_on_off_ini(1) = 8; dataUC.p_low(1) = 150; dataUC.p_up(1) = 150;
%dataUC.p_rampup(1) = 50;  dataUC.p_rampdown(1) = 50;
%dataUC.beta(1) = 1; dataUC.gamma(1) = 1;
%dataUC.p_startup(1) = 50; dataUC.p_shutdown(1) = 50;

E = cell(N,1);          Constraints = cell(N,1);
objective =cell(N,1);   Pit = cell(N,1);
Phkit = cell(N,1);      Yhk = cell(N,1);
Zhkit = cell(N,1);      Zi = cell(N,1);

for i = 1:N %���ջ�����зֿ飬����������ص�Լ����Ϊһ�顣
    
    U_i = max(min(T,dataUC.u0(i)*(dataUC.time_min_on(i) - dataUC.time_on_off_ini(i))),0);
    L_i = max(min(T,dataUC.u0(i)*(dataUC.time_min_off(i) + dataUC.time_on_off_ini(i))),0);
    
    Node = cell(T,2);   %����ͼ��㼯N
    index = 1;
    Node{index,1} = 0;
    Node{index,2} = 0;
    index = index + 1;
    Node{index,1} = inf;
    Node{index,2} = inf;
    sum_t{i} = 0;  %���е�ʱ���ܺ�
    for h = 1:T                
        for k = min(h + dataUC.time_min_on(i) + 1, T):T
            index  = index + 1;
            Node{index,1} = h;
            Node{index,2} = k;
            sum_t{i} = sum_t{i} + (k - h + 1);
         end
    end
    
    Node_len_1 = length(Node) - 2; %N1�ڵ㼯�ĳ��ȡ�
    
    Node_1 = Node;     %N1��㼯
    
   
    for h = 3:Node_len_1 + 2      %������չͼ�ڵ㼯N_wan
        index = index + 1;
        Node{index,1} = -Node{h,1};
        Node{index,2} = -Node{h,2};
    end
    
    Arc = cell(T,4);   %��������
    index = 1;
    
    for p = 3:Node_len_1 + 2  %����A1����
        for j = 3:Node_len_1 + 2
            k = Node{p,2};
            r = Node{j,1};
            if r >= k + dataUC.time_min_on(i) + 1 
                Arc{index,1} = Node{p,1};
                Arc{index,2} = k;
                Arc{index,3} = r;
                Arc{index,4} = Node{j,2};
                index = index + 1;
            end         
        end
    end
    
    disp(i);
    for p = 3:Node_len_1 + 2  %����A2����
        if dataUC.u0(i) == 1
            if Node{p,1} == 1 && Node{p,2} >= U_i
                Arc{index,1} = 0;
                Arc{index,2} = 0;
                Arc{index,3} = Node{p,1};
                Arc{index,4} = Node{p,2};
            end
             index = index + 1;
        end
    end
    
    for p = 3:Node_len_1 + 2   %����A3����
        if dataUC.u0(i) == 0
            if Node{p,1} >= L_i + 1
                Arc{index,1} = 0;
                Arc{index,2} = 0;
                Arc{index,3} = Node{p,1};
                Arc{index,4} = Node{p,2};
            end
        end
        index = index + 1;
    end
    
    for p = 3:Node_len_1 + 2    %����A4����
        Arc{index,1} = Node{p,1};
        Arc{index,2} = Node{p,2};
        Arc{index,3} = Inf;
        Arc{index,4} = Inf;
        index = index + 1;
    end
    
    Arc_len_original = length(Arc);
    
    Arc_wan = cell(Node_len_1,4); %������չ����
    p = Node_len_1 + 2;
    index = 1;
    for h = 3:Node_len_1 + 2
        p = p + 1;
        Arc_wan{index,1} = Node{h,1};
        Arc_wan{index,2} = Node{h,2};
        Arc_wan{index,3} = Node{p,1};
        Arc_wan{index,4} = Node{p,2};
        index = index + 1;
    end
    
    Arc = [Arc_wan;Arc];
    
    %�������-��ϵ������
    E{i} = sparse(length(Node),length(Arc));
    for p = 1:length(Node)
        for j = 1:length(Arc)
            s_1 = Arc{j,1};
            s_2 = Arc{j,2};
            d_1 = Arc{j,3};
            d_2 = Arc{j,4};
            if Node{p,1} == s_1 & Node{p,2} == s_2
               E{i}(p,j) = -1;
            end
            if Node{p,1} == d_1 & Node{p,2} == d_2
               E{i}(p,j) = 1;
            end
        end
    end
    
    
    %������������
    Pit{i} = sdpvar(T,1);
    Phkit{i} = sdpvar(sum_t{i},1);
    Yhk{i} = binvar(Node_len_1,1);
    Zhkit{i} = sdpvar(sum_t{i},1);
    Zi{i} = binvar(Arc_len_original,1);
    
    %�������½�Լ��
    t1 = 1;
    t2 = 0;
    for index = 3:Node_len_1
        h = Node{index,1};
        k = Node{index,2};
        t1 = t1 + t2;
        t2 = t2 + (k - h + 1);
        Constraints{i} = [Constraints{i}, Yhk{i}(index) * dataUC.p_up(i) <= Phkit{i}(t1:t2)];
        Constraints{i} = [Constraints{i}, Phkit{i}(t1:t2) <= Yhk{i}(index) * dataUC.p_low(i)];
    end
    
    %�����С��ͣ����
    t = 1;
    for index = 3:Node_len_1 - 1
        h = Node{index,1};
        k = Node{index,2};
        Constraints{i} = [Constraints{i}, Phkit{i}(t) <= Yhk{i}(index) * dataUC.p_startup(i)];
        Constraints{i} = [Constraints{i}, Phkit{i}(t + (k - h)) <= Yhk{i}(index) * dataUC.p_shutdown(i)];
        t = t + (k - h + 1);
    end
    
    %��������Լ��
    t1 = 1;
    t2 = 0;
    for index = 3:Node_len_1
        h = Node{index,1};
        k = Node{index,2};
        t1 = t1 + t2;
        t2 = t2 + (k - h + 1);
        Constraints{i} = [Constraints{i}, Phkit{i}(t1 + 1:t2) - Phkit{i}(t1:t2 - 1) <= Yhk{i}(index) * dataUC.p_rampup(i)];
        Constraints{i} = [Constraints{i}, Phkit{i}(t1:t2 - 1) - Phkit{i}(t1 + 1:t2) <= Yhk{i}(index) * dataUC.p_rampdown(i)];
    end
    
    %����׶Լ��
    t1 = 1;
    t2 = 0;
    for index = 3:Node_len_1
        h = Node{index,1};
        k = Node{index,2};
        t1 = t1 + t2;
        t2 = t2 + (k - h + 1);
        Constraints{i} = [Constraints{i}, Phkit{i}(t1:t2)' * Phkit{i}(t1:t2) <= Yhk{i}(index) * Zhkit{i}(t1:t2)'];
    end
   
    
    %Լ��31
    for t = 1:T
        t_sum = [];
        index1 = 1;
        index2 = 1;
        for index = 3:Node_len_1
            h = Node{index,1};
            k = Node{index,2};
            if t >= h && t <= k
               for j = h:k
                   if t == j
                      t_sum(index1) = index2;
                      index1 = index1 + 1;
                   end
               end
            end
            index2 = index2 + (k - h + 1);
        end
         Constraints{i} = [Constraints{i},Pit{i}(t,1) == sum(Phkit{i}(t_sum))];
    end
    
    
    %����·��Լ��
    b = sparse(length(Node),1);
    b(1,1) = -1;
    b(2,1) = 1;
    Constraints{i} = [Constraints{i},E{i} * [Yhk{i};Zi{i}] == b];
   
    W = 50 * ones(Arc_len_original,1);
    
    %Ŀ�꺯��
    objective{i} = W' * Zi{i} + dataUC.beta(i) * sum(Phkit{i}) + dataUC.gamma(i) * sum(Zhkit{i});
    
end

%���طֿ������
M_i.E = E;                 M_i.Constraints = Constraints;
M_i.objective = objective; M_i.Pit = Pit;
M_i.Phkit = Phkit;         M_i.Yhk = Yhk;
M_i.Zhkit = Zhkit;         M_i.Zi = Zi;

M.N = N;
M.T = T;



end
