function b = if_Int(x,s,d)
%判断拉格朗日对偶问题得到的解是不是整数解
b = 1;

for j = 1:size(B_x)
    if B_x(j) ~= fix(B_x(j))
       b = 0;
       break;
    end
end
end